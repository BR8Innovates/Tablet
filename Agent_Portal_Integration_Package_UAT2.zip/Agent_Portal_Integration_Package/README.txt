UAT2 (protecuat2) - updated 26 Nov 2026
Base URL: https://protecuat2-sandbox-protec-in.insuremo.com   Tenant: protecuat2
Token: POST /cas/get-token with username, password, tenant_code "protecuat2" and user_source_id "platform".
  The login fails without user_source_id. Token valid about 2 hours.
Environment file: 02_Collections/Protec_UAT2_Environment.postman_environment.json (password not included).
Test data and credentials: 04_Excel/UAT2_Environment_TestData_Credentials.xlsx (password shared separately).
Agent IA000001, customer PI-26-00000001, float collection 5350670.
Collection token request now sends user_source_id from the userSourceId variable (default platform).

Agent Portal Integration Package - 24 Nov 2026
Environment: InsureMO UAT2 (protecuat2). Products: PCAR 1005, P2W 1106, PCV 1202, GCV 1204.

01_Document
  Agent_Portal_Integration_Document.docx   All Agent Portal APIs as individual APIs (InsureMO template, clickable index). Quote Persist with only the fields a quote needs; proposal APIs with mandatory customer details; KYC then customer update before bind; filters for query and load APIs; flows; test guidelines; float balance calculation; error reference.

02_Collections (Postman)
  Protec_UAT2_Agent_Portal_Individual_APIs   Every request has its full body. No scripts; no request reads a value from another. Set the variables by hand (token, dates, quotationNo, policyId, proposalNo, versionSeq, customer details). Folders: auth, party/KYC, vehicle, PCAR, P2W, PCV, GCV (quote to policy), customer payment, float balance, claims, queries and lookups.

03_Presentation
  Protec_Process_Flows_v1.1.pptx   Data, Issuance, Claim and Endorsement flows per product.

04_Excel
  Protec_Process_Flows_v1.1.xlsx, Protec_API_List_Core_vs_Orchestration.xlsx, Issuance_Orchestration_APIs_Endpoints.xlsx, Mandatory_Fields_Quote_and_Proposal.xlsx (new sheets: quote required, proposal mandatory), Vehicle_Fields_Level_Field_Table_Memo.xlsx

05_Testing_Guidelines
  Protec_Test_Guidance_Fields_and_APIs_v1.1.xlsx

Notes
  - Credentials are not included; set username and password in the collection variables.
  - Payment Link is documented from the supplied sample and was not called.
  - Endorsement is in the document only (its body is the loaded policy with the change).
  - Open on UAT2: ADPAPAS rating, claim document types, IFSC data dictionary gap on float prepayment.
