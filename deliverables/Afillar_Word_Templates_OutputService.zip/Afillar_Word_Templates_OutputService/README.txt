Afillar Insurance - Application form and Policy certificate templates (Word, Output Service tag format)
Built on the two reference files (PA_POLICY_WITH_WITHOUT_TTD_SCHEDULE_EN and PA_without_TTD_ApplicationForm_SCHEDULE_EN):
same layout, same <<PolicyObject.path|alias>> tags, same <<Fragment_BeneficiaryList[]|...>> ... <<EndFragment>> loop.

FILES  (22): one Application and one Policy per product variant, named UP_<PRODUCT>_<SUBCODE>_{APPLICATION|POLICY}_EN.docx
  UPPA001 sub 1 (with TTD), sub 2 (without TTD) | TL001 sub 1 (with travel), sub 2 | FP001 | HC001 | CI001 sub 1/2/3 | LP001 | DH001
  Use the file name (without .docx) as the TemplateName in table UP_DocTemplate for that ProductCode + ProductSubcode.

WHY ONE FILE PER VARIANT - coverage index
  The reference reads sums insured by position: PolicyCoverageList[n].SumInsured. The position is the order the platform stores the
  coverages, and it is different for every variant. The indexes below were read from policies issued in MC for every plan:
  UPPA001 sub 1: ACD[1], PTD[2], PPD[3], TTD[4], HCB[5], REX[0]
  UPPA001 sub 2: ACD[0], PTD[1], PPD[2], HCB[3], REX[4]
  TL001 sub 1: DTH[0], PTD[1], PPD[2], TRV[3], REX[4]
  TL001 sub 2: DTH[0], PTD[1], PPD[2], REX[3]
  FP001 sub 1: FCC[0]
  HC001 sub 1: HCB[0]
  CI001 sub 1: CIB[0]
  CI001 sub 2: CIB[0]
  CI001 sub 3: CIB[0]
  LP001 sub 1: DTH[0], PTD[1], PPD[2]
  DH001 sub 1: DTH[0], AME[1], RHE[2], REP[3]

  The reference file's indexes (Death[3], PTD[2], PPD[5], TTD[1], Hospital cash[0], Repatriation[4]) belong to the PA001 product; with
  UPPA001 they would print the wrong amounts, so they were re-pointed.

OTHER PATHS CHANGED FROM THE REFERENCE (checked on live MC policy objects; all 456 data tags resolve to a value; the other 13 are the beneficiary loop markers)
  - Premium: the reference uses ...PlanList[0].DuePremium; in UPONLY that field is not filled. The premium is at
    PolicyObject.PolicyLobList[0].PolicyRiskList[0].DuePremium.
  - Application Date uses PolicyObject.ApplyDate (the reference used EffectiveDate).
  - Payment frequency uses PolicyObject.PremiumModeCode_CodeDesc (Annual / Single / Monthly Premium) instead of fixed words.
  - Period of cover uses PolicyObject.PolicyTerm (Year(s); Life Protect: Month(s)).
  - Policy holder name = insured name (the platform object has no separate holder name).

CORRECTED IN THE REFERENCE TEXT
  - Application form: Arabic of 'Application No' and 'Application Date' said 'certificate number' / 'commencement date'.
  - Corrupted Arabic characters in the application form headings, the beneficiary headings and the premium label, and the typo
    'ssssPremium'; reversed words in the PTD / PPD rows of the benefits table.
  - Policy: the TTD row had the PPD Arabic wording.
  - Benefit names now come from table UP_BenefitText; fixed limits written in the old benefit text ('TTD 50 per week', 'hospital cash 10 per day')
    were removed because the limits differ per plan - the amount is printed from the policy.

PRODUCT NOTES
  - Beneficiary block: Personal Accident, Term Life, Life Protect (policy and application) and Critical Illness (application only), as in the client forms.
  - Term Life with Travel: 'Annual Family Travel' is printed as Included.
  - Domestic Helper: the 'Administration expenses' line stays as fixed text (OMR 500); the platform has no coverage for it.
  - Term Life and Critical Illness applications: the Health and Lifestyle Questionnaire is added on a last page as text.
  - Life Protect: no Word form exists from the client (PDF only). Certificate and application were built from the Term Life documents
    with the Life Protect wording; the PDF's health questionnaire and standing-instruction pages are not included.
  - The insurer is still named 'Arabia Falcon Insurance SAOG' in the footer and signature, as in the client forms; replace it with
    Afillar Insurance Company if that is the insurer of record.

IMPORTANT - THESE FILES NEED A CODE CHANGE BEFORE THEY PRINT
  The current /up/doc_generation sends the print service its own flattened data (PolicyHolderName, PremiumTextEn, ...), not the platform policy
  object. These templates read PolicyObject.<...>, so print_data must be {"PolicyObject": <the loaded policy>}. Until that is changed in
  UPDocService / UPDocBuilder, the HTML templates remain the ones that work.

CHECKED
  Every tag was resolved against policy objects loaded from MC for all 7 products. Layout was rendered with LibreOffice and compared with the reference
  (tags show long here; real values are short). Not opened in Microsoft Word.
