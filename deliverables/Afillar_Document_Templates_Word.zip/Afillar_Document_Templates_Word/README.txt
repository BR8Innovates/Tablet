Afillar Insurance - Application form and Policy certificate templates, Word format

14 files: UP_<PRODUCT>_APPLICATION_EN.docx and UP_<PRODUCT>_POLICY_EN.docx for UPPA001, TL001, FP001, HC001, CI001, LP001, DH001.
They carry the same content, tables, bilingual (English / Arabic) layout, logo, stamp and footer banner as the HTML templates in Afillar_Document_Templates.zip.

- {{Field}} are the merge fields the system fills in (e.g. {{PolicyNo}}, {{InsuredName}}, {{PremiumTextEn}}). Keep them exactly as written.
- {{#each Coverages}} ... {{/each}} in the application form marks the benefit row that repeats once per coverage.
- Arabic cells are right-to-left paragraphs.
- The platform renders the HTML templates, not Word. Word is the editing master: tell us the changes and they are carried back to the HTML (or send the edited Word and it is converted back).
- The insurer name in the wording (Arabia Falcon Insurance SAOG) comes from the reference forms; confirm or replace it with Afillar Insurance Company.
- Generated from the HTML by html_to_docx.py. Layout was checked structurally (every text and image is present); it has not been visually compared in Word.
