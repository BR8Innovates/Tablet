Afillar Insurance - Application form and Policy certificate templates, Word format (v2, alignment checked)

14 files: UP_<PRODUCT>_APPLICATION_EN.docx and UP_<PRODUCT>_POLICY_EN.docx for UPPA001, TL001, FP001, HC001, CI001, LP001, DH001.
Same content, tables, bilingual (English / Arabic) layout, logo, stamp and footer banner as the HTML templates in Afillar_Document_Templates.zip.

- {{Field}} are the merge fields the system fills in. Keep them exactly as written.
- {{#each ...}} / {{/each}} (small grey text in the first cell) mark the row that repeats once per coverage / beneficiary.
- Arabic cells are right-to-left, Arial font (Arial is on every Windows and Mac machine).
- Word is the editing master: the platform renders the HTML templates. Send changes back and they are carried into the HTML.
- The insurer name in the wording (Arabia Falcon Insurance SAOG) comes from the reference forms; confirm or replace with Afillar Insurance Company.
- Checked by rendering every file to PDF and comparing with the HTML layout (columns, borders, Arabic alignment, signature blocks, page counts). Open in Word to confirm on your machine; fonts differ slightly between systems.
