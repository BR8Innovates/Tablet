import os,json,sys,time
B=os.environ["B"]; src=open(B+"/ref_flow.py").read().split("def run(tag):")[0]; ns={}; exec(src,ns)
tag=sys.argv[1]; code,sub=tag.split("_"); plan=sys.argv[2] if len(sys.argv)>2 else "1"
sample=json.load(open(f"{B}/samples/req/{tag}_proposal.json"))
gp=ns["tpl"]("Get Plans"); gp["ProductCode"]=code; gp["ProductSubcode"]=sub; gp["PolicyLobList"][0]["ProductCode"]=code
st,r=ns["call"]("POST","/up/get-plans",ns["concrete"](gp,{"applicationNo":"x"}))
pl={p["PlanId"]:p for p in r["PolicyLobList"][0]["PolicyRiskList"][0]["PlanList"]}
body=ns["build"](tag,plan,pl,sample)
json.dump(ns["concrete"](body,{"applicationNo":str(int(time.time()*1000))}),open(f"{B}/payloads/req_{tag}.json","w")); print("ok",tag)
