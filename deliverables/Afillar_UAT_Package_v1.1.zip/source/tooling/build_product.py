#!/usr/bin/env python3
"""Build one Uponly-style product (tech + market) in the current gateway tenant.
Usage: build_product.py <spec.json> <step>
steps: tech | tree | fields | codetables | market | all
Env: B (build dir), GW, TOK
"""
import json, os, subprocess, sys, tempfile

B = os.environ["B"]; GW = os.environ["GW"]; TOK = os.environ["TOK"]
SK = "/tmp/insuremo/insuremo-gi-product-config/scripts"
PC = ["python3", f"{SK}/product_create.py", "--gateway", GW, "--token", TOK, "--workspace", B + "/ws"]
PF = ["python3", f"{SK}/policy_field.py", "--gateway", GW, "--token", TOK, "--workspace", B + "/ws"]
MP = ["python3", f"{SK}/mp_inherit_tree.py", "--gateway", GW, "--token", TOK]

FIELDS = json.load(open(B + "/fields_created.json"))["ids"]

COMP_FIELDS = {
    "lob": ["APPLICATIONNO", "APPLYDATE", "BRANCHCODE", "CIFNUMBER", "DISCOUNTAMOUNT", "STAFFID", "USERNAME",
            "PLANID", "POLICYTERM", "PREMIUMMODECODE", "PRODUCTSUBCODE"],
    "risk": ["INSUREDNAME", "GENDER", "SALUTATION", "RESIDENTSTATUS"],
    "plan": ["PLANID", "PLANNAME", "DUEPREMIUM", "COMMISSION"],
    "beneficiary": ["BENEFICARYNAME", "BENEFICARYSEQUENCE", "RELATIONSHIPCODE", "SHARE"],
    "coverage": ["COVERAGECODE", "STANDARDGROSSPREMIUM"],
}
# (component, FieldName, code table)
CODETABLES = [
    ("lob", "BranchCode", "BranchCode"), ("lob", "PlanId", "Plan"), ("lob", "PremiumModeCode", "PremiumMode"),
    ("risk", "Gender", "GenderCode"), ("risk", "Salutation", "Salutation"), ("risk", "ResidentStatus", "ResidentStatus"),
    ("plan", "PlanId", "Plan"), ("beneficiary", "RelationshipCode", "Relationship"),
]


def run(cmd, ok_fail=False):
    r = subprocess.run(cmd, capture_output=True, text=True)
    out = (r.stdout or "") + (r.stderr or "")
    if not ok_fail and ('"status": "error"' in out):
        print("ERROR:", out[-400:]); sys.exit(1)
    return out


def jload(s):
    i = s.find("{"); j = s.find("[")
    if i < 0 or (0 <= j < i): i = j
    return json.loads(s[i:])


def tree(pid):
    return jload(run(PC + ["tree-runtime", "--product-id", str(pid)]))


def walk(n, f, parent=None):
    for c in n.get("ChildProductTreeNodeList") or []:
        f(c, parent); walk(c, f, c)


def product_ids(code):
    out = run(["imo", "config", "product", "list", "--profile", "portal:uponly", "--code", code, "--json"])
    for x in json.loads(out):
        p = x["Product"]
        if p["BusinessCode"] == code:
            return p["ProductId"]
    return None


def write(obj, name):
    p = f"{B}/payloads/{name}.json"; json.dump(obj, open(p, "w")); return p


def step_tech(spec):
    code = spec["code"] + "_TECH"
    if product_ids(code):
        print("tech exists", code); return
    body = {"ProductMaster": {"@type": "ProductMaster-ProductMaster", "ProductCode": code,
                              "ProductName": spec["name"], "ProductLineId": -3},
            "Product": {"@type": "Product-Product", "StartDate": "2000-01-01", "EndDate": "2099-12-31",
                        "ProductRuntimeWithoutField": "Y", "IsInsuredGroup": "N", "HasPlan": "N",
                        "EffectiveFlag": "Y", "PolicyType": "01", "IsReleased": "N"}}
    run(PC + ["create-tech", "--body-file", write(body, code), "--confirm"])
    print("created", code, product_ids(code))


def add_el(pid, parent, el, tag):
    run(PC + ["create-product-element", "--product-id", str(pid), "--parent-element-id", str(parent),
              "--body-file", write(el, tag), "--confirm"])


def find(pid, code):
    hit = {}
    def f(c, p):
        if c.get("ProductElementCode") == code: hit.update(c)
    walk(tree(pid), f)
    return hit or None


def step_tree(spec):
    pid = product_ids(spec["code"] + "_TECH")
    t = tree(pid); lob = t["ChildProductTreeNodeList"][0]
    if not find(pid, "R00001"):
        add_el(pid, lob["ProductElementId"], {"@type": "ProductElement-ProductRisk", "DefinitionSuperObjectName": "PersonInsured",
               "DiscriminatorValue": -2, "ProductId": pid, "EffectiveFlag": "Y", "ProductElementCode": "R00001",
               "ProductElementName": "Person Insured", "InsuredCategory": 2}, "risk")
    risk = find(pid, "R00001")
    for code, name in (("PLAN", "Plan"), ("BENEFICIARY", "Beneficiary")):
        if not find(pid, code):
            add_el(pid, risk["ProductElementId"], {"@type": "ProductElement-ProductSchedule", "DefinitionSuperObjectName": "PolicyEntity",
                   "DiscriminatorValue": -7, "ProductId": pid, "EffectiveFlag": "Y", "ProductElementCode": code,
                   "ProductElementName": name, "ScheduleCategory": "PolicyEntity", "CustomModelName": name}, "sch_" + code)
    plan = find(pid, "PLAN")
    for ccode, cname in spec["coverages"]:
        if not find(pid, ccode):
            add_el(pid, plan["ProductElementId"], {"@type": "ProductElement-ProductCoverage", "DefinitionSuperObjectName": "PolicyCoverage",
                   "DiscriminatorValue": -1, "ProductId": pid, "EffectiveFlag": "Y", "ProductElementCode": ccode,
                   "ProductElementName": cname, "CoverageLayer": "1"}, "cov_" + ccode)
    print("tree ok", pid)


def comp_nodes(pid, spec):
    t = tree(pid); lob = t["ChildProductTreeNodeList"][0]
    first_cov = find(pid, spec["coverages"][0][0])
    return {"lob": lob, "risk": find(pid, "R00001"), "plan": find(pid, "PLAN"),
            "beneficiary": find(pid, "BENEFICIARY"), "coverage": first_cov}


def step_fields(spec):
    pid = product_ids(spec["code"] + "_TECH"); nodes = comp_nodes(pid, spec)
    for comp, codes in COMP_FIELDS.items():
        ids = [str(FIELDS[c]) for c in codes]
        out = run(PC + ["attach-field", "--field-element-id", *ids, "--product-id", str(pid),
                        "--target-element-id", str(nodes[comp]["ProductElementId"]), "--confirm"], ok_fail=True)
        print("attach", comp, "->", out.strip().replace("\n", " ")[:120])


def step_codetables(spec):
    pid = product_ids(spec["code"] + "_TECH"); nodes = comp_nodes(pid, spec)
    for comp, fname, ct in CODETABLES:
        obj = nodes[comp]["DefinitionObjectId"]
        out = run(PF + ["find-binding", "--object-id", str(obj), "--field-name", fname], ok_fail=True)
        try: bid = jload(out).get("BindingId") or jload(out).get("bindingId")
        except Exception: bid = None
        if not bid: print("no binding", comp, fname, out[-120:]); continue
        cur = jload(run(PF + ["load-binding", "--binding-id", str(bid)]))
        if cur.get("CodeTableName") == ct: print("ct ok", comp, fname); continue
        keep = ["BindingId", "FieldName", "FieldType", "FieldLabelEn", "FieldCommentsEn", "IsDeprecated", "IsFixed",
                "IsIndexed", "IsInput", "IsMandatory", "IsTemp", "IsUnique", "RecordUsage", "BusinessObjectId"]
        b = {k: cur[k] for k in keep if k in cur}; b["CodeTableName"] = ct
        b.setdefault("BusinessObjectId", obj); b.setdefault("FieldLabelEn", fname)
        for k in ("IsIndexed", "IsUnique", "IsFixed", "IsDeprecated", "IsMandatory"): b.setdefault(k, "N")
        b.setdefault("IsInput", "Y")
        body = {"ContextTypeId": "5", "ContextId": str(pid), "BusinessFieldBinding": b}
        out = run(PF + ["--body-file", write(body, f"upd_{comp}_{fname}"), "--confirm", "update-binding", "--binding-id", str(bid)], ok_fail=True)
        print("ct", comp, fname, "->", ct, out.strip().replace("\n", " ")[:80])


def step_market(spec):
    tcode = spec["code"] + "_TECH"; mcode = spec["code"]
    tid = product_ids(tcode)
    if not product_ids(mcode):
        tm = [x for x in json.loads(run(["imo", "config", "product", "list", "--profile", "portal:uponly", "--code", tcode, "--json"]))
              if x["Product"]["BusinessCode"] == tcode][0]["Product"]
        body = {"ProductMaster": {"@type": "ProductMaster-ProductMaster", "ProductCode": mcode, "ProductName": spec["name"],
                                  "ProductLineId": -3, "FromProductMasterId": tm["ProductMasterId"]},
                "Product": {"@type": "Product-Product", "FromProductId": tid, "StartDate": "2000-01-01", "EndDate": "2099-12-31",
                            "ProductRuntimeWithoutField": "Y", "IsInsuredGroup": "N", "HasPlan": "N", "EffectiveFlag": "Y",
                            "PolicyType": "01", "IsReleased": "N"}}
        run(PC + ["create-market", "--body-file", write(body, mcode), "--confirm"])
        print("created market", mcode, product_ids(mcode))
    mid = product_ids(mcode)
    t = tree(mid)
    lobn = (t.get("ChildProductTreeNodeList") or [{}])[0]
    if not (lobn.get("ChildProductTreeNodeList") or []):
        out = run(MP + ["inherit", "--product-id", str(mid), "--confirm"], ok_fail=True)
        print("inherit", out.strip().replace("\n", " ")[:160])
    else:
        print("market tree already inherited")


POLICY_FIELDS = [("ApplicationNo", -4, None), ("ApplyDate", -5, None), ("BranchCode", -4, "BranchCode"), ("DiscountAmount", -3, None),
                 ("StaffId", -4, None), ("UserName", -4, None), ("PlanId", -4, "Plan"), ("PolicyTerm", -4, None),
                 ("PremiumModeCode", -4, "PremiumMode"), ("ProductSubcode", -4, None)]


POLICY_FIELDS += [("PaymentLGCode", -4, None), ("PaymentLCCode", -4, None), ("PaymentDebitAccountNo", -4, None),
                  ("PaymentDebitRefNo", -4, None), ("PaymentIsInstallment", -4, None), ("PaymentTransactionDate", -5, None),
                  ("EMIRate", -3, None), ("InternalEMIAmt", -3, None)]


def step_policyfields(spec):
    pid = product_ids(spec["code"] + "_TECH")
    t = tree(pid); obj = t["DefinitionObjectId"]
    for fname, ftype, ct in POLICY_FIELDS:
        b = {"BusinessObjectId": obj, "FieldType": ftype, "FieldName": fname, "FieldCommentsEn": fname, "FieldLabelEn": fname,
             "IsFixed": "N", "IsDeprecated": "N", "IsMandatory": "N", "IsTemp": "N", "IsUnique": "N", "IsIndexed": "N", "IsInput": "Y"}
        if ct: b["CodeTableName"] = ct
        body = {"ContextTypeId": "5", "ContextId": str(pid), "BusinessFieldBinding": b}
        out = run(PF + ["--body-file", write(body, f"pol_{spec['code']}_{fname}"), "--confirm", "create-binding"], ok_fail=True)
        print("policy field", fname, "->", out.strip().replace("\n", " ")[:110])


def step_persist(spec):
    """Component-path fields are created as temporary (IsTemp=Y, not stored). Make them persisted like Uponly's."""
    fmap = {c: fn for c, fn, t, l, ct in json.load(open(B + "/fields_created.json"))["fields"]}
    fmap["PLANNAME"] = "PlanName"
    pid = product_ids(spec["code"] + "_TECH"); nodes = comp_nodes(pid, spec)
    for comp, codes in COMP_FIELDS.items():
        if comp == "lob":
            continue
        obj = nodes[comp]["DefinitionObjectId"]
        for c in codes:
            fname = fmap[c]
            out = run(PF + ["find-binding", "--object-id", str(obj), "--field-name", fname], ok_fail=True)
            try: bid = jload(out).get("BindingId") or jload(out).get("bindingId")
            except Exception: bid = None
            if not bid: print("no binding", comp, fname, out[-150:]); continue
            cur = jload(run(PF + ["load-binding", "--binding-id", str(bid)]))
            if cur.get("IsTemp") == "N": print("persisted already", comp, fname); continue
            keep = ["BindingId", "FieldName", "FieldType", "FieldLabelEn", "FieldCommentsEn", "IsDeprecated", "IsFixed",
                    "IsIndexed", "IsInput", "IsMandatory", "IsUnique", "RecordUsage", "BusinessObjectId", "CodeTableName"]
            b = {k: cur[k] for k in keep if k in cur}; b["IsTemp"] = "N"
            b.setdefault("BusinessObjectId", obj); b.setdefault("FieldLabelEn", fname)
            for k in ("IsIndexed", "IsUnique", "IsFixed", "IsDeprecated", "IsMandatory"): b.setdefault(k, "N")
            b.setdefault("IsInput", "Y")
            body = {"ContextTypeId": "5", "ContextId": str(pid), "BusinessFieldBinding": b}
            out = run(PF + ["--body-file", write(body, f"persist_{comp}_{fname}"), "--confirm", "update-binding", "--binding-id", str(bid)], ok_fail=True)
            print("persist", spec["code"], comp, fname, "ok" if "BindingId" in out else out.strip()[:100])


STEPS = {"persist": step_persist, "policyfields": step_policyfields, "tech": step_tech, "tree": step_tree, "fields": step_fields, "codetables": step_codetables, "market": step_market}

if __name__ == "__main__":
    spec = json.load(open(sys.argv[1])); step = sys.argv[2]
    for s in (["tech", "tree", "fields", "codetables", "market"] if step == "all" else [step]):
        print("##", spec["code"], s); STEPS[s](spec)
