"""One structured specification per API (inputs with M / O / C, outputs with A / C), shared by the workbook and the specification document.
Inputs come from the deployed validation rules plus the conditions enforced by the validator code; outputs from all recorded responses (52 plan flows and the common samples)."""
import json, os, re, glob, collections
import model_data as md
B = os.environ["B"]
cts = md.code_tables(); rules = md.field_rules()
STEP_API = {"get-plans": "UPGetPlans", "proposal": "UPProposal", "proposal-for-reject": "UPProposal", "update-proposal": "UPUpdateProposal", "issue": "UPIssue",
            "load-proposal": "UPLoadPolicy", "load-policy": "UPLoadPolicy", "load-cancelled": "UPLoadPolicy", "proposal-reject": "UPProposalReject", "doc-policy": "UPDocGeneration",
            "doc-application": "UPDocGeneration", "cancel-check": "UPCancelCheck", "cancel-approve": "UPCancelApprove"}
URL = {a[1]: a[3] for a in md.APIS}; METHOD = {a[1]: a[2] for a in md.APIS}
DESC = {
 "CarrierCode": "Insurer (carrier) code of the product, for example AFIC; optional in requests, when sent it must be the insurer of the product (see UP_Carrier)", "CarrierName": "Insurer (carrier) name, from the insurer table",
 "ChannelCode": "Channel code assigned to the partner (Sohar Bank = SOHAR). Records can only be used by the channel that created them", "ProductCode": "Product code (UPPA001, TL001, FP001, HC001, CI001, LP001, DH001)",
 "ProductSubcode": "Product variant (see section 4)", "PlanId": "Plan id of the product variant", "PremiumModeCode": "Premium mode, from PremiumMode", "PolicyTerm": "Policy term in years",
 "ApplicationNo": "Partner's own unique application reference", "EffectiveDate": "Policy start date (YYYY-MM-DD)", "ExpiryDate": "Policy end date (YYYY-MM-DDT23:59:59)", "ApplyDate": "Application date (YYYY-MM-DD)",
 "BranchCode": "Branch, from BranchCode", "UserName": "User who captures the application", "StaffId": "Staff id of the user", "DiscountAmount": "Discount amount requested", "OrgCode": "Issuing branch code; the service sends 1 when it is omitted",
 "DateOfBirth": "Insured date of birth (YYYY-MM-DD)", "InsuredName": "Insured full name", "IdNo": "ID or passport number", "IdType": "ID type, from IdType", "Gender": "Gender, from GenderCode", "Salutation": "Salutation, from Salutation",
 "ResidentStatus": "Resident status, from ResidentStatus", "MaritalStatus": "Marital status, from InsMaritalStatus", "Mobile": "Mobile number (returned masked)", "Email": "E-mail address", "Address": "Communication address",
 "PostCode": "PO box / post code", "MonthSalaryIncome": "Monthly salary income", "ProductElementCode": "Risk element code", "CIFNumber": "Customer CIF number", "CustomerType": "Customer type, from CustomerType",
 "BeneficaryName": "Beneficiary name", "RelationshipCode": "Relationship of the beneficiary, from Relationship", "BeneficarySequence": "Beneficiary sequence number", "Share": "Beneficiary share in percent",
 "LGCode": "Payment LG code", "LCCode": "Payment LC code", "DebitAccountNo": "Debit account number", "DebitRefNo": "Debit transaction reference number", "TransactionDate": "Payment transaction date (YYYY-MM-DD)",
 "IsInstallment": "Whether the payment is made in instalments (Y / N)", "ProposalNo": "Proposal number", "PolicyNo": "Policy number", "ProposalRejectDesc": "Reason for rejecting the proposal", "DocType": "Application (application form) or Policy (certificate)",
 "PreviewData": "Y returns the print data as JSON instead of a PDF", "CancellationDate": "Requested cancellation date (YYYY-MM-DD) between policy start and expiry", "CancelReason": "Cancellation reason (3 to 200 characters)",
 "RequestNo": "Cancellation request number returned by Cancel Check", "Decision": "APPROVE cancels the policy; REJECT closes the request and keeps the policy in force", "DataTableName": "Name of the master table",
 "Id": "Record id to read a single record", "FromDate": "Start of the period (YYYY-MM-DD)", "ToDate": "End of the period (YYYY-MM-DD)", "PageNo": "Page number, from 1", "PageSize": "Rows per page, 1 to 50",
 "SearchType": "Policy or Proposal", "OutputFormat": "EXCEL (default) or JSON", "policyNo": "Policy number", "proposalNo": "Proposal number",
 # outputs
 "DuePremium": "Premium payable for the plan (annual premium, or single premium for the term)", "Commission": "Commission for the plan", "CommissionRate": "Commission rate", "PlanName": "Plan name",
 "CoverageCode": "Cover code", "CoverageDescription": "Cover description", "SumInsured": "Sum insured of the cover", "PolicyStatus": "Policy status", "ProposalStatus": "Proposal status", "IssueDate": "Date and time of issue",
 "Code": "Status code (2 = in force, 3 = cancelled)", "Description": "Status description", "RequestStatus": "PENDING, APPROVED or REJECTED", "RequestExists": "Y when the request already existed", "RefundPremium": "Refund premium",
 "EndorsementNo": "Number of the endorsement that cancelled the policy", "CancellationType": "FREE_LOOK or PRO_RATA", "RefundPercent": "Refund percentage applied", "Premium": "Premium of the policy", "PolicyPeriodDays": "Days of the policy period",
 "DaysSinceCommencement": "Days from the start date to the cancellation date", "UnexpiredDays": "Days not yet expired at the cancellation date", "ProRataPremium": "Pro-rata premium of the unexpired days", "FreeLookDays": "Free look days of the product",
 "message": "Confirmation message", "status": "SUCCESS", "Records": "List of records", "Total": "Total number of records", "PageTotalPremium": "Premium total of the page", "PageTotalCommission": "Commission total of the page",
 "Source": "Where the commission was taken from", "CommissionRaw": "Commission, unrounded", "PremiumRaw": "Premium, unrounded", "CommencementDate": "Policy commencement date", "CarrierCode": "Carrier code",
 "InstallmentType": "Instalment type", "PolicyStatusForDisplay": "Status for display", "PolicyId": "Platform policy id",
}
OUT_COND = {("UPProposal", "PolicyNo"): "after issue", ("UPLoadPolicy", "PolicyNo"): "only for an issued policy", ("UPLoadPolicy", "IssueDate"): "only for an issued policy",
            ("UPIssue", "PolicyNo"): None, ("UPCancelApprove", "RefundPremium"): "only when the request is approved", ("UPCancelApprove", "EndorsementNo"): "only when the request is approved"}
def dtype(v):
    if isinstance(v, bool): return "String"
    if isinstance(v, int): return "Integer"
    if isinstance(v, float): return "Double"
    if isinstance(v, list): return "Array"
    if isinstance(v, dict): return "Object"
    if isinstance(v, str) and re.match(r"^\d{4}-\d{2}-\d{2}(T[\d:.]+)?$", v): return "Date"
    return "String"
EXTRA_TECH = {"ProductElementId", "ProductLobId", "IsFinalLevelCt", "InstallmentPeriodCount", "IsFinalLevelCt"}
PARENT = {"PolicyLobList": "PolicyLob", "PolicyRiskList": "PolicyRisk", "PlanList": "PlanList", "PolicyCoverageList": "PolicyCoverage", "BeneficiaryList": "BeneficiaryList",
          "PolicyCustomerList": "PolicyCustomer", "PolicyPaymentInfoList": "PolicyPaymentInfoList"}
def flat(o, parent, out):
    if isinstance(o, dict):
        for k, v in o.items():
            if k in md.TECH or k in EXTRA_TECH or k.endswith("_CodeDesc") or k.startswith("@"): continue
            if k == "PolicyStatus" and parent not in ("Policy", "PolicyStatus", "Response") and not isinstance(v, dict): continue
            if isinstance(v, list) and v and isinstance(v[0], dict): flat(v[0], PARENT.get(k, k), out)
            elif isinstance(v, dict): flat(v, k, out)
            elif isinstance(v, list): out.append((parent, k, "Array", "[...]"))
            else: out.append((parent, k, dtype(v), v))
def label(n): return re.sub(r"(?<=[a-z0-9])(?=[A-Z])", " ", n)
# ------------------------------------------------------------------ inputs
COND = {  # (api, field leaf) -> (required, condition text)
 ("UPGetPlans", "PremiumModeCode"): ("C", "Mandatory where the plans of the variant differ by premium mode (UPPA001, TL001, CI001, LP001); see the Product sheet"),
 ("UPGetPlans", "PolicyTerm"): ("C", "Single premium: between the minimum and maximum term of the product; annual and monthly premium: 1 year"),
 ("UPProposal", "PremiumModeCode"): ("C", "Mandatory where the plans of the variant differ by premium mode; must be a mode allowed for the product"),
 ("UPUpdateProposal", "PremiumModeCode"): ("C", "Mandatory where the plans of the variant differ by premium mode; must be a mode allowed for the product"),
 ("UPProposal", "PolicyTerm"): ("M", "Single premium: between the minimum and maximum term of the product; annual and monthly premium: 1 year"),
 ("UPUpdateProposal", "PolicyTerm"): ("M", "Single premium: between the minimum and maximum term of the product; annual and monthly premium: 1 year"),
 ("UPProposal", "Share"): ("C", "Mandatory for every beneficiary that is sent; the shares of one insured must total 100"),
 ("UPUpdateProposal", "Share"): ("C", "Mandatory for every beneficiary that is sent; the shares of one insured must total 100"),
 ("UPLoadPolicy", "policyNo"): ("C", "Send either policyNo or proposalNo, not both"), ("UPLoadPolicy", "proposalNo"): ("C", "Send either policyNo or proposalNo, not both"),
 ("UPCancelCheck", "PolicyNo"): ("C", "Send either PolicyNo or ProposalNo, not both"), ("UPCancelCheck", "ProposalNo"): ("C", "Send either PolicyNo or ProposalNo, not both"),
 ("UPCancelApprove", "PolicyNo"): ("C", "Send either PolicyNo or ProposalNo, not both"), ("UPCancelApprove", "ProposalNo"): ("C", "Send either PolicyNo or ProposalNo, not both"),
 ("UPCommissionQuery", "PolicyNo"): ("C", "Query by policy: send PolicyNo, or ProductCode (+ ProductSubcode / PlanId), or FromDate and ToDate"),
 ("UPCommissionQuery", "ProductCode"): ("C", "Query by plan configuration or period: send PolicyNo, or ProductCode (+ ProductSubcode / PlanId), or FromDate and ToDate"),
 ("UPCommissionQuery", "FromDate"): ("C", "Query for a period: FromDate and ToDate must be sent together"), ("UPCommissionQuery", "ToDate"): ("C", "Query for a period: FromDate and ToDate must be sent together; not before FromDate"),
 ("UPCommissionQuery", "ProductSubcode"): ("O", "Used together with ProductCode"), ("UPCommissionQuery", "PlanId"): ("O", "Used together with ProductCode"),
 ("UPFeedFile", "EffectiveDate"): ("M", "From and to effective date (period of the feed file); the to date is not before the from date"),
}
MODEL_BY_API = {"UPCancelCheck": "CancelRequest", "UPCancelApprove": "CancelRequest", "UPCommissionQuery": "CommissionQuery", "UPFeedFile": "FeedFileRequest", "UPListMasterTable": "MasterTableRequest",
                "UPDocGeneration": "DocumentRequest", "UPApplicationDocGeneration": "DocumentRequest", "UPLoadPolicy": "Query"}
def allowed(r):
    ct = r.get("CodeTable")
    if r.get("EnumValues"): return r["EnumValues"].replace(",", ", ")
    if ct == "UP_Channel": return "SOHAR"
    if ct and ct in cts: return "; ".join(f"{c} = {d}" for c, d in cts[ct])
    return ""
def limits(r):
    b = []
    if r.get("MinLength") or r.get("MaxLength"): b.append(f"{r.get('MinLength', 0)}-{r.get('MaxLength', '')} characters")
    if r.get("MinValue") is not None or r.get("MaxValue") is not None: b.append(f"{r.get('MinValue', '')} to {r.get('MaxValue', '')}")
    if r.get("Pattern"): b.append("format " + r["Pattern"])
    return "; ".join(b)
def ptype(r): return {"integer": "Integer", "date": "Date", "decimal": "Double", "enum": "String"}.get(r["DataType"], "String")
def inputs(api):
    out = []; seen = set()
    sample = None
    for r in rules:
        if r["Api"] != api: continue
        path = re.sub(r"\[\d+\]", "", r["Path"]); parts = path.split("."); leaf = parts[-1]
        if len(parts) > 1: parent = md.model_of(r["Path"])[0] if api in ("UPGetPlans", "UPProposal", "UPUpdateProposal") else parts[0]
        else: parent = MODEL_BY_API.get(api, "Policy")
        if api in MODEL_BY_API and leaf in ("ChannelCode",) and api != "UPLoadPolicy": parent = MODEL_BY_API[api]
        req = "M" if r["Required"] == "Y" else "O"; cond = ""
        if r.get("WhenPath"): req, cond = "C", f"Mandatory when {r['WhenPath']} = {r['WhenValue']}"
        if (api, leaf) in COND: req, cond = COND[(api, leaf)]
        if api == "UPUpdateProposal" and leaf == "ProposalNo": req, cond = "M", "Number of the open proposal to update"
        out.append(dict(parent=parent, name=leaf, path=r["Path"], dtype=ptype(r), req=req, cond=cond, allowed=allowed(r), limits=limits(r), example="", desc=DESC.get(leaf, r["Label"])))
        seen.add((parent, leaf))
    # fields the API accepts without a validation rule (optional)
    exs, _v = md.examples(); stepkey = {"UPGetPlans": "get-plans"}.get(api)
    if stepkey and exs.get(stepkey, {}).get("request"):
        extra = []; flat(exs[stepkey]["request"], "Policy", extra)
        for parent, k, t, v in extra:
            if (parent, k) in seen or k in ("PolicyStatus",): continue
            seen.add((parent, k)); out.append(dict(parent=parent, name=k, path=k, dtype=t, req="O", cond="", allowed="", limits="", example=str(v)[:40], desc=DESC.get(k, label(k))))
    if api in ("UPProposal", "UPUpdateProposal"):
        out.append(dict(parent="Policy", name="OrgCode", path="OrgCode", dtype="String", req="O", cond="The service sends 1 when it is omitted", allowed="1", limits="1-10 characters", example="1", desc=DESC["OrgCode"]))
        if api == "UPProposal": out.append(dict(parent="Policy", name="ProposalNo", path="ProposalNo", dtype="String", req="X", cond="Must not be sent when creating a proposal (use Update Proposal)", allowed="", limits="", example="", desc="Proposal number"))
    return out
# ------------------------------------------------------------------ outputs
def collect_outputs():
    per = collections.defaultdict(lambda: collections.defaultdict(lambda: dict(n=0, type="String", ex="")))
    total = collections.Counter()
    def add(api, body, tag=None):
        if not isinstance(body, dict) or body.get("_pdf") or body.get("_xlsx"): return
        total[api] += 1; out = []; flat(body, "Policy" if api in ("UPGetPlans", "UPProposal", "UPUpdateProposal", "UPIssue", "UPLoadPolicy") else "Response", out)
        seen = set()
        for parent, k, t, v in out:
            key = (parent, k)
            if key in seen: continue
            seen.add(key); d = per[api][key]; d["n"] += 1; d["type"] = t; d["ex"] = d["ex"] or str(v)[:60]
    for d in glob.glob(B + "/samples/ref/*_P*"):
        for f in glob.glob(d + "/[0-9]*.json"):
            st = os.path.basename(f)[3:-5]; api = STEP_API.get(st)
            if not api: continue
            j = json.load(open(f));
            if j["response"]["status"] == 200: add(api, j["response"]["body"])
    return per, total
def outputs(api, per, total):
    rows = []
    if api in ("UPDocGeneration", "UPApplicationDocGeneration"):
        return [dict(parent="Response", name="(file)", dtype="File", req="A", cond="", example="application/pdf", desc="The document as a PDF file; with PreviewData = Y the print data as JSON")]
    if api == "UPFeedFile":
        return [dict(parent="Response", name="(file)", dtype="File", req="A", cond="", example="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", desc="Excel file with one row per policy; JSON when OutputFormat = JSON")]
    items = per.get(api, {}); n = total.get(api, 0)
    for (parent, k), d in items.items():
        req = "A" if (d["n"] == n or k in ("CarrierCode", "CarrierName")) else "C"
        cond = OUT_COND.get((api, k)) or ("" if req == "A" else "Returned when applicable")
        if cond is None: cond = ""
        rows.append(dict(parent=parent, name=k, dtype=d["type"], req=req, cond=cond, example=d["ex"], desc=DESC.get(k, label(k))))
    return rows
def top_outputs(key, tk_list, parent="Response"):
    """Outputs of the common APIs from the top samples, flagged C per query mode."""
    rows = collections.OrderedDict()
    for tk, mode in tk_list:
        j = md.top_examples().get(tk)
        if not j: continue
        body = j["response"]["body"]; items = body if isinstance(body, list) else [body]
        for it in items[:1]:
            if not isinstance(it, dict): continue
            for k, v in it.items():
                if k in md.TECH or k.startswith("@") or k in ("DataTableId", "RecordId", "RecordUsage"): continue
                if isinstance(v, list) and v and isinstance(v[0], dict):
                    for k2, v2 in v[0].items():
                        if k2 in md.TECH: continue
                        r = rows.setdefault(("Records", k2), dict(parent="Records", name=k2, dtype=dtype(v2), modes=set(), example=str(v2)[:60])); r["modes"].add(mode)
                else:
                    r = rows.setdefault((parent, k), dict(parent=parent, name=k, dtype=dtype(v), modes=set(), example=str(v)[:60])); r["modes"].add(mode)
    return rows
TITLES = {"UPGetPlans": "Get Plans", "UPProposal": "Create Proposal", "UPUpdateProposal": "Update Proposal", "UPIssue": "Issue Policy", "UPLoadPolicy": "Load Proposal / Policy", "UPProposalReject": "Reject Proposal",
          "UPDocGeneration": "Policy Documents (PDF)", "UPApplicationDocGeneration": "Application Form (PDF)", "UPCancelCheck": "Cancel Check (Checker)", "UPCancelApprove": "Cancel Approve (Approver)",
          "UPListMasterTable": "Master Data", "UPCommissionQuery": "Commission Query", "UPFeedFile": "Policy Feed File"}
PORDER = ["Policy", "PolicyCustomer", "PolicyLob", "PolicyRisk", "BeneficiaryList", "PolicyPaymentInfoList", "PlanList", "PolicyCoverage"]
def porder(rows):
    idx = {}
    for r in rows: idx.setdefault(r["parent"], len(PORDER) + len(idx) if r["parent"] not in PORDER else PORDER.index(r["parent"]))
    return sorted(rows, key=lambda r: idx[r["parent"]])
def build():
    per, total = collect_outputs(); spec = collections.OrderedDict()
    for key, api, method, path, title, purpose in md.APIS:
        ins = inputs(api); outs = outputs(api, per, total)
        if api == "UPListMasterTable":
            outs = [dict(parent="Response (array)", name=k, dtype="String", req="A", cond="", example=e, desc=dsc) for k, e, dsc in (("Id", "2", "Record id (code)"), ("Description", "Daughter", "Record description"))]
        if api == "UPCommissionQuery":
            rows = top_outputs(key, [("commission_by_policy", "by policy"), ("commission_by_config", "by plan configuration"), ("commission_by_period", "for a period")]); outs = []
            for (p, k), d in rows.items():
                outs.append(dict(parent=d["parent"], name=k, dtype=d["dtype"], req="C", cond="Returned when querying " + " / ".join(sorted(d["modes"])), example=d["example"], desc=DESC.get(k, label(k))))
        spec[api] = dict(key=key, api=api, method=method, path=path, title=TITLES[api], purpose=purpose, inputs=porder(ins), outputs=porder(outs))
    return spec
if __name__ == "__main__":
    s = build()
    for a, v in s.items():
        c = collections.Counter(x["req"] for x in v["inputs"]); o = collections.Counter(x["req"] for x in v["outputs"])
        print(a, dict(c), dict(o))
