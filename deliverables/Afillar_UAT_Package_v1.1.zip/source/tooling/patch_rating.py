import os,json,subprocess,sys
B=os.environ['B']; GW=os.environ['GW']; TOK=os.environ['TOK']
R=["python3","/tmp/insuremo/insuremo-gi-rating-config/scripts/rating_api.py"]
def api(cmd,payload=None,extra=None,confirm=False):
    a=R+[cmd]+(extra or [])+(["--confirm"] if confirm else [])+["--gateway",GW,"--token",TOK]
    r=subprocess.run(a,input=json.dumps(payload) if payload is not None else None,capture_output=True,text=True); o=r.stdout+r.stderr
    try: return json.loads(o[o.index("{"):])
    except Exception: return {"raw":o[-300:]}
OLD1="def prem=plansPrem[0].Premium\n\tdef comm=plansPrem[0].Commission"
NEW1="def pm = Policy().PremiumModeCode.val\n\tdef selRow = plansPrem.find { it.PremiumModeCode != null && it.PremiumModeCode != '' && it.PremiumModeCode == pm } ?: plansPrem[0]\n\tdef prem=selRow.Premium\n\tdef comm=selRow.Commission"
for code in sys.argv[1:]:
    d=api("definition-load",extra=["--code",f"{code}_PREM_CALC"]); vid=d["VersionList"][0]["VersionId"]
    ver=api("version-load",extra=["--version-id",str(vid)])
    for n in ver.get("TopCalcList",[]):
        for st in n["CalculationSteps"]:
            if st["Name"] in("AllPlanPremium","PlanPremium"):
                full=api("step-load",extra=["--step-id",str(st["StepId"])]); fc=full["FormulaContent"]
                if "selRow" in fc: print(code,st["Name"],"already"); continue
                if OLD1 not in fc: print(code,st["Name"],"PATTERN NOT FOUND"); continue
                full["FormulaContent"]=fc.replace(OLD1,NEW1)
                print(code,st["Name"],api("step-save",full,["--mode","update"],True))
