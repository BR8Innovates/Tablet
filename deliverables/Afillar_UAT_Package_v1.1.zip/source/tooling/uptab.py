"""Small helpers to create / extend Uponly data tables (same approach as make_rules.py)."""
import json, os, subprocess
B = os.environ["B"]
S, L, D = -4, -2, -3
def imo(args):
    r = subprocess.run(["imo"] + args + ["--profile", "portal:uponly"], capture_output=True, text=True, cwd="/home/user/Tablet"); return r.stdout + r.stderr
def table(name, cols):
    out = imo(["config", "datatable", "by-name", "--name", name, "--json"])
    try:
        j = json.loads(out); j = j if isinstance(j, list) else [j]
        if j and j[0].get("Name") == name: return j[0]["DataTableId"]
    except Exception: pass
    fields = {}
    for i, (c, t) in enumerate(cols):
        f = {"DataType": t, "Label": c, "Name": c, "Sequence": i}
        if i == 0: f.update({"IsPrimaryKey": "Y", "NotNull": "Y"})
        fields[c] = f
    body = {"CodeTableFlag": "N", "Fields": fields, "GroupId": 127, "IsSmall": "Y", "Name": name, "RecordUsage": 5, "SyncDefinitionOnly": "N"}
    p = f"{B}/tables/def_{name}.json"; json.dump(body, open(p, "w")); imo(["config", "datatable", "create", "--file", p, "--confirm"])
    j = json.loads(imo(["config", "datatable", "by-name", "--name", name, "--json"])); j = j if isinstance(j, list) else [j]
    return j[0]["DataTableId"]
def save(name, tid, rows, first_id, tag):
    recs = []
    for i, r in enumerate(rows):
        rr = {"Id": str(first_id + i), "DataTableId": tid, "RecordUsage": 5}
        rr.update({k: v for k, v in r.items() if v not in ("", None)}); recs.append(rr)
    for i in range(0, len(recs), 40):
        p = f"{B}/tables/r_{tag}_{i}.json"; json.dump(recs[i:i+40], open(p, "w"))
        out = imo(["config", "datatable", "record-batch-save", "--file", p, "--confirm"]); print(" ", name, "batch", i, "ok" if "@pk" in out else out[:200], flush=True)
