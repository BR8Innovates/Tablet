import json, os, collections, time
B = os.environ["B"]; d = json.load(open(B + "/security/results.json")); R = d["results"]
cnt = collections.Counter(r["verdict"] for r in R); cats = collections.OrderedDict()
for r in R: cats.setdefault(r["category"], []).append(r)
md = []; w = md.append
w("# Uponly APIs - Security Probe (VAPT) Results, release 4 (after the security fixes)\n")
w(f"Run: {d['generated']}. Target: uponly tenant, test route `/platform/api-orchestration-test/v1/flow/up/...`, 13 orchestration APIs, authorised testing of our own test tenant with a test channel (SOHAR). Fixtures: proposal `{d['fixture']['proposal']}`, policy `{d['fixture']['policy']}`.\n")
w("## Result\n")
w(f"**{len(R)} live checks: {cnt['PASS']} pass, {cnt['FAIL']} fail, {cnt['INFO']} observations.** The two failures and the observations are platform / gateway behaviour (code review report finding VAPT-05); every defect found in our code by release 3 (VAPT-01 to VAPT-04) is fixed and re-tested below.\n")
w("| Category | Checks | Pass | Fail | Observation |\n|---|---:|---:|---:|---:|")
for c, rs in cats.items(): w(f"| {c} | {len(rs)} | {sum(r['verdict']=='PASS' for r in rs)} | {sum(r['verdict']=='FAIL' for r in rs)} | {sum(r['verdict']=='INFO' for r in rs)} |")
w("")
w("## Method\n")
w("- Black-box requests with the production code path: the same APIs the channels use, a valid bearer token for positive cases, forged tokens for negative cases.\n- Authentication: no header, empty bearer, garbage, truncated, last-character-changed signature, payload edited with the old signature, `alg=none`.\n- Channel isolation (IDOR): every API called with an unregistered, empty and missing `ChannelCode` against a real SOHAR policy.\n- Injection: 14 payload families (SQL, stacked SQL, script, attribute XSS, template and Groovy expressions, OS command, path traversal, NoSQL operator, CRLF, null byte, 5,000 characters, unicode direction override, format string) in a free-text field, the policy number query and the cancel reason.\n- Business-logic tampering: premium, commission, discount, status and policy-number fields supplied by the client; extreme and invalid cancellation dates; case-changed decision; client refund amount; approval replay.\n- Resource abuse: 2 MB body, 3,000-level nesting, huge / negative paging, internal table listing, 40-request burst.\n- HTTP surface: verbs, security headers, server banner, CORS, host / method override headers.\n- Error handling: invalid numbers, wrong JSON types, no stack traces or internals in answers.\n")
w("## Findings (checks that failed)\n")
w("| ID | Check | HTTP | Evidence | Report finding |\n|---|---|---:|---|---|")
ref = {r["id"]: "VAPT-05" for r in R if r["category"].startswith("HTTP surface")}
for r in R:
    if r["verdict"] == "FAIL": w(f"| {r['id']} | {r['title']} | {r['status']} | {r['evidence'][:140].replace('|','/')} | {ref.get(r['id'], '-')} |")
pre = os.path.join(B, "security", "results_pre_fix.json")
if os.path.exists(pre):
    old = json.load(open(pre))["results"]; new = {r["title"]: r for r in R}
    w("\n## Release 3 findings re-tested after the fixes\n")
    w("| Check (title) | Before | After | Finding |\n|---|---|---|---|")
    fmap = {"InsuredName": "VAPT-01", "PolicyNo": "VAPT-02", "PolicyStatus": "VAPT-02", "body is a JSON array": "VAPT-03"}
    for r in old:
        if r["verdict"] == "FAIL" and not r["category"].startswith("HTTP surface"):
            n2 = new.get(r["title"]); f = next((v for k, v in fmap.items() if k in r["title"]), "-")
            w(f"| {r['title']} | FAIL (HTTP {r['status']}) | {n2['verdict'] + ' (HTTP ' + str(n2['status']) + ')' if n2 else 'see Request hygiene checks'} | {f} |")
w("\n## Observations\n")
w("| ID | Check | HTTP | Evidence |\n|---|---|---:|---|")
for r in R:
    if r["verdict"] == "INFO": w(f"| {r['id']} | {r['title']} | {r['status']} | {r['evidence'][:160].replace('|','/')} |")
w("\n## Controls that held\n")
for t in ["Every forged or missing token was refused with 401 and no body detail.", "No unregistered, empty or missing channel code could read, print, issue, reject, update, cancel or query commission of a SOHAR record.", "No payload produced a 5xx, a stack trace, a class name or SQL text from our code; SQL, CRLF, null-byte and traversal text is rejected or stored inert.", "Premium, commission, discount and effective-date tampering had no effect (values are recalculated server side).", "The approver ignores a client-supplied refund amount; an approval cannot be replayed (404) and cannot be rejected afterwards.", "Extreme cancellation dates, lower-case decisions, huge page sizes, 2 MB and deeply nested bodies are refused with 4xx.", "Internal tables (UP_ApiConfig) cannot be listed through the master-table API.", "Responses with personal data carry `Cache-Control: private,no-cache,no-store`."]: w("- " + t)
w("\n## All checks\n")
w("| ID | Category | Check | Expected | HTTP | Verdict | Evidence |\n|---|---|---|---|---:|---|---|")
for r in R: w(f"| {r['id']} | {r['category']} | {r['title'].replace('|','/')} | {r['expectation'].replace('|','/')} | {r['status']} | {r['verdict']} | {r['evidence'][:90].replace('|','/').replace(chr(10),' ')} |")
w("\n## Limits\n")
w("Test tenant only; role-based access is deferred by decision, so no role tests; one 40-request burst is not a load test; platform internals were not reviewed. Re-run `security_probe.py` after each release.\n")
open(B + "/security/Uponly_Security_Probe_Report.md", "w").write("\n".join(md)); print(len(md), cnt)
