import json, os
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.worksheet.datavalidation import DataValidation
B=os.environ["B"]; A=json.load(open(B+"/devdata/assets.json")); T=json.load(open(B+"/devdata/tables.json"))
ORDER=["UPDataUtil","UPSecurity","UPErrorHandler","UPPlatformClient","UPValidator","UPProductData","UPShaper","UPDocBuilder","UPDocService","UPCancelService"]
TABLES=["UP_Channel","UP_Carrier","UP_ProductMaster","UP_ProductRule","UP_ProductPlanRelation","UP_PlanBenefitRelation","UP_DocTemplate","UP_DocWording","UP_BenefitText","UP_FeedColumn","UP_FieldRule","UP_ApiConfig"]
wb=Workbook(); hf=PatternFill("solid",fgColor="1F3864"); th=Side(style="thin",color="BBBBBB")
def sheet(name,head,rows,widths,status=True):
    ws=wb.create_sheet(name); ws.append(head)
    for c in ws[1]: c.font=Font(bold=True,color="FFFFFF"); c.fill=hf; c.alignment=Alignment(wrap_text=True,vertical="center")
    for r in rows: ws.append(r)
    for i,w in enumerate(widths): ws.column_dimensions[chr(65+i)].width=w
    for row in ws.iter_rows(min_row=2):
        for c in row: c.alignment=Alignment(wrap_text=True,vertical="top"); c.border=Border(top=th,bottom=th,left=th,right=th)
    ws.freeze_panes="A2"; ws.auto_filter.ref=ws.dimensions
    if status:
        n=len(head); dv=DataValidation(type="list",formula1='"Open,Done,Failed,N/A"',allow_blank=True); ws.add_data_validation(dv)
        dv.add(f"{chr(64+n-1)}2:{chr(64+n-1)}{ws.max_row}")
    return ws
wb.remove(wb.active)
sheet("README",["Item","Value"],[["Document","Afillar Insurance API - UAT deployment checklist v1.1 (companion to the UAT Deployment Plan)"],["Source","MC tenant `uponly`, profile portal:uponly"],["Target","UAT - tenant code / profile / gateway: <TO BE PROVIDED>"],["How to use","Work sheets in order: 1 Prerequisites, 2 Functions, 3 APIs, 4 Tables, 5 Platform config, 6 Environment values, 7 Steps, 8 Smoke tests, 9 Go/No-go. Set Status to Done/Failed and fill Evidence."],["Rule","PA001 is never changed. Ids differ per tenant: re-resolve, never copy."]],[18,110],False)
sheet("1 Prerequisites",["#","Prerequisite","Owner","Status","Evidence"],[[i+1,x,o,"Open",""] for i,(x,o) in enumerate([("UAT tenant code, imo profile and gateway received","Project"),("Deployer has admin rights: iComposer, iTables, product config, Output Service, code tables","Platform"),("PA001 exists in UAT (or tech/market products can be created)","Platform"),("API users with Checker and Approver roles created for Sohar Bank","Platform"),("Gateway routes /up/... allowed to the partner","Platform"),("Backup/export of UAT iComposer and iTables taken","Deployer"),("Release package v1.1 extracted; sources match MC md5 list (sheets 2-3)","Deployer"),("Change window approved","PM")])],[5,80,14,10,40])
fn=[a for a in A if a["kind"]=="function"]; fm={a["name"]:a for a in fn}
sheet("2 Functions",["Order","Function","MC version","MC md5","Lines","Status","Evidence"],[[i+1,n,fm.get(n,{}).get("version"),fm.get(n,{}).get("md5"),fm.get(n,{}).get("lines"),"Open",""] for i,n in enumerate(ORDER)],[7,22,11,36,8,10,30])
api=sorted([a for a in A if a["kind"]=="api" and a.get("status")==1],key=lambda a:a["name"])
sheet("3 APIs",["Name","Route","Method","MC version","MC md5","UAT version","Status","Evidence"],[[a["name"],a["path"],{1:"GET",2:"POST"}.get(a["method"]),a["version"],a["md5"],"","Open",""] for a in api],[28,36,8,11,36,11,10,30])
rows=[]
for t in TABLES: rows.append([t,len(T[t]["records"]),"Create table, load rows with record-batch-save (insert-only); verify count","Open",""])
sheet("4 Tables",["Table","Rows (MC)","Action","Status","UAT row count / evidence"],rows,[26,10,70,10,30])
cfg=[("Tech products (7) + market products (7)","UPPA001, TL001, FP001, HC001, CI001, LP001, DH001: recreate/import, re-resolve product ids"),("Data dictionary bindings","incl. cancellation fields and OrgCode/PubBranch value 1"),("Rating / plan / benefit data","per product"),("Output templates (14) and DocTemplate rows","re-resolve template ids in UP_DocTemplate"),("Code tables","PubBranch 1, gender, ID type, marital status, relationship"),("Pre-existing tenant tables","BranchCode, Relationship etc. must exist in UAT")]
sheet("5 Platform config",["Item","Detail","Status","Evidence"],[[a,b,"Open",""] for a,b in cfg],[40,80,10,30])
env=[("AllowedHosts","UAT gateway host"),("GatewayUrl","UAT gateway URL"),("PrintUrl","UAT print service URL"),("UP_Channel row","partner ChannelCode for UAT"),("Token endpoint / client","UAT OAuth client for the partner"),("OrgCode","branch value 1 must exist as PubBranch")]
sheet("6 Environment values",["Setting","Meaning","UAT value","Status","Evidence"],[[a,b,"","Open",""] for a,b in env],[24,50,36,10,30])
steps=["Export MC sources and rows (already in the package)","Create the 12 UP_ tables in UAT","Load rows; adjust environment keys (sheet 6)","Configure/verify products and templates, re-resolve ids","Push the 10 functions in the order of sheet 2","Push the 12 APIs (sheet 3), compile check on each","Reload / publish routes and gateway mapping","Run smoke tests (sheet 8)","Run PA001 snapshot before/after and compare","Sign off with go / no-go (sheet 9)"]
sheet("7 Steps",["#","Step","Owner","Status","Evidence"],[[i+1,s,"Deployer","Open",""] for i,s in enumerate(steps)],[5,70,12,10,30])
sm=[(p,"carrier_check.py flow: Get Plans, Proposal, Issue, Load, Cancel Check/Approve, Commission; CarrierCode AFIC") for p in ["UPPA001","TL001","FP001","HC001","CI001","LP001","DH001"]]
sheet("8 Smoke tests",["Product","Test","Status","Evidence"],[[a,b,"Open",""] for a,b in sm]+[["All","Mismatched CarrierCode returns 400","Open",""],["All","Master data lists UP_Carrier","Open",""],["All","security_probe.py (read-only checks)","Open",""]],[12,80,10,30])
sheet("9 Go-NoGo",["Criterion","Decision","Comment"],[[c,"","" ] for c in ["All functions and APIs match MC md5 / version","All 12 tables have the MC row counts","7 product smoke flows pass","PA001 snapshot identical before/after","Security probe has no new findings vs MC","Partner users and routes confirmed","Rollback tested (re-push saved sources)"]],[60,14,40],False)
dv=DataValidation(type="list",formula1='"Go,No-go"',allow_blank=True); wb["9 Go-NoGo"].add_data_validation(dv); dv.add("B2:B8")
wb.save(B+"/final2/Afillar_UAT_Deployment_Checklist_v1.1.xlsx"); print("ok")
