#!/usr/bin/env python3
"""Stage A: new configuration rows (no defaults in code) + UP_FeedColumn."""
import json, sys, glob
sys.path.insert(0, ".")
from uptab import *
cfg = []
def c(k, v): cfg.append(dict(Api="*", Scope="*", Key=k, Value=str(v)))
for k, v in [("TrueValue", "Y"), ("FalseValue", "N"), ("SinglePremiumModeCode", "1"), ("NonSingleTermYears", "1"), ("ProposalStatusEntry", "1"),
             ("PrintExportType", "pdf"), ("PrintStorage", "not_store"), ("PrintMode", "sync"), ("DocContentType", "application/pdf"),
             ("DocFileNamePattern", "{docType}_{number}.pdf"), ("DocTypeApplication", "Application"), ("DocTypePolicy", "Policy"),
             ("SearchSortField", "index_time"), ("SearchSortType", "desc"), ("SearchModule", "Policy"), ("DayStartTime", "T00:00:00"), ("DayEndTime", "T23:59:59"),
             ("FeedFileName", "Policy_Feed.xlsx"), ("FeedSheetName", "PolicyFeed"), ("FeedContentType", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"),
             ("FeedMaxRecords", "2000"), ("FeedMaxPages", "40"),
             ("DateFormatDoc", "dd/MM/yyyy"), ("MoneyFormat", "#,##0.00"), ("NumberFormat", "#,##0.##"), ("PlanLabelPrefix", "PLAN-"),
             ("BeneficiaryShareTotal", "100"), ("MoneyScale", "2"), ("RoundingMode", "HALF_UP"), ("PercentBase", "100"),
             ("AllowedHosts", "portal-gw.insuremo.com"), ("PatternMaxLength", "200"), ("PatternMaxInput", "500"),
             ("MsgServerError", "The request could not be processed. Please contact support and quote the trace id."),
             ("MsgConfigError", "The service is not configured correctly. Please contact support and quote the trace id."),
             ("MsgInvalidNumber", "A numeric value in the request is not valid.")]: c(k, v)
tid = table("UP_ApiConfig", [])
save("UP_ApiConfig", tid, cfg, 28, "cfgA")
# benefit wording by limit basis (UP_DocWording, ModeCode = BASIS:<LimitBasis>)
wid = table("UP_DocWording", [])
wr = [("BASIS:Included", "Text", "Included"), ("BASIS:PerDay", "Text", "{limit} per day"), ("BASIS:PerDay", "DaysText", " (maximum {days} days per policy year)"),
      ("BASIS:ActualsPerPolicyYear", "Text", "Actuals up to {limit} per policy year"), ("BASIS:Actuals", "Text", "Actuals up to {limit}"), ("BASIS:Default", "Text", "{limit}")]
save("UP_DocWording", wid, [dict(ModeCode=a, Key=b, Value=v) for a, b, v in wr], 22, "wordA")
# benefit names for products without bilingual wording: table description, no Arabic (a row is now required)
bid = table("UP_BenefitText", [])
have = {(r["ProductCode"], r["BenefitCode"]) for r in json.load(open(B + "/tables/r_UP_BenefitText_0.json"))}
rows = []
for f in glob.glob(B + "/tables/b_UP_PlanBenefitRelation_*.json"): rows += json.load(open(f))
seen = {}
for r in rows: seen[(r["IMOProductCode"], r["BenefitCode"])] = r["BenefitDesc"]
new = [dict(ProductCode=k[0], BenefitCode=k[1], NameEn=v, NameAr="") for k, v in seen.items() if k not in have]
print("benefit rows to add", len(new), [(n["ProductCode"], n["BenefitCode"]) for n in new])
save("UP_BenefitText", bid, new, len(have) + 1, "benA")
# feed columns
cols = [("ApplicationNo", "ApplicationNo", "App No"), ("PolicyNo", "PolicyNo", "Certificate No"), ("ApplyDate", "ApplyDate", "Date of Application"), ("BranchCode", "BranchCode", "Branch Code"),
        ("ProductCode", "ProductCode", "Product Code"), ("ProductSubcode", "ProductSubcode", "Product Subcode"), ("PolicyTerm", "PolicyTerm", "Plan Term"),
        ("InsuredName", "PolicyLobList[0].PolicyRiskList[0].InsuredName", "Name Of The Insured Person"), ("DOB", "PolicyLobList[0].PolicyRiskList[0].DateOfBirth", "DOB"),
        ("Frequency", "PremiumModeCode", "Premium Frequency"), ("Discount", "DiscountAmount", "Discount"), ("Premium", "PolicyLobList[0].PolicyRiskList[0].DuePremium", "Premium Amount"),
        ("Beneficiary", "PolicyLobList[0].PolicyRiskList[0].BeneficiaryList[0].BeneficaryName", "Name of the Beneficiary"),
        ("Relationship", "PolicyLobList[0].PolicyRiskList[0].BeneficiaryList[0].RelationshipCode", "Relationship of Beneficiary"),
        ("PoBox", "PolicyLobList[0].PolicyRiskList[0].PostCode", "PO Box"), ("Address", "PolicyLobList[0].PolicyRiskList[0].Address", "Address"), ("Commencement", "EffectiveDate", "Commencement Date"),
        ("Status", "PolicyStatus_CodeDesc|PolicyStatus", "Policy Status"), ("Mobile", "PolicyLobList[0].PolicyRiskList[0].Mobile", "Mobile Number"), ("User", "UserName", "Username"),
        ("Staff", "StaffId", "Staff Id"), ("DebitRef", "PolicyPaymentInfoList[0].DebitRefNo", "Debit Trans Ref No"), ("CIF", "PolicyCustomerList[0].CIFNumber", "CIF No"),
        ("LC", "PolicyPaymentInfoList[0].LCCode", "LC Code"), ("LG", "PolicyPaymentInfoList[0].LGCode", "LG Code"), ("PolicyNo2", "PolicyNo", "Policy No")]
fid = table("UP_FeedColumn", [("Id", S), ("Sequence", L), ("Heading", S), ("Source", S)])
save("UP_FeedColumn", fid, [dict(Sequence=i, Heading=h, Source=s) for i, (_, s, h) in enumerate(cols, 1)], 1, "feedcol")
print("done")
