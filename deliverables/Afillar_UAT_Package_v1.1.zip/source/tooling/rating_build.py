#!/usr/bin/env python3
"""Create <CODE>_PREM_CALC (copy of Uponly PA001_PREM_CALC) bound to a market product in the current tenant.
usage: rating_build.py <PRODUCTCODE> [--confirm]"""
import json, os, subprocess, sys
B = os.environ["B"]; GW = os.environ["GW"]; TOK = os.environ["TOK"]
code = sys.argv[1]; confirm = "--confirm" in sys.argv
R = ["python3", "/tmp/insuremo/insuremo-gi-rating-config/scripts/rating_api.py"]
def api(cmd, payload=None, extra=None):
    args = R + [cmd] + (extra or []) + (["--confirm"] if confirm and cmd.endswith(("-save","-delete","-bind")) else []) + ["--gateway", GW, "--token", TOK]
    r = subprocess.run(args, input=json.dumps(payload) if payload is not None else None, capture_output=True, text=True)
    out = r.stdout + r.stderr
    try: return json.loads(out[out.index("{"):])
    except Exception: return {"raw": out[-500:]}
src = json.loads(open(B + "/rating/tree_PA001.json").read()[open(B + "/rating/tree_PA001.json").read().index("{"):])
mp = None
for x in json.loads(subprocess.run(["imo", "config", "product", "list", "--profile", "portal:uponly", "--code", code, "--json"], capture_output=True, text=True).stdout):
    if x["Product"]["BusinessCode"] == code: mp = x["Product"]["ProductMasterId"]
print("market ProductMasterId", mp)
defcode = f"{code}_PREM_CALC"
existing = api("definition-load", extra=["--code", defcode])
res = existing if existing.get("CalcDefId") else api("definition-save", {"calculationDefinition": {"Code": defcode, "Name": "PA_PREM_CALC", "Description": f"Premium calculation for {code}", "VersionDateField": "", "ReleaseDateField": ""},
                              "context": ["1_70_26", f"2_2_{mp}"]})
print("definition:", json.dumps(res)[:200])
if not confirm: sys.exit(0)
loaded = api("definition-load", extra=["--code", defcode])
vid = (loaded.get("VersionList") or [{}])[0].get("VersionId")
print("VersionId", vid)
tree = api("definition-term-calculation", extra=["--version-id", str(vid)])
if tree.get("TopCalcList"):
    print("nodes already exist:", [n["Name"] for n in tree["TopCalcList"]]); sys.exit(0)
for node in src["TopCalcList"]:
    body = {"VersionId": vid, "ModelName": node["ModelName"], "Name": node["Name"], "Description": node.get("Description", ""),
            "FilterExpression": node["FilterExpression"], "Accumulation": False, "Code": ""}
    nres = api("node-save", body, ["--mode", "add"])
    cid = nres.get("CalcId")
    print("node", node["Name"], "->", cid, "" if cid else json.dumps(nres)[:300])
    for st in sorted(node["CalculationSteps"], key=lambda s: s["Sequence"]):
        formula = st["FormulaContent"].replace('"PlanBenefitRelation"', '"UP_PlanBenefitRelation"').replace('"ProductPlanRelation"', '"UP_ProductPlanRelation"')
        formula = formula.replace("def prem=plansPrem[0].Premium\n\tdef comm=plansPrem[0].Commission", "def pm = Policy().PremiumModeCode.val\n\tdef selRow = plansPrem.find { it.PremiumModeCode != null && it.PremiumModeCode != '' && it.PremiumModeCode == pm } ?: plansPrem[0]\n\tdef prem=selRow.Premium\n\tdef comm=selRow.Commission")
        if st["Name"] == "PlanPremium":
            formula = formula.replace("Policy().Commission.update(comm)", "Policy().Commission.update(comm)\n")
        for line in ("Plans[i].DuePremium.update(prem)", "Plans[i].Commission.update(comm)"):  # keeps the PLAN row out of the premium sign
            formula = formula.replace(line, "//" + line)
        sres = api("step-save", {"ParentCalculateId": cid, "Sequence": st["Sequence"], "Name": st["Name"], "FormulaContent": formula}, ["--mode", "add"])
        print("   step", st["Name"], "->", sres.get("StepId"), "" if sres.get("StepId") else json.dumps(sres)[:300])

# noplanprem applied
