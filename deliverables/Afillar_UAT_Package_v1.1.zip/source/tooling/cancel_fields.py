import json,os,subprocess,sys
B=os.environ['B']; GW=os.environ['GW']; TOK=os.environ['TOK']
PF=["python3","/tmp/insuremo/insuremo-gi-product-config/scripts/policy_field.py","--gateway",GW,"--token",TOK,"--workspace",B+"/ws"]
FIELDS=["CancellationDate","CancellationType","CancellationRefundPremium","CancellationRef"]
for code,tech in [("FP001",1188326278),("HC001",1188326360),("DH001",1188326431),("TL001",1188369449),("CI001",1188369625),("LP001",1188369653),("UPPA001",1188326821)]:
    out=subprocess.run(PF+["context-objects","--product-id",str(tech)],capture_output=True,text=True).stdout
    top=json.loads(out)[0]; oid=top["ObjectId"] if "ObjectId" in top else top.get("ChildObject",{}).get("ObjectId")
    print(code,"policy object",oid,top.get("Code"))
    for fn in FIELDS:
        b={"BusinessObjectId":oid,"FieldType":-3,"FieldName":fn,"FieldCommentsEn":fn,"FieldLabelEn":fn,"IsFixed":"N","IsDeprecated":"N","IsMandatory":"N","IsTemp":"N","IsUnique":"N","IsIndexed":"N","IsInput":"Y"}
        p=f"{B}/payloads/cancelfld_{code}_{fn}.json"; json.dump({"ContextTypeId":"5","ContextId":str(tech),"BusinessFieldBinding":b},open(p,"w"))
        r=subprocess.run(PF+["--body-file",p,"--confirm","create-binding"],capture_output=True,text=True)
        print("  ",fn,"ok" if "BindingId" in r.stdout else (r.stdout+r.stderr)[-200:])
