import json,os,subprocess
B=os.environ["B"]; GW=os.environ["GW"]; TOK=os.environ["TOK"]
PC=["python3","/tmp/insuremo/insuremo-gi-product-config/scripts/product_create.py","--gateway",GW,"--token",TOK,"--workspace",B+"/ws"]
out={}
for c in ["UPPA001","TL001","FP001","HC001","CI001","LP001","DH001"]:
    d=json.loads(subprocess.run(["imo","config","product","list","--profile","portal:uponly","--code",c,"--json"],capture_output=True,text=True,cwd="/home/user/Tablet").stdout or "[]")
    ids={x["Product"]["BusinessCode"]:x["Product"] for x in d if x["Product"]["BusinessCode"] in (c,c+"_TECH")}
    if c+"_TECH" not in ids: continue
    r=subprocess.run(PC+["tree-runtime","--product-id",str(ids[c+"_TECH"]["ProductId"])],capture_output=True,text=True).stdout
    t=json.loads(r[r.index("{"):])
    out[c]={"tech":ids[c+"_TECH"]["ProductId"],"market":ids.get(c,{}).get("ProductId"),"marketMaster":ids.get(c,{}).get("ProductMasterId"),"policyObj":t["DefinitionObjectId"]}
json.dump(out,open(B+"/products.json","w"),indent=1); print(json.dumps(out))
