#!/usr/bin/env python3
"""Stages C + D: ChannelCode rules on every API, cancel-check / cancel-approve rules and config keys, ChannelCode feed column."""
import json, sys
sys.path.insert(0, ".")
from uptab import *
mode = sys.argv[1]            # config | rules | feed
DATE = r"^\d{4}-\d{2}-\d{2}$"
if mode == "config":
    cfg = []
    def c(k, v): cfg.append(dict(Api="*", Scope="*", Key=k, Value=str(v)))
    for k, v in [("EndoBasePath", "/platform/endo/core/endo/v1"), ("EndoTypeCancel", "3"), ("CancelTypeFreeLook", "31"), ("CancelTypeProRata", "32"), ("CancelReasonCode", "1"),
                 ("CancelPayMode", "30"), ("CancelInstallmentFlag", "Y"), ("CancelInstallmentType", "1"), ("PolicyStatusInforce", "2"),
                 ("RefundTypeFreeLook", "FREE_LOOK"), ("RefundTypeProRata", "PRO_RATA"), ("RequestStatusPending", "PENDING"), ("RequestStatusApproved", "APPROVED"),
                 ("RequestStatusRejected", "REJECTED"), ("DecisionApprove", "APPROVE"), ("DecisionReject", "REJECT"), ("PlatformErrorMaxLength", "300")]: c(k, v)
    first = 28 + len(json.load(open(B + "/tables/r_cfgA_0.json")))
    save("UP_ApiConfig", table("UP_ApiConfig", []), cfg, first, "cfgD"); print("config first id", first)
elif mode == "feed":
    save("UP_FeedColumn", table("UP_FeedColumn", []), [dict(Sequence=27, Heading="Channel Code", Source="ChannelCode")], 27, "feedcol2")
else:
    rules = []
    def rule(api, path, label, req="N", typ="string", minl="", maxl="", pat="", minv="", maxv="", ct="", cc="", enum="", applies="*", wp="", wv=""):
        rules.append(dict(Api=api, Path=path, Label=label, Required=req, DataType=typ, MinLength=minl, MaxLength=maxl, Pattern=pat, MinValue=minv, MaxValue=maxv, CodeTable=ct, CodeColumn=cc, EnumValues=enum, AppliesTo=applies, WhenPath=wp, WhenValue=wv))
    for api in ["UPGetPlans", "UPProposal", "UPUpdateProposal", "UPIssue", "UPProposalReject", "UPListMasterTable", "UPFeedFile", "UPDocGeneration", "UPApplicationDocGeneration",
                "UPCommissionQuery", "UPCancelCheck", "UPCancelApprove", "UPLoadPolicy"]:
        rule(api, "ChannelCode", "Channel code", "Y", "string", 2, 20, r"^[A-Z0-9_]+$", ct="UP_Channel", cc="ChannelCode")
    rule("UPCancelCheck", "PolicyNo", "Policy number", "N", "string", 5, 30, r"^[A-Za-z0-9/_-]+$")
    rule("UPCancelCheck", "ProposalNo", "Proposal number", "N", "string", 5, 30, r"^[A-Za-z0-9/_-]+$")
    rule("UPCancelCheck", "CancellationDate", "Cancellation date", "Y", "date", pat=DATE)
    rule("UPCancelCheck", "CancelReason", "Cancel reason", "Y", "string", 3, 200)
    rule("UPCancelApprove", "PolicyNo", "Policy number", "N", "string", 5, 30, r"^[A-Za-z0-9/_-]+$")
    rule("UPCancelApprove", "ProposalNo", "Proposal number", "N", "string", 5, 30, r"^[A-Za-z0-9/_-]+$")
    rule("UPCancelApprove", "RequestNo", "Request number", "Y", "string", 5, 40, r"^[A-Za-z0-9/_-]+$")
    rule("UPCancelApprove", "Decision", "Decision", "Y", "enum", enum="APPROVE,REJECT")
    first = 115
    save("UP_FieldRule", table("UP_FieldRule", []), rules, first, "UP_FieldRule_CD"); print("rules", len(rules))
