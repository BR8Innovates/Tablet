#!/usr/bin/env python3
"""Create the UP_ data tables in Uponly (definitions and rows copied from the tested TrialX tables)."""
import json, os, subprocess, sys
B = os.environ["B"]
def imo(args, prof):
    r = subprocess.run(["imo"] + args + ["--profile", prof], capture_output=True, text=True, cwd="/home/user/Tablet"); return r.stdout + r.stderr
def byname(name, prof):
    out = imo(["config", "datatable", "by-name", "--name", name, "--json"], prof)
    try: d = json.loads(out)
    except Exception: return None
    d = d if isinstance(d, list) else [d]
    return d[0] if d else None
MAP = {"ProductMaster": "UP_ProductMaster", "ProductPlanRelation": "UP_ProductPlanRelation", "UP_PlanBenefitRelation": "UP_PlanBenefitRelation", "ProductRule": "UP_ProductRule", "DocTemplate": "UP_DocTemplate"}
for src, dst in MAP.items():
    s = byname(src, "portal:trialx")
    ex = byname(dst, "portal:uponly")
    if ex and ex.get("Name") == dst:
        print(dst, "exists", ex["DataTableId"]); tid = ex["DataTableId"]
    else:
        body = {"CodeTableFlag": s.get("CodeTableFlag", "N"), "Fields": s["Fields"], "GroupId": 127, "IsSmall": "Y", "Name": dst, "RecordUsage": 5, "SyncDefinitionOnly": "N"}
        p = f"{B}/tables/def_{dst}.json"; json.dump(body, open(p, "w"))
        print(dst, "create:", imo(["config", "datatable", "create", "--file", p, "--confirm"], "portal:uponly").strip()[:200])
        tid = byname(dst, "portal:uponly")["DataTableId"]
    rows = []
    for r in s.get("Records", []):
        rr = {k: v for k, v in r.items() if k not in ("@pk", "DataTableId", "RecordId", "BusinessUUID", "RecordUsage")}
        rr.update({"DataTableId": tid, "RecordUsage": 5}); rows.append(rr)
    p = f"{B}/tables/rows_{dst}.json"; json.dump(rows, open(p, "w"))
    print(dst, tid, len(rows), "rows")
