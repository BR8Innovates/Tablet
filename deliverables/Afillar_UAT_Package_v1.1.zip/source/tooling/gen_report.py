import json, os, glob, collections, shutil
B = os.environ["B"]; res = json.load(open(B + "/tests/results.json")); cases = {c["id"]: c for c in json.load(open(B + "/tests/cases.json"))}
out = B + "/tests_out"; os.makedirs(out, exist_ok=True)
tot = len(res); p = sum(r["result"] == "PASS" for r in res)
def exp(e):
    if e.get("errors"): return "400 " + ", ".join(f"{f}/{c}" for f, c in e["errors"])
    if e.get("status_in"): return "/".join(map(str, e["status_in"]))
    return str(e.get("status", ""))
by = collections.OrderedDict()
for r in res: by.setdefault(r["group"], []).append(r)
byapi = collections.OrderedDict()
for r in res: byapi.setdefault(r["api"], []).append(r)
# plan matrix
STEPS = ["get-plans", "proposal", "update-proposal", "load-proposal", "issue", "load-policy", "proposal-for-reject", "proposal-reject", "doc-application", "doc-policy", "cancel-check", "cancel-approve", "load-cancelled"]
matrix = []; planok = 0
for d in sorted(glob.glob(B + "/samples/ref/*_P*"), key=lambda x: (x.split("/")[-1].split("_P")[0], int(x.rsplit("_P", 1)[1]))):
    tag = os.path.basename(d); row = []
    for i, s in enumerate(STEPS, 1):
        fn = f"{d}/{i:02d}_{s}.json"; row.append(json.load(open(fn))["response"]["status"] if os.path.exists(fn) else "-")
    ok = all(x == 200 for x in row); planok += ok; matrix.append((tag, row, ok))
md = ["# Uponly API test report", "",
      f"Environment: Uponly tenant, test route `/platform/api-orchestration-test/v1/flow/up/...`. Run date: 2026-10-01 (final cycle). Every request carries ChannelCode (SOHAR). Cancellation = Checker (cancel-check) + Approver (cancel-approve).", "",
      "## Result", "", f"- **Automated cases: {tot}, passed {p}, failed {tot - p}** (field validation, business rules, state transitions, master data, feed file, robustness).",
      f"- **Plan-wise end-to-end flows: {planok} of {len(matrix)} plans passed all 13 steps** (get-plans, proposal, update-proposal, load proposal, issue, load policy, proposal for reject, reject, application PDF, certificate PDF, cancel-check, cancel-approve with APPROVE, load of the cancelled policy). Every proposal carries `OrgCode` 1.",
      "- PA001 snapshot (tables, rows, product entries) before vs after: unchanged (new products only appear in a code-prefix search).",
      "- Configuration-missing check: removing one `UP_ApiConfig` key returns HTTP 500 `UP-CONFIG` with a generic message and the trace id; the key name is only in the platform log (key restored after the check).", "",
      "## Results by API", "", "| API | Cases | Passed | Failed |", "|---|---|---|---|"]
for a, rs in byapi.items(): md.append(f"| {a} | {len(rs)} | {sum(r['result']=='PASS' for r in rs)} | {sum(r['result']!='PASS' for r in rs)} |")
md += ["", "## Results by group", "", "| Group | Cases | Passed |", "|---|---|---|"]
for g, rs in by.items(): md.append(f"| {g} | {len(rs)} | {sum(r['result']=='PASS' for r in rs)} |")
md += ["", "## Plan-wise flows (HTTP status of each step; request and response of every step in `plan_samples/<variant>_P<plan>/`)", "",
       "| Variant / plan | " + " | ".join(STEPS) + " | Result |", "|---|" + "---|" * (len(STEPS) + 1)]
for tag, row, ok in matrix: md.append(f"| {tag} | " + " | ".join(map(str, row)) + f" | {'PASS' if ok else 'FAIL'} |")
md += ["", "## Defects found by the suite and fixed (first runs: 36 and 6 failures, final run: 0; this release added the items 9 to 11)", "",
       "| # | Found | Fix |", "|---|---|---|",
       "| 1 | Empty request body `{}` returned HTTP 500 (null pointer) on 9 APIs | Null body treated as empty input; the validator then returns the field errors |",
       "| 2 | Issue / reject / update of an unknown proposal returned 500 (platform null pointer); documents for an unknown policy/proposal returned 500 | Existence check first: HTTP 404 with a clear message |",
       "| 3 | Issue / update / reject on an already issued proposal returned 500 from the platform | HTTP 409 `UP-409` with message (status codes come from `UP_ApiConfig`) |",
       "| 4 | A rejected proposal could be issued and rejected again | Rejected proposals now return HTTP 409 for issue, update and reject |",
       "| 5 | Update / issue / reject with a different product than the stored proposal was accepted | HTTP 400 `MISMATCH` on `ProductCode` / `ProductSubcode` |",
       "| 6 | A wrong sub-product code reported two errors (format and unknown) | Product-dependent checks skipped when the product fields already failed |",
       "| 7 | Get plans without premium mode on LP001 returned both modes mixed | `PremiumModeCode` REQUIRED where plans differ by mode |",
       "| 8 | Test-data issues only: GET object test, feed file test using PA001, short sub-code pattern test | Test corrected (no product change) |",
       "| 9 | Cancellation check on a policy with a pending request returned 500: the endorsement service needs the signed policy id | Signed id taken from the platform load and sent once-encoded |",
       "| 10 | Platform business errors during cancellation approval escaped as HTTP 500 (the REST client raises its own exception) | `UPPlatformClient` returns status and message; the approver answers 409 and keeps the request pending |",
       "| 11 | Unexpected errors gave no usable trace | Generic message to the caller; full exception logged with the trace id |",
       "| 12 | Proposal without OrgCode kept the platform default -1 and could not be cancelled (platform validation of code table PubBranch) | Default branch 1 applied by UPSecurity.defaultOrgCode; a caller's own value is kept |",
       "| 13 | Free-text fields accepted script, template and command text (stored) | UPSecurity.scan: blocked characters everywhere, allow-list for free-text fields (400 INVALID_CHARACTER) |",
       "| 14 | Client could send PolicyNo / PolicyStatus: duplicate-key 500 with database text, 500 / 502 on a status | Server-owned fields removed from the proposal body; platform database / framework text replaced by a generic message |",
       "| 15 | A JSON array, text or number body gave HTTP 500 | UPSecurity.readInput: 400 INVALID_BODY on all body APIs |", "",
       "## Cancellation and refund verification", "",
       "- Per product (UPPA001, TL001, FP001, HC001, CI001, LP001, DH001): policy created and issued, Checker at day 10, 15 (last free-look day), 16 (first pro-rata day) and 60, each request closed with REJECT, then APPROVE on the day-60 request.",
       "- Refund rule checked against an independent calculation in the test: free look (15 days) = 100% of the premium; later = premium x unexpired days / policy days x 80%, rounded half up to 2 decimals. Approver refund equals the Checker refund; policy status becomes 3 (Cancelled); a second approve, a reject after approve and a new check on the cancelled policy are refused.",
       "- Platform endorsement `-002` is issued (EndoStatus 300) and shown in the endorsement history.", "",
       "## Behaviour to know", "",
       "- Wrong HTTP method (for example GET on a POST API) is rejected by the platform gateway with HTTP 422 `MO-PLATFORM-ICOMPOSER-B0008`, not by our code.",
       "- Reject is not blocked by a duplicate `ApplicationNo`: creating a second proposal with an existing ApplicationNo is accepted (documented in case ST0024).",
       "- The effective date minimum offset (0 days = today) comes from `UP_ApiConfig.EffectiveDateMinOffsetDays`.", "",
       "## Hard-coded defaults removed (now from tables)", "",
       "| Was in code | Now |", "|---|---|",
       "| Risk element `R00001`, status `2`, sequence `1`, `IsAutoAttachedForm Y`, customer flags, instalment structure (count, rate, amounts), zero-premium field list, `IsPremiumCalcSuccess`, `BusinessCateCode` | `UP_ApiConfig` |",
       "| Template version, print service URL, gateway URL, proposal status codes, page sizes, effective date offset, success text, commission switch | `UP_ApiConfig` |",
       "| Premium mode wording (frequency, premium text, period of cover in English and Arabic) | `UP_DocWording` |",
       "| English / Arabic benefit names | `UP_BenefitText` (fallback is the plan table description) |",
       "| Field rules (required, type, length, format, range, code values) | `UP_FieldRule` (114 rules) |",
       "| Free look days / refund percentage fallback (15 / 80) | removed: missing values raise a configuration error |",
       "| Y / N flag values (about 20 places), premium mode meaning, print settings, search constants, feed file layout (`UP_FeedColumn`), formats, rounding, cancellation codes, endorsement paths, error texts, allowed hosts | `UP_ApiConfig` (about 80 keys) and `UP_FeedColumn` |",
       "| Benefit limit phrases (per day, actuals up to ...) | `UP_DocWording` (BASIS:*) |",
       "| Cancel reason default text, first plan as default PlanId, benefit name fallback | removed: value required (400 REQUIRED) or table row required |",
       "| Channel | `UP_Channel` (SOHAR = Sohar Bank), `ChannelCode` required on every request and saved on every proposal / policy |",
       "| Policy term default `1` in documents, `IsInstallment` default `N`, plan name default | removed: value must exist on the policy / request or table |",
       "A missing configuration value returns HTTP 500 `UP-CONFIG` (generic text, key name in the log), never a silent default.", "",
       "## Not covered", "",
       "- Cancellation APPROVE end to end is covered (all 7 products, free look and pro-rata). It needs `OrgCode` 1 on the proposal: a proposal without it keeps the platform default -1 and the platform refuses the cancellation (documented 409 case).",
       "- Runtime (non-test) route, load/performance, and role-based permissions. Security testing is reported separately (see the VAPT report and `Uponly_Security_Probe_Results`).",
       "- Newman execution of the collection (the suite uses the same requests directly).", "",
       "## All cases", "", "| ID | API | Product / plan | Case | Expected | Actual | Result |", "|---|---|---|---|---|---|---|"]
for r in res:
    c = r; pp = (c["product"] + (f" P{c['plan']}" if c.get("plan") else "")) if c.get("product") else "-"
    md.append(f"| {c['id']} | {c['api']} | {pp} | {c['title'].replace('|','/')} | {exp(c['expect'])} | {c['status']} | {c['result']} |")
open(out + "/Uponly_Test_Report.md", "w").write("\n".join(md))
# regenerate catalogue with ST cases
import subprocess
subprocess.run(["python3", B + "/gen_md.py"])
# samples
ps = out + "/plan_samples"; shutil.rmtree(ps, ignore_errors=True); shutil.copytree(B + "/samples/ref", ps)
for d in glob.glob(ps + "/*"):
    f = d + "/11_cancel-policy.json"
    if os.path.exists(f): os.remove(f)
tr = out + "/test_results"; shutil.rmtree(tr, ignore_errors=True); shutil.copytree(B + "/tests/results", tr)
print(tot, p, planok, len(matrix))
