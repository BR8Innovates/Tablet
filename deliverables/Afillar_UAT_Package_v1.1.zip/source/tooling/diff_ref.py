import json,glob,re,sys,os
ref=json.load(open(glob.glob("/root/.claude/uploads/*/9a04f7cf*")[0])); f=ref["item"][5]["item"]
def paths(o,p=""):
    s=set()
    if isinstance(o,dict):
        for k,v in o.items(): s.add(p+"/"+k); s|=paths(v,p+"/"+k)
    elif isinstance(o,list):
        for v in o: s|=paths(v,p+"[]")
    return s
names=["get-plans","proposal","update-proposal","load-proposal","issue","load-policy","proposal-for-reject","proposal-reject"]
d=sys.argv[1]
for i,n in enumerate(names):
    fn=glob.glob(f"{d}/{i+1:02d}_*.json")[0]; m=json.load(open(fn))
    rr=paths(json.loads(f[i]["response"][0]["body"])); mr=paths(m["response"]["body"])
    print("==",n,"| only-in-ref:",sorted(rr-mr)[:30]); print("   only-in-mine:",sorted(x for x in mr-rr if "_CodeDesc" not in x)[:30])
