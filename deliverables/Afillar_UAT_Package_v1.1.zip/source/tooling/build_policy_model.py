#!/usr/bin/env python3
"""Builds Afillar_PolicyModel_v0.4.xlsx in the layout of the PA policy model workbook (v0.1), extended to all Uponly products and APIs."""
import json, os, re, collections
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
import model_data as md
B = os.environ["B"]; OUT = B + "/final2"; os.makedirs(OUT, exist_ok=True)
HDR = PatternFill("solid", fgColor="92D050"); BOLD = Font(bold=True); WRAP = Alignment(wrap_text=True, vertical="top")
thin = Side(style="thin", color="BFBFBF"); BOX = Border(left=thin, right=thin, top=thin, bottom=thin)
wb = openpyxl.Workbook()
def sheet(title, header, rows, widths):
    ws = wb.create_sheet(title); ws.append(header)
    for c in ws[1]: c.fill = HDR; c.font = BOLD; c.alignment = Alignment(wrap_text=True, vertical="center"); c.border = BOX
    for r in rows: ws.append(r)
    for i, w in enumerate(widths, 1): ws.column_dimensions[get_column_letter(i)].width = w
    for row in ws.iter_rows(min_row=2):
        for c in row: c.alignment = WRAP; c.border = BOX
    ws.freeze_panes = "A2"; return ws
def label(name): return re.sub(r"(?<=[a-z0-9])(?=[A-Z])", " ", name)
prods = md.products(); cts = md.code_tables(); rules = md.field_rules(); ex, vars_ = md.examples(); top = md.top_examples()
# ------------------------------------------------------------------ Revision
sheet("Revision", ["No", "Date", "Change Content", "Prepared/Updated by"], [
    ["0.1", "2026-02-23", "PA product details added", "Kaviram D"],
    ["0.2", "2026-10-02", "Extended to the additional Afillar products (UPPA001, TL001, FP001, HC001, CI001, LP001, DH001) and 13 APIs: ChannelCode and OrgCode on every proposal, update proposal, load, reject, documents, cancellation Checker / Approver, commission, feed file, master data. Field list generated from the deployed validation rules and the recorded API samples.", "Afillar API team (draft for review)"],
    ["0.4", "2026-10-02", "Insurer: CarrierCode and CarrierName (insurer table UP_Carrier, link UP_ProductMaster.CarrierCode) returned by every API, optional validated CarrierCode on Get Plans / Create / Update Proposal; Product sheet shows the insurer; code tables include UP_Carrier.", "Afillar API team (draft for review)"],
    ["0.3", "2026-10-02", "API specific field sheets (one sheet per API) with separate Input and Output rows; Required marked M (mandatory), O (optional), C (conditional, with the condition written out), X (must not be sent); outputs marked A (always returned) or C (conditional).", "Afillar API team (draft for review)"]], [8, 12, 120, 30])
del wb["Sheet"]
# ------------------------------------------------------------------ Product
rows = []
for p in prods:
    rule = p["rule"]; plans = ", ".join(f"{x['IMOPlanCode']} ({x['IMOPlanName']}: {x['Premium']})" for x in p["plans"])
    rows.append([p["code"], p["sub"], p["name"], "AFIC", "Afillar Insurance Company", p["lob"], "R00001", len(p["plans"]), plans, rule.get("PremiumModes", ""), f"{rule.get('MinTerm','')}-{rule.get('MaxTerm','')}", f"{rule.get('MinAge','')}-{rule.get('MaxAge','')}", rule.get("MaxEntryAge", ""), rule.get("MaxExitAge", ""), rule.get("FreeLookDays", ""), rule.get("ProRataRefundPercent", "")])
sheet("Product", ["ProductCode", "ProductSubcode", "Product Name", "Insurer code", "Insurer name", "Line of business", "Risk", "Plans", "Plans (code, name, annual premium)", "Premium modes (see PremiumMode)", "Term (years)", "Age", "Max entry age", "Max exit age", "Free look days", "Pro-rata refund %"], rows, [13, 10, 32, 12, 26, 20, 9, 7, 60, 16, 10, 10, 10, 10, 10, 12])
# covers matrix
bens = collections.OrderedDict(); variants = [f"{p['code']}-{p['sub']}" for p in prods]
for p in prods:
    for b in p["covers"]: bens.setdefault(b["BenefitCode"], b["BenefitDesc"])
rows = []
for code, desc in bens.items():
    rows.append([desc, code] + ["Y" if any(b["BenefitCode"] == code for b in p["covers"]) else "" for p in prods])
sheet("Cover matrix", ["Cover / benefit name", "SystemCode"] + variants, rows, [38, 12] + [11] * len(variants))
# plans and covers detail
rows = []
for p in prods:
    for pl in p["plans"]:
        for b in [x for x in p["covers"] if x["IMOPlanCode"] == pl["IMOPlanCode"]]:
            rows.append([p["code"], p["sub"], pl["IMOPlanCode"], pl["IMOPlanName"], pl["Premium"], pl["Commission"], b["BenefitCode"], b["BenefitDesc"], b["BenefitLevel"], b["BenefitLimit"], b["BenefitLimitDesc"]])
sheet("Plans and covers", ["ProductCode", "Sub", "PlanId", "Plan name", "Annual premium", "Commission", "Cover code", "Cover description", "Level", "Limit / sum insured", "Limit note"], rows, [12, 6, 8, 14, 12, 11, 10, 36, 9, 14, 24])
# ------------------------------------------------------------------ Model
model = [
    ["x", "", "", "", "", "Policy", "Policy", "Policy", "Policy root: product, dates, plan, premium mode, channel, branch"],
    ["", "x", "", "", "", "Policy", "PolicyCustomer", "PolicyCustomer", "Customer (CIF) of the policy"],
    ["", "x", "", "", "", "Policy", "PolicyLob", "Product", "Product (line of business)"],
    ["", "", "x", "", "", "Policy", "PolicyRisk", "Insured", "Insured person (risk R00001)"],
    ["", "", "", "x", "", "Policy", "PlanList", "Plan", "Plan with premium and commission (output of Get Plans)"],
    ["", "", "", "", "x", "Policy", "PolicyCoverage", "Cover", "Cover list of the plan with sum insured"],
    ["", "", "", "x", "", "Policy", "BeneficiaryList", "Beneficiary", "Beneficiaries of the insured (name, relationship, share)"],
    ["", "x", "", "", "", "Policy", "PolicyPaymentInfoList", "PaymentInfo", "Payment details (LG / LC code, debit account, reference)"],
    ["x", "", "", "", "", "Cancellation", "CancelRequest", "Cancellation request", "Checker output: request number, premium and refund details"],
    ["", "x", "", "", "", "Cancellation", "PremiumDetails", "Premium details", "Premium, policy days, days since commencement, unexpired days, pro-rata premium"],
    ["", "x", "", "", "", "Cancellation", "RefundDetails", "Refund details", "Cancellation type (FREE_LOOK / PRO_RATA), refund percent, refund premium"],
    ["x", "", "", "", "", "SalesChannel", "Channel", "Channel", "ChannelCode (SOHAR = Sohar Bank) sent on every request and saved on every proposal / policy"]]
sheet("PA-Model", ["Level", "", "", "", "", "Domain", "Model Name", "Name", "Description"], model, [7, 4, 4, 4, 4, 16, 24, 22, 80])
sheet("Data Model", ["Level", "", "", "", "", "Domain", "Model Name", "Name", "Description"], model, [7, 4, 4, 4, 4, 16, 24, 22, 80])
# ------------------------------------------------------------------ Data tables / code tables
desc = {"UP_Carrier": "Insurer (carrier) master", "CustomerType": "Customer type", "Plan": "Plan", "Salutation": "Salutation", "ResidentStatus": "Resident status", "BranchCode": "Branch", "InsMaritalStatus": "Marital status", "PremiumMode": "Premium mode", "IdType": "ID type", "GenderCode": "Gender", "Relationship": "Beneficiary relationship"}
sheet("Data Table Master", ["Name of the DataTable", "DataTable"], [[k, ""] for k in desc], [30, 30])
sheet("Code Tables", ["Table Name", "Table Description", "ID Column", "Code Column", "Description Column", "Configurable (Y/N)"], [[k, v, "BranchCode" if k == "BranchCode" else ("CarrierCode" if k == "UP_Carrier" else "Id"), "BranchCode" if k == "BranchCode" else ("CarrierCode" if k == "UP_Carrier" else "Id"), "BranchName" if k == "BranchCode" else ("CarrierName" if k == "UP_Carrier" else "Description"), "Y"] for k, v in desc.items()], [20, 28, 14, 14, 20, 16])
sheet("Code Values", ["Table Name", "Code", "Description"], [[t, c, d] for t, vals in cts.items() for c, d in vals], [20, 10, 40])
# ------------------------------------------------------------------ API list
api_rows = []
for key, name, method, path, title, purpose in md.APIS: api_rows.append([name, title, method, path, purpose])
sheet("API List", ["API", "Name", "Method", "Path (after the base URL)", "Purpose"], api_rows, [28, 28, 8, 34, 90])
# ------------------------------------------------------------------ API field (like PA-Field)
APIN = [a[1] for a in md.APIS]; APIT = [a[4] for a in md.APIS]
fields = collections.OrderedDict()   # (model, field) -> dict
def flat(o, model, out):
    if isinstance(o, dict):
        for k, v in o.items():
            if isinstance(v, list) and v and isinstance(v[0], dict): flat(v[0], re.sub(r"List$", "", k) if not k.endswith("InfoList") else k, out)
            elif isinstance(v, dict): flat(v, k, out)
            elif not isinstance(v, list): out.append((model, k, v))
def tname(v): return "Double" if isinstance(v, float) else ("Integer" if isinstance(v, int) and not isinstance(v, bool) else "String")
def get(model, field):
    return fields.setdefault((model, field), dict(label="", dt="", ct="", example="", type="String", rule="", inp={}, out=set(), req={}))
# inputs from the validation rules
rule_ct = {"PremiumMode": "PremiumMode", "Plan": "Plan", "CustomerType": "CustomerType", "UP_Channel": "ChannelMaster"}
REQ_MODEL = {"UPCancelCheck": "CancelRequest", "UPCancelApprove": "CancelRequest", "UPCommissionQuery": "CommissionQuery", "UPFeedFile": "FeedFileRequest", "UPListMasterTable": "MasterTableRequest",
             "UPDocGeneration": "DocumentRequest", "UPApplicationDocGeneration": "DocumentRequest", "UPLoadPolicy": "LoadRequest"}
SHARED = {"ChannelCode", "PolicyNo", "ProposalNo", "ProductCode", "ProductSubcode", "PlanId", "ProposalRejectDesc"}
for r in rules:
    model, field = md.model_of(r["Path"])
    if r["Api"] in REQ_MODEL and "." not in r["Path"].replace("Conditions.", "").replace("RangeConditions.", "") and field not in ("ChannelCode",):
        model = REQ_MODEL[r["Api"]]
    elif r["Api"] == "UPFeedFile" and "." in r["Path"]: model = r["Path"].split(".")[0]
    if field.lower() in ("policyno", "proposalno") and r["Api"] in REQ_MODEL: model = "Policy"
    f = get(model, field); f["label"] = f["label"] or r["Label"]
    if r.get("CodeTable"): f["ct"] = r["CodeTable"]
    if r["DataType"] in ("integer",): f["type"] = "Integer"
    elif r["DataType"] == "date": f["type"] = "Date"
    elif r["DataType"] == "decimal": f["type"] = "Double"
    bits = []
    if r.get("MinLength") or r.get("MaxLength"): bits.append(f"length {r.get('MinLength','')}-{r.get('MaxLength','')}")
    if r.get("MinValue") is not None or r.get("MaxValue") is not None: bits.append(f"value {r.get('MinValue','')}-{r.get('MaxValue','')}")
    if r.get("EnumValues"): bits.append("one of " + r["EnumValues"])
    if r.get("Pattern"): bits.append("pattern " + r["Pattern"])
    if r.get("WhenPath"): bits.append(f"when {r['WhenPath']} = {r['WhenValue']}")
    if bits: f["rule"] = "; ".join(sorted(set(filter(None, [f["rule"]] + ["; ".join(bits)]))))
    f["inp"][r["Api"]] = "R" if r["Required"] == "Y" else "O"
# example values from the sample requests
samp_req = []
for key, name, *_ in md.APIS:
    s = ex.get(key)
    if s and s["request"] is not None:
        out = []; flat(s["request"], "Policy", out)
        for model, k, v in out:
            f = get(model, k); f["example"] = f["example"] or str(v); f["req"][name] = True
            if tname(v) == "Double" and f["type"] == "String": f["type"] = "Double"
# outputs from the recorded responses (public fields only)
for key, name, *_ in md.APIS:
    s = ex.get(key)
    if not s or not isinstance(s["response"], dict) or s["response"].get("_pdf"): continue
    out = []; flat(md.trim(s["response"]), "Policy", out)
    for model, k, v in out:
        f = get(model, k); f["out"].add(name); f["example"] = f["example"] or str(v)
        if f["type"] == "String": f["type"] = tname(v)
for tk, name in (("commission_by_policy", "UPCommissionQuery"), ("master", "UPListMasterTable")):
    j = top.get(tk)
    if j:
        body = j["response"]["body"]; items = body if isinstance(body, list) else [body]
        for it in items[:1]:
            if isinstance(it, dict):
                for k, v in it.items():
                    if k in md.TECH or k.startswith("@") or k in ("DataTableId", "RecordId", "RecordUsage") or isinstance(v, (dict, list)): continue
                    f = get("CommissionResult" if tk.startswith("commission") else "MasterRecord", k); f["out"].add(name); f["example"] = f["example"] or str(v); f["type"] = tname(v)
rows = []
order = ["Policy", "PolicyCustomer", "PolicyLob", "PolicyRisk", "BeneficiaryList", "PolicyPaymentInfoList", "PlanList", "PolicyCoverage"]
def sort_key(k): return (order.index(k[0]) if k[0] in order else 50, k[0], k[1])
for (model, field) in sorted(fields, key=sort_key):
    f = fields[(model, field)]
    isin = bool(f["inp"] or f["req"])
    if not isin and not f["out"]: continue
    direction = "InputField" if isin else "OutputField"
    if isin and f["out"]: direction = "Input / Output"
    cells = []
    for a in APIN:
        v = f["inp"].get(a, "") or ("O" if a in f["req"] else "")
        if f["out"] and a in f["out"]: v = (v + "/" if v else "") + "Y"
        cells.append(v)
    rows.append([model, f["label"] or label(field), field, direction, f["ct"], f["example"][:60], f["type"], f["rule"]] + cells + ["0.2"])
ws = sheet("API-Field", ["Model Name", "Label", "InsureMO Fieldname", "Remark", "Code Table", "Data Example", "Field Type", "Rules"] + APIT + ["Change Revision"], rows, [20, 28, 26, 12, 18, 26, 10, 60] + [11] * len(APIN) + [9])
ws.cell(row=len(rows) + 3, column=1, value="Legend: M = mandatory, C = conditional mandatory, O = optional (input); Y = returned in the response. The API sheets (01 ... 13) give every field on its own input / output row with the condition. Platform technical fields (internal ids, hashes, audit stamps, zero VAT / gross fields) are not part of the contract and are not listed.")
# ------------------------------------------------------------------ JSON request / response
cols = []; sample_keys = [("get-plans", "GetPlan"), ("proposal", "CreateProposal"), ("update-proposal", "UpdateProposal"), ("issue", "IssuePolicy"), ("load-policy", "LoadPolicy"), ("proposal-reject", "RejectProposal"), ("cancel-check", "CancelCheck"), ("cancel-approve", "CancelApprove")]
def lines(o, maxlines=140):
    t = json.dumps(o, indent=2, ensure_ascii=False).split("\n"); return t[:maxlines] + (["... (trimmed)"] if len(t) > maxlines else [])
for k, nm in sample_keys:
    s = ex[k]
    cols.append((f"{nm} API Request ({s['method']} {s['path']}" + (f"?{s['query']}" if s["query"] else "") + ")", lines(s["request"]) if s["request"] is not None else ["(no body)"]))
    cols.append((f"{nm} API Response ({s['status']})", lines(md.trim(s["response"]))))
for tk, nm in (("commission_by_policy", "CommissionQuery by policy"), ("master", "Master data"), ("feedfile", "FeedFile")):
    j = top.get(tk)
    if j:
        body = md.resolve(j["request"]["body"], vars_ | {"monthStart": "2026-10-01", "monthEnd": "2026-10-31"})
        cols.append((f"{nm} Request ({j['request']['method']} {j['request']['path']})", lines(body)))
        resp = j["response"]["body"]; resp = resp[:2] if isinstance(resp, list) else resp
        cols.append((f"{nm} Response ({j['response']['status']})", lines(md.trim(resp)) if not (isinstance(resp, dict) and resp.get("_xlsx")) else ["(Excel file, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet)"]))
n = max(len(c[1]) for c in cols)
ws = wb.create_sheet("JSON_Request_Response"); ws.append([c[0] for c in cols])
for c in ws[1]: c.fill = HDR; c.font = BOLD; c.alignment = Alignment(wrap_text=True, vertical="center")
for i in range(n): ws.append([c[1][i] if i < len(c[1]) else "" for c in cols])
for i in range(1, len(cols) + 1): ws.column_dimensions[get_column_letter(i)].width = 60
for row in ws.iter_rows(min_row=2):
    for c in row: c.font = Font(name="Consolas", size=9)
ws.freeze_panes = "A2"
# ------------------------------------------------------------------ Errors
res = json.load(open(B + "/tests/results.json")); err = collections.OrderedDict()
for r in res:
    b = r.get("response")
    if isinstance(b, dict) and b.get("code") and r["status"] >= 400:
        k = (r["status"], b["code"]); err.setdefault(k, b.get("message", ""))
    if isinstance(b, dict):
        for e in b.get("errors") or []: err.setdefault(("field", e.get("code")), e.get("message", ""))
rows = [["HTTP status", s, c, m[:120]] for (s, c), m in err.items() if s != "field"] + [["errors[].code", "", c, m[:120]] for (s, c), m in err.items() if s == "field"]
sheet("Errors", ["Where", "HTTP", "Code", "Example message"], rows, [16, 8, 24, 100])
# ------------------------------------------------------------------ Cancellation
rows = [[p["code"], p["sub"], p["rule"].get("FreeLookDays", ""), p["rule"].get("ProRataRefundPercent", ""), "100% of premium" if p["rule"].get("FreeLookDays") else "", "premium x unexpired days / policy days x refund %"] for p in prods]
ws = sheet("Cancellation", ["ProductCode", "Sub", "Free look (days)", "Pro-rata refund %", "Refund inside free look", "Refund after free look"], rows, [14, 6, 16, 16, 24, 50])
ws.cell(row=len(rows) + 3, column=1, value="Worked example: premium 70.00, policy 2026-10-02 to 2027-10-01 (365 days), cancellation 29 days after start: unexpired days 336, pro-rata premium 70 x 336 / 365 = 64.44, refund 64.44 x 80% = 51.55. Cancelling 15 days or less after the start date refunds the full premium. Amounts are rounded half up to 2 decimals.")

# ------------------------------------------------------------------ per API sheets (input / output rows, M / O / C)
import api_spec_data as asd
spec = asd.build()
FILL = {"M": "F8CBAD", "C": "FFE699", "O": "E2EFDA", "X": "D9D9D9", "A": "C6E0F5"}
leg = wb.create_sheet("Legend")
for r in [["Input fields - Required", ""], ["M", "Mandatory: must be sent, otherwise HTTP 400 REQUIRED"], ["O", "Optional"], ["C", "Conditional mandatory: mandatory only when the condition in the Condition column is met"], ["X", "Must not be sent"],
          ["", ""], ["Output fields - Returned", ""], ["A", "Always returned in a successful response"], ["C", "Returned only when the condition in the Condition column is met"], ["", ""],
          ["Data types", "String, Integer, Double, Date (YYYY-MM-DD, expiry date YYYY-MM-DDT23:59:59), Array, Object, File"], ["Platform technical fields", "Internal ids, hashes and audit stamps may appear in responses; they are not part of the contract and are not listed."]]:
    leg.append(r)
leg.column_dimensions["A"].width = 28; leg.column_dimensions["B"].width = 110
for row in leg.iter_rows():
    for c in row: c.alignment = WRAP
for r in (1, 7): leg.cell(row=r, column=1).font = BOLD; leg.cell(row=r, column=1).fill = HDR
for r in (2, 3, 4, 5, 8, 9): leg.cell(row=r, column=1).fill = PatternFill("solid", fgColor=FILL[leg.cell(row=r, column=1).value])
SHEETN = {}
for i, (api, sp) in enumerate(spec.items(), 1):
    name = f"{i:02d} {sp['title']}"[:31].replace("/", "-"); ws = wb.create_sheet(name); SHEETN[api] = name
    ws.append([sp["title"] + " - " + api]); ws["A1"].font = Font(bold=True, size=13)
    ws.append(["Request", f"{sp['method']} {{baseUrl}}{sp['path']}"]); ws.append(["Purpose", sp["purpose"]]); ws.append(["Header", "Authorization: Bearer {access_token}" + ("" if sp["method"] == "GET" else "  |  Content-Type: application/json")])
    for r in (2, 3, 4): ws.cell(row=r, column=1).font = BOLD
    ws.append([])
    cols = ["Direction", "Parent Object", "Field Name", "Data Type", "Required", "Condition", "Allowed values / code table", "Length / range / format", "Example", "Description"]
    def block(title, rows, outputs=False):
        ws.append([title]); r0 = ws.max_row; ws.cell(row=r0, column=1).font = Font(bold=True, color="FFFFFF"); 
        for c in range(1, 11): ws.cell(row=r0, column=c).fill = PatternFill("solid", fgColor="1F3864")
        ws.append(cols)
        for c in ws[ws.max_row]: c.fill = HDR; c.font = BOLD; c.border = BOX; c.alignment = WRAP
        for x in rows:
            ws.append(["Output" if outputs else "Input", x["parent"], x["name"], x["dtype"], x["req"], x["cond"], x.get("allowed", ""), x.get("limits", ""), x.get("example", ""), x["desc"]])
            rr = ws.max_row
            for c in range(1, 11): ws.cell(row=rr, column=c).alignment = WRAP; ws.cell(row=rr, column=c).border = BOX
            ws.cell(row=rr, column=5).fill = PatternFill("solid", fgColor=FILL.get(x["req"], "FFFFFF")); ws.cell(row=rr, column=5).alignment = Alignment(horizontal="center", vertical="top")
    block("REQUEST - Input fields (" + ("query parameters" if sp["method"] == "GET" else "JSON body") + ")", sp["inputs"])
    ws.append([])
    block("RESPONSE - Output fields", sp["outputs"], True)
    ws.append([]); ws.append(["Counts", f"Input: M {sum(x['req']=='M' for x in sp['inputs'])}, C {sum(x['req']=='C' for x in sp['inputs'])}, O {sum(x['req']=='O' for x in sp['inputs'])}   |   Output: A {sum(x['req']=='A' for x in sp['outputs'])}, C {sum(x['req']=='C' for x in sp['outputs'])}"])
    for i2, wd in enumerate([9, 22, 26, 10, 9, 52, 34, 34, 24, 60], 1): ws.column_dimensions[get_column_letter(i2)].width = wd
    ws.freeze_panes = "A6"

wb.save(OUT + "/Afillar_PolicyModel_v0.4.xlsx"); print("saved", len(rows), len(fields), "fields", len(err), "errors")
