#!/usr/bin/env python3
"""Single 'Sohar Bank' collection: one example per product, token mapped, values parameterized."""
import json, os, glob, copy, re, sys
B = os.environ["B"]; sys.path.insert(0, B)
from pm_common import *
STEPS = [("get-plans", "Get Plans"), ("proposal", "Create Proposal (application)"), ("update-proposal", "Update Proposal (enrolment)"), ("load-proposal", "Load Proposal"),
         ("issue", "Issue Policy"), ("load-policy", "Load Policy"), ("proposal-for-reject", "Create Proposal (to be rejected)"), ("proposal-reject", "Reject Proposal"),
         ("doc-application", "Application Form PDF"), ("doc-policy", "Policy Certificate PDF"), ("cancel-check", "Cancel Check (Checker)"), ("cancel-approve", "Cancel Approve (Approver, Decision APPROVE)"), ("load-cancelled", "Load Policy (after cancellation)")]
PICK = {"UPPA001": "UPPA001_1", "TL001": "TL001_1", "FP001": "FP001_1", "HC001": "HC001_1", "CI001": "CI001_1", "LP001": "LP001_1", "DH001": "DH001_1"}
PER_PRODUCT = ["ProductCode", "ProductSubcode", "PremiumModeCode", "PolicyTerm", "PlanId", "DateOfBirth", "Gender", "InsuredName", "IdNo", "Mobile", "Email", "MonthSalaryIncome"]
GLOBAL = {"UserName": "userName", "BranchCode": "branchCode", "StaffId": "staffId", "Address": "address", "CIFNumber": "cifNumber", "BeneficaryName": "beneficiaryName", "PostCode": "postCode"}
variables = {}
def first_values(o, keys, out):
    if isinstance(o, dict):
        for k, v in o.items():
            if k in keys and not isinstance(v, (dict, list)) and k not in out: out[k] = v
            first_values(v, keys, out)
    elif isinstance(o, list):
        for x in o: first_values(x, keys, out)
def subst(o, base, code):
    if isinstance(o, dict):
        r = {}
        for k, v in o.items():
            if k in base and not isinstance(v, (dict, list)) and v == base[k][1] and not str(v).startswith("{{"):
                r[k] = ("@@NUM:%s@@" % base[k][0]) if isinstance(v, (int, float)) and not isinstance(v, bool) else "{{%s}}" % base[k][0]
            else: r[k] = subst(v, base, code)
        return r
    if isinstance(o, list): return [subst(x, base, code) for x in o]
    return o
def dump(b): return re.sub(r'"@@NUM:([^@]+)@@"', r"{{\1}}", json.dumps(b, indent=4, ensure_ascii=False))
def build_item(step, nm, saved, number, base, code):
    it = copy.deepcopy(T.get(nm) or T["Reject Proposal"]); it["name"] = f"{number}. {nm}"
    rq, rs = saved["request"], saved["response"]; req = it["request"]
    req["method"] = rq["method"]; req["url"] = url_of(rq["path"], rq.get("query"))
    if rq.get("body") is not None: req["body"] = {"mode": "raw", "raw": dump(subst(rq["body"], base, code)), "options": {"raw": {"language": "json"}}}
    else: req.pop("body", None)
    it["response"] = [example(req, rs["status"], rs["body"])]
    return it
folders = []
for code, tag in PICK.items():
    d = min(glob.glob(f"{B}/samples/ref/{tag}_P*"), key=lambda p: int(p.rsplit("_P", 1)[1]))
    prop = json.load(open(d + "/02_proposal.json"))["request"]["body"]
    vals = {}; first_values(prop, set(PER_PRODUCT) | set(GLOBAL), vals)
    base = {}
    for k, v in vals.items():
        name = GLOBAL[k] if k in GLOBAL else f"{code}_{k[0].lower()}{k[1:]}"
        base[k] = (name, v); variables.setdefault(name, str(v))
    items = []
    for i, (step, nm) in enumerate(STEPS, 1):
        sv = json.load(open(f"{d}/{i:02d}_{step}.json"))
        if sv["response"]["status"] == 200: items.append(build_item(step, nm, sv, i, base, code))
        if step == "cancel-check" and items: items[-1]["event"] = [{"listen": "test", "script": {"type": "text/javascript", "exec": CANCEL_CHECK_TEST}}]
        if step == "cancel-approve" and items: items[-1]["event"] = [{"listen": "test", "script": {"type": "text/javascript", "exec": CANCEL_APPROVE_TEST}}]
    folders.append({"name": f"{code}", "item": items, "description": f"Example flow for {code} (sub {vals.get('ProductSubcode')}, PlanId {vals.get('PlanId')}). Change the `{code}_*` collection variables to try other plans / values."})
# Common
def top_item(fname, name, number, nm_tpl):
    sv = json.load(open(f"{B}/samples/top/{fname}.json")); it = copy.deepcopy(T[nm_tpl] if nm_tpl in T else T["Reject Proposal"]); it["name"] = f"{number}. {name}"
    req = it["request"]; rq = sv["request"]; req["method"] = rq["method"]; req["url"] = url_of(rq["path"], rq.get("query"))
    body = json.loads(json.dumps(rq["body"]).replace('"FP001"', '"{{FP001_productCode}}"')) if rq.get("body") else None
    if body is not None: req["body"] = {"mode": "raw", "raw": json.dumps(body, indent=4, ensure_ascii=False), "options": {"raw": {"language": "json"}}}
    it["response"] = [example(req, sv["response"]["status"], sv["response"]["body"])]
    if nm_tpl not in T: it["event"] = [{"listen": "test", "script": {"type": "text/javascript", "exec": ["pm.test('Status is 200', function () { pm.response.to.have.status(200); });"]}}]
    return it
tl = [("master", "Master Data - Insurer (UP_Carrier)", "Data Table - Relationship"), ("feedfile", "Generate Feed File", "Generate Feed File"), ("commission_by_period", "Commission Query", None)]
common = [top_item(f, n, i, t if t else "Reject Proposal") for i, (f, n, t) in enumerate(tl, 1)]
col = base_collection("Sohar Bank", "Sohar Bank - insurance APIs on the Uponly tenant. One working example per product (UPPA001, TL001, FP001, HC001, CI001, LP001, DH001), each a 13-step flow (plans, proposal, enrolment, issue, load policy, reject, documents, cancel check, cancel approve), plus common utility APIs.\n\nSetup: select the Sohar Bank environment, set username and password, run '0. Get Token' (stores the ticket in `token`; every request uses it as Bearer auth, the collection also re-fetches it automatically when empty). Dates and ApplicationNo are generated; ProposalNo / PolicyNo are filled by test scripts. All product, plan and insured values are collection variables named <PRODUCT>_<field>. No VAT. Every request carries ChannelCode = {{channelCode}} (SOHAR). Every proposal carries OrgCode = {{orgCode}} (1, a branch known to the platform): without it the platform cannot validate the cancellation. Cancel Approve in the saved flow uses Decision APPROVE (the policy becomes Cancelled and the refund is returned); send REJECT to close the request and keep the policy in force.")
tok = copy.deepcopy(ref["item"][0]); tok["name"] = "0. Get Token"
col["item"] = [tok] + folders + [{"name": "Common", "item": common}]
col["variable"] = [v for v in col["variable"] if v["key"] not in ("username", "password")] + [{"key": k, "value": v} for k, v in variables.items()]
# auto token: pre-request fetches a ticket when token is empty (collection level, async)
pre = col["event"][0]["script"]["exec"]
pre[:] = [l for l in pre if not l.startswith("if(!cv.get('token')")] + [
 "if(!pm.variables.get('token') && pm.info.requestName.indexOf('Get Token')<0 && pm.variables.get('username')){",
 "  pm.sendRequest({url: pm.variables.get('casUrl')+'/cas/ebao/v2/json/tickets', method:'POST', header:{'Content-Type':'application/json','x-mo-user-source-id':'platform','x-mo-tenant-id':pm.variables.get('tenant')}, body:{mode:'raw', raw: JSON.stringify({username: pm.variables.get('username'), password: pm.variables.get('password')})}}, function(err,res){",
 "    if(err){console.warn('token fetch failed: '+err);return;}",
 "    var t=res.text(); try{var j=JSON.parse(t); t=j.access_token||j.token||j.ticket||j.Token||(j.data&&(j.data.access_token||j.data.token||j.data.ticket))||t;}catch(e){}",
 "    pm.collectionVariables.set('token', String(t).trim());",
 "  });",
 "}"]
out = B + "/final"
json.dump(col, open(out + "/Sohar_Bank.postman_collection.json", "w"), indent=2, ensure_ascii=False)
env = [{"key": k, "value": v, "type": "default", "enabled": True} for k, v in (("baseUrl", "https://portal-gw.insuremo.com/platform/api-orchestration-test/v1/flow"), ("casUrl", "https://portal-gw.insuremo.com"), ("gatewayUrl", "https://portal-gw.insuremo.com"), ("tenant", "uponly"), ("channelCode", "SOHAR"))]
env += [{"key": "username", "value": "", "type": "default", "enabled": True}, {"key": "password", "value": "", "type": "secret", "enabled": True}]
json.dump({"id": "sohar-bank-env", "name": "Sohar Bank", "values": env, "_postman_variable_scope": "environment"}, open(out + "/Sohar_Bank.postman_environment.json", "w"), indent=2)
print("folders", [(f["name"], len(f["item"])) for f in folders], "variables", len(variables))
