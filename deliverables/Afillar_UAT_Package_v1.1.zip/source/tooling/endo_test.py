import json,os,sys,urllib.request,urllib.parse,urllib.error
GW=os.environ['GW']; TOK=os.environ['TOK']; po=sys.argv[1]; eff=sys.argv[2]; ctype=sys.argv[3]; commit=len(sys.argv)>4 and sys.argv[4]=="commit"
H={"Authorization":"Bearer "+TOK,"Content-Type":"application/json","x-mo-tenant-id":"uponly"}
def call(m,path,body=None):
    req=urllib.request.Request(GW+path,data=json.dumps(body).encode() if body is not None else (b"" if m=="POST" else None),method=m,headers=H)
    try:
        with urllib.request.urlopen(req,timeout=240) as r: return r.status,r.read().decode()
    except urllib.error.HTTPError as e: return e.code,e.read().decode()
E="/platform/endo/core/endo/v1"
s,t=call("GET",f"/platform/proposal/v1/load?policyNo={po}"); p=json.loads(t); print('policy',p['PolicyStatus'],p['EffectiveDate'],p['ExpiryDate'])
s,t=call("GET",E+"/queryPendingEndo?policyId="+urllib.parse.quote(p['PolicyId']))
if s==200 and t.strip().startswith('{'):
    pe=json.loads(t); s2,t2=call("POST",E+"/suspendEndorsement?endoId="+urllib.parse.quote(str(pe['EndoId']))); print('suspended pending',s2)
env={"EndoEffectiveDate":eff,"EndoType":"3","CancelType":ctype,"CancelReasonCode":"1","OtherCancelReason":"customer request","PolicyNo":po,"ProductId":p['ProductId'],"ProductCode":p['ProductCode'],"EndorsementPaymentInfoList":[{"PayModeCode":"30","IsInstallment":"Y","InstallmentType":"1"}]}
s,t=call("POST",E+"/createEx",env); print('createEx',s)
if s!=200: print(t[:400]); sys.exit()
created=json.loads(t)
s,t=call("POST",E+"/calculateEx",created); print('calculateEx',s)
if s!=200: print(t[:600]); 
else:
    c=json.loads(t); print({k:c.get(k) for k in ('GrossPremium','ShortRate','BeforeVatPremium','DuePremium','EndoStatus','EndoNo','EndoEffectiveDate','EndoPremium')})
    s2,t2=call("POST",E+"/validate",c); print('validate',s2,t2[:300])
    if commit and s2 in (200,204):
        s3,t3=call("POST",E+"/issueEndorsement",c); print('issueEndorsement',s3,t3[:200])
        s4,t4=call("GET",f"/platform/proposal/v1/load?policyNo={po}"); q=json.loads(t4); print('after:',q.get('PolicyStatus'),q.get('PolicyStatus_CodeDesc'))
    else:
        pend=call("GET",E+"/queryPendingEndo?policyId="+urllib.parse.quote(p['PolicyId']))
        if pend[0]==200 and pend[1].strip().startswith('{'):
            call("POST",E+"/suspendEndorsement?endoId="+urllib.parse.quote(str(json.loads(pend[1])['EndoId']))); print('withdrawn test endorsement')
