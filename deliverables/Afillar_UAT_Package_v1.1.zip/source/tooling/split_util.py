#!/usr/bin/env python3
"""Splits UPDataUtil into focused functions and rewrites the callers. Usage: split_util.py <src-root> <out-root>"""
import re, sys, os, shutil
SRC, OUT = sys.argv[1], sys.argv[2]
API = "src/dev/Tenant/UP_PRODUCTS_API"
if os.path.exists(OUT): shutil.rmtree(OUT)
shutil.copytree(SRC, OUT)
core_path = f"{OUT}/{API}/function/UPDataUtil/UPDataUtil.groovy"
lines = open(core_path).read().split("\n")
OWNERS = {
 "UPDataUtil": "fail str yes no isYes isNo requireAllowedHost fill roundingMode moneyScale percentBase configMap cfgValue cfg pathValue fieldError throwValidation parseDate getRecords readRecords filterRecords toDecimal fmtDate fmtMoney fmtNumber".split(),
 "UPValidator": "requireOpenProposal requireProductMatch requireChannel codeExists validate crossFieldErrors entryErrors".split(),
 "UPProductData": "getVariant getRule allowedModes getPlanRows getBenefitRows buildPlanView prepareProposal".split(),
 "UPShaper": "stripCommission restorePayment returnCommission enrichPremiumFields shapeResponse".split(),
 "UPDocBuilder": "describe benefitText docBenefit premiumWording buildPrintData rate commissionOfPolicy".split(),
 "UPCancelService": ["refundCalc"],
}
VAR = {"UPDataUtil": "util", "UPValidator": "validator", "UPProductData": "products", "UPShaper": "shaper", "UPDocBuilder": "builder"}
owner_of = {f: s for s, fs in OWNERS.items() for f in fs}
DESC = {"UPDataUtil": "UPDataUtil - core helpers: configuration (UP_ApiConfig), table access, flag values, formats, error helpers.",
        "UPValidator": "UPValidator - request validation: field rules (UP_FieldRule), cross-field and product rules, state / channel checks.",
        "UPProductData": "UPProductData - product master data (variants, rules, plans, benefits) and preparation of the proposal payload.",
        "UPShaper": "UPShaper - shapes the responses returned to callers (commission, premium fields, payment info).",
        "UPDocBuilder": "UPDocBuilder - print data for the application form / certificate, document wording, commission view."}
# ---- parse blocks
imports = [l for l in lines if l.startswith("import ")]
start_re = re.compile(r"^[A-Za-z].*\) \{$")
blocks = []; i = 0; first = None
while i < len(lines):
    if start_re.match(lines[i]) and not lines[i].startswith("import "):
        j = i
        while lines[j] != "}": j += 1
        k = i
        while k > 0 and (lines[k-1].startswith("/**") or lines[k-1].startswith(" *") or lines[k-1].startswith("//") or lines[k-1].strip() == "*/"): k -= 1
        name = re.search(r"([A-Za-z0-9_]+)\(", lines[i]).group(1)
        blocks.append((name, lines[k:j+1])); first = first if first is not None else k; i = j + 1
    else: i += 1
assert {b[0] for b in blocks} == set(owner_of), ({b[0] for b in blocks} ^ set(owner_of))
def rewrite_body(block_lines, own):
    text = "\n".join(block_lines); used = set()
    for f, s in owner_of.items():
        if s == own or s == "UPCancelService": continue
        pat = re.compile(r"(?<![\w.])" + f + r"\(")
        if pat.search(text): text = pat.sub(VAR[s] + "." + f + "(", text); used.add(s)
    return text, used
def decl(s): return f'    {s} {VAR[s]} = ({s}) getCommonService("{s}")'
files = {}
for svc in ("UPDataUtil", "UPValidator", "UPProductData", "UPShaper", "UPDocBuilder"):
    out = [f"/**\n * {DESC[svc]}\n */"] + imports + [""]
    for name, bl in blocks:
        if owner_of[name] != svc: continue
        text, used = rewrite_body(bl, svc)
        ls = text.split("\n"); idx = next(n for n, l in enumerate(ls) if start_re.match(l) and not l.startswith("import "))
        ds = [decl(u) for u in sorted(used)]
        out += ls[:idx+1] + ds + ls[idx+1:] + [""]
    body_text = "\n".join(l for l in out if not l.startswith("import "))
    out = [l for l in out if not l.startswith("import ") or re.search(r"\b" + l.split(".")[-1] + r"\b", body_text)]
    files[svc] = "\n".join(out).rstrip() + "\n"
# refundCalc moves to UPCancelService
refund = next(bl for n, bl in blocks if n == "refundCalc")
text, used = rewrite_body(refund, "UPCancelService")
ls = text.split("\n"); idx = next(n for n, l in enumerate(ls) if start_re.match(l) and not l.startswith("import "))
refund_text = "\n".join(ls[:idx+1] + [decl(u) for u in sorted(used)] + ls[idx+1:])
for svc, body in files.items():
    d = f"{OUT}/{API}/function/{svc}"; os.makedirs(d, exist_ok=True); open(f"{d}/{svc}.groovy", "w").write(body)
# ---- callers
def fix_caller(path):
    s = open(path).read(); used = set()
    for f, svc in owner_of.items():
        if svc in ("UPDataUtil",): continue
        if svc == "UPCancelService":
            s = s.replace("util.refundCalc(", "refundCalc("); continue
        pat = re.compile(r"\butil\." + f + r"\(")
        if pat.search(s): s = pat.sub(VAR[svc] + "." + f + "(", s); used.add(svc)
    if used:
        s = re.sub(r"^(\s*)UPDataUtil util = \(UPDataUtil\) getCommonService\(\"UPDataUtil\"\)$", lambda m: m.group(0) + "".join("\n" + m.group(1) + f'{u} {VAR[u]} = ({u}) getCommonService("{u}")' for u in sorted(used)), s, flags=re.M)
    open(path, "w").write(s)
for root, _, fs in os.walk(f"{OUT}/{API}"):
    for f in fs:
        p = os.path.join(root, f)
        if f.endswith(".groovy") and not any(p.endswith(f"{x}/{x}.groovy") for x in ("UPDataUtil", "UPValidator", "UPProductData", "UPShaper", "UPDocBuilder")): fix_caller(p)
# add refundCalc into UPCancelService
cs = f"{OUT}/{API}/function/UPCancelService/UPCancelService.groovy"; s = open(cs).read()
s = s.rstrip() + "\n\n" + refund_text + "\n"; open(cs, "w").write(s)
print({k: len(v.split("\n")) for k, v in files.items()})
