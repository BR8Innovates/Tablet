#!/usr/bin/env python3
"""usage: os_gen.py TEMPLATE_NAME html_file data.json out.pdf  (uploads and generates)"""
import sys, os, json, base64, subprocess
name, html, data, out = sys.argv[1:5]
GW = os.environ["GW"]; TOK = os.environ["TOK"]
H = ["-H", "Authorization: Bearer " + TOK, "-H", "x-mo-tenant-id: uponly"]
r = subprocess.run(["curl", "-sS", "-X", "POST", GW + "/mo-fo/1.0/print/v3/template/upload"] + H + ["-F", "name=" + name, "-F", "template_type=html", "-F", "version=0", "-F", "template=@" + html + ";type=application/octet-stream"], capture_output=True, text=True)
print("upload:", r.stdout[:160])
body = {"template_name": name, "template_version": "0", "print_data": json.load(open(data)), "export_file_type": "pdf", "storage_config": "not_store", "async_or_sync": "sync"}
r = subprocess.run(["curl", "-sS", "-X", "POST", GW + "/mo-fo/1.0/print/v3/printtask/generate"] + H + ["-H", "Content-Type: application/json", "-d", json.dumps(body)], capture_output=True, text=True)
d = json.loads(r.stdout); x = d.get("data", d)
c = x.get("target_file_content") if isinstance(x, dict) else None
if c: open(out, "wb").write(base64.b64decode(c)); print("pdf", out, len(base64.b64decode(c)))
else: print(r.stdout[:500])
