#!/usr/bin/env python3
"""One Postman collection per plan; one folder per API; real flow request/response + recorded failure examples."""
import json, os, glob, copy, re, sys
B = os.environ["B"]; sys.path.insert(0, B)
from pm_common import *
import common_tests as ct
OUT = B + "/final/postman_per_plan"; os.makedirs(OUT, exist_ok=True)
for f in glob.glob(OUT + "/*.json"): os.remove(f)
VARIANTS = {"UPPA001_1": "with TTD", "UPPA001_2": "without TTD", "TL001_1": "with Travel", "TL001_2": "without Travel", "CI001_1": "7 CI", "CI001_2": "11 CI", "CI001_3": "32 CI"}
STEPS = [("get-plans", "Get Plans", "Get Plans"), ("proposal", "Create Proposal (application)", "Create Proposal"), ("update-proposal", "Update Proposal (enrolment)", "Update Proposal"),
         ("load-proposal", "Load Proposal", "Load Proposal"), ("issue", "Issue Policy", "Issue Policy"), ("load-policy", "Load Policy", "Load Policy"),
         ("proposal-for-reject", "Create Proposal (to be rejected)", "Reject Proposal"), ("proposal-reject", "Reject Proposal", "Reject Proposal"),
         ("doc-application", "Application Form PDF", "Application Form PDF"), ("doc-policy", "Policy Certificate PDF", "Policy Certificate PDF"),
         ("cancel-check", "Cancel Check (Checker)", "Cancel Check"), ("cancel-approve", "Cancel Approve (Approver, Decision APPROVE)", "Cancel Approve"), ("load-cancelled", "Load Policy (after cancellation)", "Load Policy")]
API_FOLDER = {"UPGetPlans": "Get Plans", "UPProposal": "Create Proposal", "UPUpdateProposal": "Update Proposal", "UPIssue": "Issue Policy", "UPLoadPolicy": "Load Policy",
              "UPProposalReject": "Reject Proposal", "UPApplicationDocGeneration": "Application Form PDF", "UPDocGeneration": "Policy Certificate PDF", "UPCancelCheck": "Cancel Check", "UPCancelApprove": "Cancel Approve"}
ORDER = ["Get Plans", "Create Proposal", "Update Proposal", "Load Proposal", "Issue Policy", "Load Policy", "Reject Proposal", "Application Form PDF", "Policy Certificate PDF", "Cancel Check", "Cancel Approve"]
def pid_sub(x):
    b = x.get("body")
    try: pr = b["PolicyLobList"][0]; pid = pr["PolicyRiskList"][0]["PlanList"][0]["PlanId"]; return pr["ProductCode"], b.get("ProductSubcode") or pr.get("ProductSubcode"), str(pid)
    except Exception: return ct.product_of(x), None, None
res = json.load(open(B + "/tests/results.json"))
fails = [x for x in res if ct.kind(x) == "Failure" and x["api"] in API_FOLDER]
def flow_item(step, nm, saved, number):
    it = copy.deepcopy(T.get(nm) or T["Reject Proposal"]); it["name"] = f"{number}. {nm}"
    rq, rs = saved["request"], saved["response"]; req = it["request"]
    req["method"] = rq["method"]; req["url"] = url_of(rq["path"], rq.get("query"))
    if rq.get("body") is not None: req["body"] = {"mode": "raw", "raw": raw_body(rq["body"]), "options": {"raw": {"language": "json"}}}
    else: req.pop("body", None)
    it["response"] = [example(req, rs["status"], rs["body"])]
    if step == "cancel-check": it["event"] = [{"listen": "test", "script": {"type": "text/javascript", "exec": CANCEL_CHECK_TEST}}]
    if step == "cancel-approve": it["event"] = [{"listen": "test", "script": {"type": "text/javascript", "exec": CANCEL_APPROVE_TEST}}]
    return it
n = 0; counts = []
for d in sorted(glob.glob(B + "/samples/ref/*_P*"), key=lambda p: (p.rsplit("/", 1)[1].rsplit("_P", 1)[0], int(p.rsplit("_P", 1)[1]))):
    if not os.path.exists(d + "/13_load-cancelled.json"): continue
    tag_p = os.path.basename(d); tag, plan = tag_p.rsplit("_P", 1); code, sub = tag.split("_"); n += 1
    folders = {k: [] for k in ORDER}
    for i, (step, nm, fold) in enumerate(STEPS, 1):
        sv = json.load(open(f"{d}/{i:02d}_{step}.json"))
        if sv["response"]["status"] != 200: continue
        folders[fold].append(flow_item(step, nm, sv, i))
    nfail = 0
    for x in fails:
        pc, sb, pl = pid_sub(x)
        if pc != code: continue
        if sb and str(sb) != sub: continue
        if x.get("product") and x["product"] != tag: continue
        if pl is not None and pl != plan: continue
        folders[API_FOLDER[x["api"]]].append(case_item(f"FAIL {x['id']} - {x['title']}", x, ct.exp_text(x["expect"]))); nfail += 1
    v = VARIANTS.get(tag); title = f"{code} sub {sub}" + (f" ({v})" if v else "") + f" - PlanId {plan}"
    col = base_collection(f"Uponly - {title}", f"Plan collection for {title} in the Uponly tenant. Folder per API: the plan's real success flow (steps in order) followed by the recorded failure examples (FAIL ...) for that API and plan; each failure request has a test asserting the expected HTTP status. Set `token`; baseUrl points to the test route (paths start with /up). Run Get Plans > Create Proposal > Update Proposal > Load Proposal > Issue Policy > Load Policy > Reject Proposal > documents > Cancel Check (Checker) > Cancel Approve (Approver; the saved request uses Decision APPROVE, so the policy becomes Cancelled; send REJECT to keep it in force) > Load Policy (after cancellation). Every proposal carries OrgCode = {{orgCode}} (1). Every request carries ChannelCode = {{channelCode}} (SOHAR). No VAT.")
    col["item"] = [copy.deepcopy(ref["item"][0])] + [{"name": f"{i}. {k}", "item": folders[k]} for i, k in enumerate(ORDER, 1) if folders[k]]
    fn = f"{OUT}/{code}_sub{sub}_Plan{plan}.postman_collection.json"
    json.dump(col, open(fn, "w"), indent=2, ensure_ascii=False)
    counts.append((os.path.basename(fn), sum(1 for f in col["item"] for _ in f.get("item", [])), nfail))
print(len(counts), "collections;", sum(c[1] for c in counts), "requests;", sum(c[2] for c in counts), "failure examples")
for c in counts[:6]: print(c)
