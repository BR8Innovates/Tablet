"""Collects the facts for the policy model workbook and the external API documentation from the build folder (product tables, field rules, code tables, saved samples)."""
import json, os, glob, re, copy
B = os.environ["B"]
TECH = {"BusinessObjectId", "ParentElementType", "ParentPolicyElementId", "PolicyElementId", "PolicyId", "InsertBy", "InsertTime", "UpdateBy", "UpdateTime", "UpdateTimestamp",
        "DataEntryUserId", "DataEntryUserRealName", "FirstDataEntryDate", "OldPrimaryKey", "VersionSeq", "IssueUserId", "IssueUserRealName", "PremCalcFactorHash", "PremCalcResultHash",
        "SchemaVersion", "ProductId", "TechProductId", "TechProductCode", "ProductVersion", "BeforeVatPremium", "AdjustedPremium", "AnnualPremium", "GrossPremium", "StandardGrossPremium",
        "IsPremiumCalcSuccess", "AutoUwResultCode", "BusinessCateCode", "IsRenewable", "IsTakeUpPolicy", "PolicyType", "QuotationDate", "ProposalDate", "SumInsured", "PolicyStatusForDisplay",
        "IsAutoAttachedForm", "SequenceNumber", "IsInsured", "IsOrgParty", "IsPolicyHolder", "InstallmentList", "PolicyStatus_CodeDesc", "TempData"}
def is_tech(k): return k in TECH or k.endswith("_CodeDesc") and k not in ("BranchCode_CodeDesc",) and False or k in TECH
def rows(name):
    d = json.load(open(f"{B}/tables/rows_UP_{name}.json")); return d if isinstance(d, list) else d.get("Records", d)
def products():
    pm = rows("ProductMaster"); pr = rows("ProductRule"); pp = rows("ProductPlanRelation"); pb = rows("PlanBenefitRelation")
    out = []
    for m in pm:
        code, sub = m["IMOProductCode"], m["CarrierProductCode"]
        rule = next((r for r in pr if r["ProductCode"] == code and str(r["ProductSubcode"]) == str(sub)), {})
        plans = [p for p in pp if p["IMOProductCode"] == code and str(p["CarrierProductCode"]) == str(sub) and p.get("IsActive") == "Y"]
        covers = [b for b in pb if b["IMOProductCode"] == code and str(b["CarrierProductCode"]) == str(sub) and b.get("IsApplicable") == "Y"]
        out.append(dict(code=code, sub=sub, name=m["CarrierProductName"], lob=m["LOB"], plans=plans, covers=covers, rule=rule))
    return out
def code_tables():
    out = {}
    for f in sorted(glob.glob(B + "/model/ct_*.json")):
        d = json.load(open(f)); out[os.path.basename(f)[3:-5]] = [(v["Code"], v["Description"]) for v in d.get("BusinessCodeTableValueList", [])]
    return out
def field_rules():
    rows_ = []
    for f in glob.glob(B + "/tables/r_UP_FieldRule_*.json") + glob.glob(B + "/tables/r_carrierrule_*.json"): rows_ += json.load(open(f))
    return sorted(rows_, key=lambda r: int(r["Id"]))
def model_of(path):
    """('PolicyRisk', 'InsuredName') from a rule path such as PolicyLobList[0].PolicyRiskList[0].InsuredName."""
    parts = [re.sub(r"\[\d+\]", "", p) for p in path.split(".")]
    names = {"PolicyLobList": "PolicyLob", "PolicyRiskList": "PolicyRisk", "PolicyCustomerList": "PolicyCustomer", "BeneficiaryList": "BeneficiaryList", "PolicyPaymentInfoList": "PolicyPaymentInfoList", "PlanList": "PlanList", "PolicyCoverageList": "PolicyCoverage"}
    return (names.get(parts[-2], parts[-2]) if len(parts) > 1 else "Policy"), parts[-1]
def sample(tag="UPPA001_1_P1"):
    d = f"{B}/samples/ref/{tag}"; s = {}
    for f in sorted(glob.glob(d + "/[0-9]*.json")):
        j = json.load(open(f)); s[os.path.basename(f)[3:-5]] = j
    return s
def resolve(o, ex):
    t = json.dumps(o)
    for k, v in ex.items(): t = t.replace("{{%s}}" % k, str(v))
    return json.loads(t)
def examples(tag="UPPA001_1_P1"):
    s = sample(tag); r = lambda k: s[k]["response"]["body"]
    ex = {"applicationNo": r("proposal")["ApplicationNo"], "proposalNo": r("proposal")["ProposalNo"], "policyNo": r("issue")["PolicyNo"], "requestNo": r("cancel-check")["RequestNo"],
          "applyDate": r("proposal")["ApplyDate"], "effectiveDate": r("proposal")["EffectiveDate"], "expiry1y": r("proposal")["ExpiryDate"], "cancelDate": r("cancel-check")["CancellationDate"],
          "channelCode": "SOHAR", "orgCode": "1", "rejectProposalNo": r("proposal-for-reject")["ProposalNo"]}
    out = {}
    for k, j in s.items():
        out[k] = dict(method=j["request"]["method"], path=j["request"]["path"], query=resolve(j["request"].get("query"), ex) if j["request"].get("query") else None,
                      request=resolve(j["request"].get("body"), ex) if j["request"].get("body") is not None else None, status=j["response"]["status"], response=j["response"]["body"])
    return out, ex
def trim(o):
    """Public view of a payload: platform technical fields removed."""
    if isinstance(o, dict): return {k: trim(v) for k, v in o.items() if k not in TECH and not k.endswith("_CodeDesc")}
    if isinstance(o, list): return [trim(x) for x in o]
    return o
def top_examples():
    out = {}
    for f in glob.glob(B + "/samples/top/*.json"):
        j = json.load(open(f)); out[os.path.basename(f)[:-5]] = j
    return out
APIS = [  # key in samples, API name, method, path, title, purpose
    ("get-plans", "UPGetPlans", "POST", "/up/get-plans", "Get plans", "Returns every plan of a product variant with premium, commission and covers for the insured details supplied."),
    ("proposal", "UPProposal", "POST", "/up/proposal", "Create proposal", "Creates a proposal (application) for the chosen plan. The premium is calculated by the platform."),
    ("update-proposal", "UPUpdateProposal", "POST", "/up/update-proposal", "Update proposal", "Updates an open proposal (enrolment: beneficiaries, payment details, corrected insured data)."),
    ("issue", "UPIssue", "POST", "/up/issue", "Issue policy", "Issues the policy for an open proposal and returns the policy number."),
    ("load-policy", "UPLoadPolicy", "GET", "/up/load-policy", "Load proposal / policy", "Returns a proposal (by ProposalNo) or an issued policy (by PolicyNo) of the calling channel."),
    ("proposal-reject", "UPProposalReject", "POST", "/up/proposal-reject", "Reject proposal", "Rejects an open proposal."),
    ("doc-policy", "UPDocGeneration", "POST", "/up/doc_generation", "Policy documents (PDF)", "Generates the application form or the policy certificate as PDF (or the print data as JSON)."),
    ("doc-application", "UPApplicationDocGeneration", "POST", "/up/application_doc_generation", "Application form (PDF)", "Generates the application form for a proposal."),
    ("cancel-check", "UPCancelCheck", "POST", "/up/cancel-check", "Cancellation - Checker", "Calculates the refund for a cancellation date and creates the cancellation request."),
    ("cancel-approve", "UPCancelApprove", "POST", "/up/cancel-approve", "Cancellation - Approver", "Approves (cancels the policy) or rejects a pending cancellation request."),
    ("master", "UPListMasterTable", "POST", "/up/list-master-table", "Master data", "Lists the values of a master / code table (relationship, gender, branch, ...)."),
    ("commission", "UPCommissionQuery", "POST", "/up/commission-query", "Commission query", "Commission by policy, by plan configuration or for a period."),
    ("feed", "UPFeedFile", "POST", "/up/generate-feedfile", "Policy feed file", "Generates the policy feed file (Excel, or JSON) for a period."),
]
