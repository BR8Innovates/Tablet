#!/usr/bin/env python3
"""Creates UP_FieldRule, UP_ApiConfig, UP_DocWording, UP_BenefitText in Uponly and loads their rows."""
import json, os, subprocess, sys
B = os.environ["B"]
def imo(args):
    r = subprocess.run(["imo"] + args + ["--profile", "portal:uponly"], capture_output=True, text=True, cwd="/home/user/Tablet"); return r.stdout + r.stderr
def table(name, cols):
    d = json.loads(imo(["config", "datatable", "by-name", "--name", name, "--json"]) or "[]") if False else None
    out = imo(["config", "datatable", "by-name", "--name", name, "--json"])
    try:
        j = json.loads(out); j = j if isinstance(j, list) else [j]
        if j and j[0].get("Name") == name: return j[0]["DataTableId"]
    except Exception: pass
    fields = {}
    for i, (c, t) in enumerate(cols):
        f = {"DataType": t, "Label": c, "Name": c, "Sequence": i}
        if i == 0: f.update({"IsPrimaryKey": "Y", "NotNull": "Y"})
        fields[c] = f
    body = {"CodeTableFlag": "N", "Fields": fields, "GroupId": 127, "IsSmall": "Y", "Name": name, "RecordUsage": 5, "SyncDefinitionOnly": "N"}
    p = f"{B}/tables/def_{name}.json"; json.dump(body, open(p, "w")); imo(["config", "datatable", "create", "--file", p, "--confirm"])
    j = json.loads(imo(["config", "datatable", "by-name", "--name", name, "--json"])); j = j if isinstance(j, list) else [j]
    return j[0]["DataTableId"]
S, L, D = -4, -2, -3
R = "PolicyLobList[0].PolicyRiskList[0]."
rules = []
def rule(api, path, label, req="N", typ="string", minl="", maxl="", pat="", minv="", maxv="", ct="", cc="", enum="", applies="*", wp="", wv=""):
    rules.append(dict(Api=api, Path=path, Label=label, Required=req, DataType=typ, MinLength=minl, MaxLength=maxl, Pattern=pat, MinValue=minv, MaxValue=maxv, CodeTable=ct, CodeColumn=cc, EnumValues=enum, AppliesTo=applies, WhenPath=wp, WhenValue=wv))
DATE = r"^\d{4}-\d{2}-\d{2}$"; DT = r"^\d{4}-\d{2}-\d{2}(T\d{2}:\d{2}:\d{2}(\.\d+)?)?$"
BEN = "UPPA001,TL001,CI001,LP001"
for api, full in (("UPProposal", True), ("UPUpdateProposal", True), ("UPGetPlans", False)):
    rq = "Y" if full else "N"
    rule(api, "ProductCode", "Product code", "Y", "string", 3, 10, r"^[A-Z0-9]+$")
    rule(api, "ProductSubcode", "Product sub code", "Y", "string", 1, 5, r"^[0-9]+$")
    rule(api, "PremiumModeCode", "Premium mode", rq, "string", ct="PremiumMode", cc="Id")
    rule(api, "PolicyTerm", "Policy term (years)", rq, "integer", minv=1, maxv=99)
    rule(api, "EffectiveDate", "Effective date", rq, "date", pat=DATE)
    rule(api, R + "DateOfBirth", "Date of birth", rq, "date", pat=DATE)
    if full:
        rule(api, "ApplicationNo", "Application number", "Y", "string", 1, 30, r"^[A-Za-z0-9/_-]+$")
        rule(api, "ExpiryDate", "Expiry date", "Y", "date", pat=DT)
        rule(api, "ApplyDate", "Application date", "Y", "date", pat=DATE)
        rule(api, "UserName", "User name", "Y", "string", 1, 50)
        rule(api, "BranchCode", "Branch code", "Y", "string", ct="BranchCode", cc="BranchCode")
        rule(api, "StaffId", "Staff id", "N", "string", 1, 20)
        rule(api, "DiscountAmount", "Discount amount", "N", "decimal", minv=0, maxv=1000000)
        rule(api, "PlanId", "Plan id", "Y", "string", ct="Plan", cc="Id")
        rule(api, "PolicyCustomerList[0].CIFNumber", "CIF number", "Y", "string", 1, 20, r"^[0-9]+$")
        rule(api, "PolicyCustomerList[0].CustomerType", "Customer type", "Y", "string", ct="CustomerType", cc="Id")
        rule(api, R + "InsuredName", "Insured name", "Y", "string", 2, 100)
        rule(api, R + "Gender", "Gender", "Y", "string", ct="GenderCode", cc="Id")
        rule(api, R + "Salutation", "Salutation", "Y", "string", ct="Salutation", cc="Id")
        rule(api, R + "IdType", "Id type", "Y", "string", ct="IdType", cc="Id")
        rule(api, R + "IdNo", "Id number", "Y", "string", 3, 30, r"^[A-Za-z0-9-]+$")
        rule(api, R + "ResidentStatus", "Resident status", "Y", "string", ct="ResidentStatus", cc="Id")
        rule(api, R + "MaritalStatus", "Marital status", "Y", "string", ct="InsMaritalStatus", cc="Id")
        rule(api, R + "Mobile", "Mobile number", "Y", "string", pat=r"^[0-9]{7,15}$")
        rule(api, R + "Email", "Email", "N", "string", 5, 100, r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
        rule(api, R + "PostCode", "Post code", "N", "string", 1, 10, r"^[0-9A-Za-z -]+$")
        rule(api, R + "Address", "Address", "Y", "string", 2, 200)
        rule(api, R + "MonthSalaryIncome", "Monthly income", "N", "decimal", minv=0, maxv=100000000)
        rule(api, R + "BeneficiaryList[0].BeneficaryName", "Beneficiary name", "Y", "string", 2, 100, applies=BEN)
        rule(api, R + "BeneficiaryList[0].RelationshipCode", "Beneficiary relationship", "Y", "string", ct="Relationship", cc="Id", applies=BEN)
        rule(api, R + "BeneficiaryList[0].Share", "Beneficiary share %", "Y", "decimal", minv=1, maxv=100, applies=BEN)
        rule(api, R + "BeneficiaryList[0].BeneficarySequence", "Beneficiary sequence", "N", "integer", minv=1, maxv=99)
        req = "Y" if api == "UPUpdateProposal" else "N"
        rule(api, "PolicyPaymentInfoList[0].LGCode", "Payment LG code", req, "string", 1, 10, r"^[0-9]+$")
        rule(api, "PolicyPaymentInfoList[0].LCCode", "Payment LC code", req, "string", 1, 10, r"^[0-9]+$")
        rule(api, "PolicyPaymentInfoList[0].IsInstallment", "Is installment", req, "enum", enum="Y,N")
        rule(api, "PolicyPaymentInfoList[0].DebitAccountNo", "Debit account number", req, "string", 6, 20, r"^[0-9]+$")
        rule(api, "PolicyPaymentInfoList[0].DebitRefNo", "Debit reference number", req, "string", 1, 30, r"^[A-Za-z0-9/_-]+$")
        rule(api, "PolicyPaymentInfoList[0].TransactionDate", "Payment transaction date", req, "date", pat=DATE)
rule("UPUpdateProposal", "ProposalNo", "Proposal number", "Y", "string", 5, 30, r"^[A-Za-z0-9/_-]+$")
rule("UPIssue", "ProposalNo", "Proposal number", "Y", "string", 5, 30, r"^[A-Za-z0-9/_-]+$")
rule("UPIssue", "ProductCode", "Product code", "Y", "string", 3, 10, r"^[A-Z0-9]+$")
rule("UPProposalReject", "ProposalNo", "Proposal number", "Y", "string", 5, 30, r"^[A-Za-z0-9/_-]+$")
rule("UPProposalReject", "ProposalRejectDesc", "Reject reason", "Y", "string", 3, 200)
rule("UPProposalReject", "ProductCode", "Product code", "N", "string", 3, 10, r"^[A-Z0-9]+$")
rule("UPLoadPolicy", "policyNo", "Policy number", "N", "string", 5, 30, r"^[A-Za-z0-9/_-]+$")
rule("UPLoadPolicy", "proposalNo", "Proposal number", "N", "string", 5, 30, r"^[A-Za-z0-9/_-]+$")
rule("UPListMasterTable", "DataTableName", "Data table name", "Y", "string", 2, 40, r"^[A-Za-z_]+$")
rule("UPListMasterTable", "Id", "Record id", "N", "string", 1, 20)
for api in ("UPDocGeneration", "UPApplicationDocGeneration"):
    rule(api, "ProductSubcode", "Product sub code", "N", "string", 1, 5, r"^[0-9]+$")
rule("UPDocGeneration", "DocType", "Document type", "Y", "enum", enum="Application,Policy")
rule("UPDocGeneration", "ProposalNo", "Proposal number", "Y", "string", 5, 30, r"^[A-Za-z0-9/_-]+$", wp="DocType", wv="Application")
rule("UPDocGeneration", "PolicyNo", "Policy number", "Y", "string", 5, 30, r"^[A-Za-z0-9/_-]+$", wp="DocType", wv="Policy")
rule("UPDocGeneration", "PreviewData", "Preview flag", "N", "enum", enum="Y,N")
rule("UPApplicationDocGeneration", "proposalNo", "Proposal number", "Y", "string", 5, 30, r"^[A-Za-z0-9/_-]+$")
rule("UPFeedFile", "Conditions.ProductCode", "Product code", "N", "string", 3, 10, r"^[A-Z0-9]+$")
rule("UPFeedFile", "FromRangeConditions.EffectiveDate", "From effective date", "Y", "date", pat=r"^\d{4}-\d{2}-\d{2}(T\d{2}:\d{2}:\d{2})?$")
rule("UPFeedFile", "ToRangeConditions.EffectiveDate", "To effective date", "Y", "date", pat=r"^\d{4}-\d{2}-\d{2}(T\d{2}:\d{2}:\d{2})?$")
rule("UPFeedFile", "SearchType", "Search type", "Y", "enum", enum="Policy,Proposal")
rule("UPFeedFile", "PageNo", "Page number", "Y", "integer", minv=1, maxv=100000)
rule("UPFeedFile", "PageSize", "Page size", "Y", "integer", minv=1, maxv=50)
rule("UPFeedFile", "OutputFormat", "Output format", "N", "enum", enum="JSON,EXCEL")
rule("UPCommissionQuery", "PolicyNo", "Policy number", "N", "string", 5, 30, r"^[A-Za-z0-9/_-]+$")
rule("UPCommissionQuery", "ProductCode", "Product code", "N", "string", 3, 10, r"^[A-Z0-9]+$")
rule("UPCommissionQuery", "ProductSubcode", "Product sub code", "N", "string", 1, 5, r"^[0-9]+$")
rule("UPCommissionQuery", "PlanId", "Plan id", "N", "string", ct="Plan", cc="Id")
rule("UPCommissionQuery", "FromDate", "From date", "N", "date", pat=DATE)
rule("UPCommissionQuery", "ToDate", "To date", "N", "date", pat=DATE)
rule("UPCommissionQuery", "PageNo", "Page number", "N", "integer", minv=1, maxv=100000)
rule("UPCommissionQuery", "PageSize", "Page size", "N", "integer", minv=1, maxv=50)
cfg = []
def c(key, val, api="*", scope="*"): cfg.append(dict(Api=api, Scope=scope, Key=key, Value=str(val)))
for k, v in [("RiskElementCode", "R00001"), ("PolicyStatusEffective", 2), ("IsAutoAttachedForm", "Y"), ("SequenceNumberStart", 1), ("IsPremiumCalcSuccess", "Y"), ("BusinessCateCode", "1"),
             ("CustomerFlagNo", "N"), ("InstalmentPeriodCount", 1), ("InstalmentPayRate", 1), ("InstalmentFeeSeq", 1), ("InstalmentPeriodSeq", 1), ("InstalmentAmount", 0),
             ("ZeroPremiumValue", 0), ("SuccessStatusText", "SUCCESS"), ("ZeroPremiumFields", "AdjustedPremium,AnnualPremium,BeforeVatPremium,GrossPremium,StandardGrossPremium"),
             ("TemplateVersion", "1"), ("PrintUrl", "https://portal-gw.insuremo.com/mo-fo/1.0/print/v3/printtask/generate"), ("GatewayUrl", "https://portal-gw.insuremo.com"),
             ("MasterTables", "BranchCode,CustomerType,GenderCode,IdType,InsMaritalStatus,Plan,PremiumMode,Relationship,ResidentStatus,Salutation,Document,ProductMaster,ProductRule"),
             ("EffectiveDateMinOffsetDays", 0), ("ProposalStatusIssued", 3), ("FeedFileMaxPageSize", 50), ("CommissionMaxPageSize", 50)]: c(k, v)
wording = []
def w(mode, key, val): wording.append(dict(ModeCode=mode, Key=key, Value=val))
w("1", "FrequencyEn", "Single Premium"); w("1", "FrequencyAr", "دفعة واحدة"); w("1", "PremiumTextEn", "OMR {premium} /-"); w("1", "PremiumTextAr", "{premium} -/")
w("1", "PeriodEn", "{term} year(s) from the Policy Commencement Date"); w("1", "PeriodAr", "{term} سنوات من تاريخ بدء سريان الوثيقة"); w("1", "ModeEn", "Single")
w("3", "FrequencyEn", "Monthly Premium"); w("3", "FrequencyAr", "قسط شهري"); w("3", "PremiumTextEn", "OMR {premium} Monthly"); w("3", "PremiumTextAr", "")
w("3", "PeriodEn", "1 Month(s) from commencement date"); w("3", "PeriodAr", "شهر واحد من تاريخ بدء السريان"); w("3", "ModeEn", "Monthly")
w("2", "FrequencyEn", "Annual"); w("2", "FrequencyAr", "سنوي"); w("2", "PremiumTextEn", "OMR {premium} /- per year"); w("2", "PremiumTextAr", "كل سنة {premium}")
w("2", "PeriodEn", "12 months from the Policy Commencement Date and continues as long as the premium is paid on the due date or within the grace period as per the policy terms and conditions")
w("2", "PeriodAr", "اثنا عشر شهراً من تاريخ بدء سريان الوثيقة وتستمر طالما القسط مسدد عند تاريخ استحقاقه أو خلال فترة الإمهال طبقاً لشروط وأحكام الوثيقة"); w("2", "ModeEn", "Annual")
BT = {"UPPA001:ACD": ("Death due to an accident", "الوفاة الناتجة عن حادث"), "UPPA001:PTD": ("PTD due to an accident", "العجز الكلي الدائم نتيجة حادث"), "UPPA001:PPD": ("PPD due to an accident", "العجز الجزئي الدائم نتيجة حادث"),
 "UPPA001:TTD": ("TTD due to an accident", "العجز الكلي المؤقت نتيجة حادث"), "UPPA001:HCB": ("Hospital Cash Benefit due to an accident", "منفعة الاستشفاء النقدية نتيجة حادث"), "UPPA001:REX": ("Repatriation Expenses", "مصاريف نقل الجثمان"),
 "TL001:DTH": ("Death due to any cause", "الوفاة الناتجة لأي سبب"), "TL001:PTD": ("PTD due to any cause", "العجز الكلي الدائم الناتج لأي سبب"), "TL001:PPD": ("PPD due to any cause", "العجز الجزئي الدائم لأي سبب"),
 "TL001:TRV": ("Annual Family Travel", "سفر عائلي سنوي"), "TL001:REX": ("Repatriation Expenses", "مصاريف نقل الجثمان"), "LP001:DTH": ("Death due to any cause", "الوفاة الناتجة لأي سبب"),
 "LP001:PTD": ("PTD due to any cause", "العجز الكلي الدائم الناتج لأي سبب"), "LP001:PPD": ("PPD due to any cause", "العجز الجزئي الدائم الناتج لأي سبب"), "DH001:DTH": ("Death due to any cause", "الوفاة الناتجة لأي سبب"),
 "DH001:AME": ("Accidental Medical Expenses", "المصاريف الطبية نتيجة حادث"), "DH001:RHE": ("Replacement Domestic Helper Expenses", "مصاريف عامل المنزل البديل"), "DH001:REP": ("Repatriation due to Death", "مصاريف نقل الجثمان")}
bt = [dict(ProductCode=k.split(":")[0], BenefitCode=k.split(":")[1], NameEn=v[0], NameAr=v[1]) for k, v in BT.items()]
sets = [("UP_FieldRule", [("Id", S), ("Api", S), ("Path", S), ("Label", S), ("Required", S), ("DataType", S), ("MinLength", L), ("MaxLength", L), ("Pattern", S), ("MinValue", D), ("MaxValue", D), ("CodeTable", S), ("CodeColumn", S), ("EnumValues", S), ("AppliesTo", S), ("WhenPath", S), ("WhenValue", S)], rules),
        ("UP_ApiConfig", [("Id", S), ("Api", S), ("Scope", S), ("Key", S), ("Value", S)], cfg),
        ("UP_DocWording", [("Id", S), ("ModeCode", S), ("Key", S), ("Value", S)], wording),
        ("UP_BenefitText", [("Id", S), ("ProductCode", S), ("BenefitCode", S), ("NameEn", S), ("NameAr", S)], bt)]
which = sys.argv[1:] or [x[0] for x in sets]
for name, cols, rows in sets:
    if name not in which: continue
    tid = table(name, cols); print(name, tid, len(rows), flush=True)
    recs = []
    for i, r in enumerate(rows, 1):
        rr = {"Id": str(i), "DataTableId": tid, "RecordUsage": 5}
        for k, v in r.items():
            if v != "" and v is not None: rr[k] = v
        recs.append(rr)
    for i in range(0, len(recs), 40):
        p = f"{B}/tables/r_{name}_{i}.json"; json.dump(recs[i:i+40], open(p, "w"))
        out = imo(["config", "datatable", "record-batch-save", "--file", p, "--confirm"]); print("  batch", i, "ok" if "@pk" in out else out[:150], flush=True)
