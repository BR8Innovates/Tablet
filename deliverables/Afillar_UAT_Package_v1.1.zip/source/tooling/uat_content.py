"""UAT deployment plan content (block list) + data for the checklist workbook."""
import json, os
import code_facts as cf
INSURER = "Afillar Insurance Company"
blocks = []
def H1(t): blocks.append(("h1", t))
def H2(t, page=False): blocks.append(("h2", t, page))
def P(t): blocks.append(("p", t))
def NOTE(t): blocks.append(("note", t))
def BUL(i): blocks.append(("bul", i))
def NUM(i): blocks.append(("num", i))
def TBL(h, r, w=None): blocks.append(("tbl", h, r, w))
def LBL(t): blocks.append(("lbl", t))
def CODE(t): blocks.append(("code", t))
B = os.environ["B"]; T = cf.tables; assets = cf.assets
prods = json.load(open(B + "/products.json"))
ORDER = ["UPDataUtil", "UPSecurity", "UPErrorHandler", "UPPlatformClient", "UPValidator", "UPProductData", "UPShaper", "UPDocBuilder", "UPDocService", "UPCancelService"]
APIS = ["UPGetPlans", "UPProposal", "UPUpdateProposal", "UPIssue", "UPLoadPolicy", "UPProposalReject", "UPDocGeneration", "UPApplicationDocGeneration", "UPCancelCheck", "UPCancelApprove", "UPListMasterTable", "UPCommissionQuery", "UPFeedFile"]
APIS = [a for a in APIS]
meta = {(a["kind"], a["name"]): a for a in assets}
TABLE_ORDER = ["UP_Channel", "UP_Carrier", "UP_ProductMaster", "UP_ProductRule", "UP_ProductPlanRelation", "UP_PlanBenefitRelation", "UP_DocTemplate", "UP_DocWording", "UP_BenefitText", "UP_FeedColumn", "UP_FieldRule", "UP_ApiConfig"]
ENVKEYS = [("AllowedHosts", "Host(s) the caller's token may be sent to (comma separated, https only)", "UAT gateway host"), ("GatewayUrl", "Base URL of the platform gateway used for the endorsement REST calls", "UAT gateway URL"),
           ("PrintUrl", "Print service URL used for the PDFs", "UAT print service URL (same host as the gateway)")]
# ================================================================== 1
H1("1. Purpose and Scope")
P(f"This document answers two questions for the {INSURER} insurance APIs: **what has to be deployed**, and **how the deployment from the MC tenant to UAT is done and verified**. Everything described here currently exists only in the MC (development) tenant. Nothing has been deployed to UAT: this is the plan.")
TBL(["Item", "Value"], [["Source tenant (MC)", "tenant code `uponly`, profile `portal:uponly`, gateway https://portal-gw.insuremo.com"], ["Target tenant (UAT)", "to be confirmed: tenant code, `imo` profile and gateway of UAT (placeholders `<UAT>` below)"], ["Scope", "10 common functions, 12 active APIs, 12 iTables with their rows, product configuration of 7 products, 14 output templates, environment settings, access"],
    ["Not in scope", "PA001 (must already exist in UAT or is not needed), the retired API `UPCancelPolicy`, test data, scripts and reports"], ["Release", "Insurance API kit v1.1 (insurer CarrierCode / CarrierName added), specification v1.1, policy model v0.4"]], [24, 76])
H2("1.1 Assumptions and Open Items")
TBL(["#", "Assumption / open item", "Owner"], [
    ["1", "UAT is a separate InsureMO tenant reachable with `imo` (profile name, tenant code and gateway to be provided).", "Project / platform team"],
    ["2", "The deployer has admin rights in UAT for iComposer, iTables, product configuration, Output Service and code tables.", "Platform team"],
    ["3", "PA001 exists in UAT (the new products were created as copies of its structure). If PA001 does not exist in UAT, section 5.3 lists what must be created first.", "Platform team"],
    ["4", "The partner (Sohar Bank) API users for UAT, with the Checker and Approver roles, are created by the platform team; credentials are not part of this package.", "Platform team"],
    ["5", "Ids of products, data tables, templates and data-dictionary objects differ per tenant and are re-resolved during the deployment, never copied.", "Deployer"],
    ["6", "Write access to configuration is allowed in UAT for the deployer account (it is required to load the tables).", "Platform team"]], [6, 74, 20])
# ================================================================== 2
H1("2. What Has to Be Deployed")
P("Six groups, A to F. Each group is described in sections 3 to 8; the order in which they are deployed is in section 9 (A, C, E, B, D, F).")
TBL(["#", "Group", "Contents", "Count", "Method"], [
    ["A", "Platform prerequisites", "Code tables, field library, PA001 base objects, PubBranch value 1, API users", "see 3", "Platform admin"],
    ["B", "Product configuration", "7 tech + 7 market products, data dictionary bindings, 7 rating definitions, cancellation delta fields", "14 products", "`build_product.py`, `rating_build.py`, `fix_endo_fields.py`"],
    ["C", "iTables", "12 `UP_` tables (definition + rows)", "12 tables, about 550 rows", "`imo config datatable create` + `record-batch-save`"],
    ["D", "Output templates", "Application form and certificate templates per product", "14 templates", "Output Service upload (`os_gen.py`)"],
    ["E", "iComposer code", "10 functions, 12 active APIs (13th stays inactive)", "22 files", "`imo icomposer push current`"],
    ["F", "Environment settings and access", "3 environment specific config values, channel row, gateway route, API users and roles", "-", "Row changes + platform admin"]], [5, 20, 40, 14, 21])
# ================================================================== 3
H1("3. Group A — Platform Prerequisites in UAT")
P("These must exist before anything else is loaded. Check each one in UAT; create it only if it is missing.")
TBL(["Prerequisite", "Why", "How to check"], [
    ["PA001 and PA001_TECH products", "The new products were built from its structure; the rating definitions were copied from `PA001_PREM_CALC`", "`imo config product list --code PA001 --profile <UAT>`"],
    ["Tenant tables used by the code and as code tables: BranchCode (001), CustomerType, GenderCode, IdType, InsMaritalStatus, Plan (ids 1-5), PremiumMode (1, 2, 3), Relationship, ResidentStatus, Salutation", "Code tables behind the validation rules and the data dictionary bindings; also listed by Master Data", "`imo config datatable by-name --name <T>` and `imo config codetable data --name <T>`; values must equal MC (see the specification section 5.1)"],
    ["Code table PubBranch with value `1`", "Cancellation endorsement validation checks OrgCode against it", "`imo config codetable data --name PubBranch`"],
    ["Field library entries of the data dictionary (ApplicationNo, ApplyDate, BranchCode, CIFNumber, DiscountAmount, StaffId, UserName, PlanId, PolicyTerm, PremiumModeCode, ProductSubcode, ChannelCode, Payment* ...)", "Fields bound to the new products; ids in `fields_created.json` are MC ids", "`policy_field.py search-fields --name <Field>`; create missing ones with `fields.py`"],
    ["Cancellation endorsement rating definition (\"Cancellation Endorsement\", tenant level)", "Used by `calculateEx`; identical in the other tenants checked", "`rating_api.py definition-load`"],
    ["API users, roles (Checker, Approver), gateway route to the iComposer APIs, token (CAS) endpoint for the partner", "Access to the APIs", "Platform admin"]], [38, 34, 28])
# ================================================================== 4
H1("4. Group B — Product Configuration")
P("For each of the seven product codes the following objects are created in UAT with the same names; the ids will differ.")
TBL(["Product code", "Tech product", "Market product", "MC tech id", "MC market id", "Rating definition"],
    [[c, c + "_TECH", c, str(v["tech"]), str(v["market"]), c + "_PREM_CALC"] for c, v in prods.items()], [14, 16, 14, 16, 16, 24])
H2("4.1 Contents Per Product")
BUL(["Tech product with the policy tree: Policy, Product (PolicyLob), Insured R00001 (PolicyRisk), Plan, PolicyCoverage, Beneficiary; the product-level field bindings (24 policy, 17 tech, 8 risk, 4 plan, 6 coverage, 4 beneficiary fields) and the code-table links (`step_codetables`).",
     "Market product bound to the tech product and the premium rating definition `<CODE>_PREM_CALC` (copy of `PA001_PREM_CALC` bound to the market product, patched to read the `UP_` tables).",
     "Cancellation delta fields on the tech product (`StandardGrossPremiumDelta`, `AnnualPremiumDelta`, `ShortRate` on the objects the platform reports as missing): `fix_endo_fields.py <TAG>` run against a test policy of each product (it binds only on the seven tech products).",
     "No `VAT` binding is created (there is no VAT in this solution)."])
H2("4.2 How")
NUM(["`build_product.py spec_<CODE>.json all` with `GW`, `TOK` and `B` pointing to UAT (steps tech, tree, fields, codetables, market).", "`rating_build.py <CODE> --confirm`, then `patch_rating.py` / `patch_rating2.py` (re-point the formulas to the `UP_` tables).",
     "Create and issue one test policy per product (after group C and E), run `fix_endo_fields.py <TAG>` until the platform calculation passes (\"CALCULATE OK\").", "Record the new product ids (`prod_info.py` writes `products.json`)."])
# ================================================================== 5
H1("5. Group C — iTables")
P("Create the tables in this order (the order does not matter technically, but the checks in section 8 assume it). Rows are written with `record-batch-save` in batches of 40; the primary key `Id` must be unique. The MC row files are in `tables/` (`r_*.json`); they must be re-read from MC just before the deployment so that the latest rows (for example the insurer rows) are included. The `DataTableId` inside the rows is a tenant id and must be replaced by the UAT table id (`uptab.py` does this).")
rows = []
for n in TABLE_ORDER:
    d = T[n]; rows.append([n, str(d["rows"]), ", ".join(f[0] for f in d["fields"] if f[0] != "Id")[:80], "Environment specific rows: " + ("AllowedHosts, GatewayUrl, PrintUrl" if n == "UP_ApiConfig" else ("channel(s) of the UAT partner" if n == "UP_Channel" else "none"))])
TBL(["Table", "Rows (MC)", "Columns", "Environment note"], rows, [18, 8, 46, 28])
H2("5.1 Row Sources")
TBL(["Table", "Source of the rows"], [["UP_ApiConfig", "`tables/r_cfg*.json`, `r_UP_ApiConfig_*.json` (about 81 keys) — or export from MC with `record-list`"], ["UP_FieldRule", "`tables/r_UP_FieldRule_*.json`, `r_carrierrule_0.json` (138 rows)"], ["UP_ProductMaster / ProductPlanRelation / PlanBenefitRelation / ProductRule / DocTemplate", "`tables/b_UP_*` and `rows_UP_*.json`"],
    ["UP_DocWording, UP_BenefitText", "`r_UP_DocWording_*`, `r_wordA_*`, `r_UP_BenefitText_*`, `r_benA_*`"], ["UP_FeedColumn", "`r_feedcol*.json`, `r_carrierfeed_0.json` (29 rows)"], ["UP_Channel / UP_Carrier", "`r_channel_0.json`, `r_carrier_0.json` (SOHAR = Sohar Bank; AFIC = Afillar Insurance Company)"]], [34, 66])
H2("5.2 Change Before Loading")
BUL(["`UP_ApiConfig`: set `AllowedHosts`, `GatewayUrl`, `PrintUrl` to the UAT gateway (section 7).", "`UP_Channel`: the UAT channel code(s) of the partner.", "Everything else is loaded unchanged."])
H2("5.3 If PA001 Is Not in UAT")
P("The solution does not read or change PA001 at run time, but the product structure and the rating were derived from it. In that case the platform team must provide the PA001 structure first, or the products must be built from the product specs without the copy (`build_product.py` creates the tree itself; only the rating definitions are copied from `PA001_PREM_CALC`).")
# ================================================================== 6
H1("6. Group D — Output Templates")
P("The application form and the policy certificate PDFs are produced by Output Service templates named in `UP_DocTemplate`. They must exist in UAT under the same names. The templates live in the MC Output Service (the generated HTML working copies are not kept in the build folder; the images are in `assets/`): export them from MC, or rebuild them with `make_templates2.py` from the form designs.")
names = sorted({r["TemplateName"] for r in T["UP_DocTemplate"]["records"]})
TBL(["#", "Template name", "Used for"], [[str(i), n, "Application form" if "APPLICATION" in n else "Policy certificate"] for i, n in enumerate(names, 1)], [6, 52, 42])
NUM(["Export the 14 templates from the MC Output Service (or rebuild them with `make_templates2.py` from the form designs and the images in `assets/`).", "Upload each template to the UAT Output Service with `os_gen.py <TEMPLATE_NAME> <html> <data.json> <out.pdf>` (uploads and generates a test PDF).", "Compare the generated PDF with the MC PDF (layout, Arabic text, images)."])
# ================================================================== 7
H1("7. Group F — Environment Settings and Access")
TBL(["UP_ApiConfig key", "Meaning", "UAT value"], [list(x) for x in ENVKEYS], [22, 50, 28])
BUL(["`ChannelCode` of the partner: row in `UP_Channel`; the partner sends this code on every request.", "`OrgCode`: the branch code accepted by PubBranch in UAT (1).", "Test route versus runtime route: the APIs answer on `/platform/api-orchestration-test/v1/flow/up/...` after the push; the runtime route and its gateway policy (token, rate limiting, CORS) are set by the platform team.",
     "API users and roles: one Checker and one Approver user for the partner; the APIs do not check roles yet (deferred), so the separation is organisational until role access is built.", "Secrets: tokens and passwords never go into tables, collections or documents."])
# ================================================================== 8
H1("8. Group E — iComposer Code")
P("Push in this order (callee before caller). `Compiled: yes` must be shown for every push; a failed compile stops the deployment.")
rows = []; n = 0
for f in ORDER:
    n += 1; m = meta[("function", f)]; rows.append([str(n), f, "Function", str(m["lines"]), str(m["version"]), m["md5"][:10] if m.get("md5") else ""])
for a in APIS:
    n += 1; m = meta[("api", a)]; rows.append([str(n), a, f"API {m['path']}", str(m["lines"]), str(m["version"]), m["md5"][:10] if m.get("md5") else ""])
TBL(["Order", "Asset", "Kind / route", "Lines", "MC version", "MC md5 (first 10)"], rows, [7, 26, 30, 8, 12, 17])
NOTE("`UPCancelPolicy` (retired, inactive) is not deployed. `UPSecurity` and the `UP_Carrier` table are new in v1.1 and must be present before `UPProductData` and `UPShaper` (the shaper reads the insurer).")
H2("8.1 How")
NUM(["Export the current MC sources (`imo icomposer reload` into a clean workspace) so that the deployed code equals the code in the package.", "Initialise a UAT workspace (`imo icomposer init`) and create the module group, then `imo icomposer create function` for each function (name, module id, group id, status 1, scope 1) and `create api` for each API (path and method as in the table above; POST except load-policy GET).",
     "Copy the Groovy files into the UAT workspace and push each file in the order above: `imo icomposer push current <file> --profile <UAT>`.", "Re-run `push` for a file that reports a conflict with `--prefer-local` only after comparing the server copy."])
# ================================================================== 9
H1("9. Deployment Sequence")
TBL(["Step", "Action", "Owner", "Evidence"], [
    ["0", "Freeze MC: no changes during the deployment; export the final MC rows and sources; run `snapshot.py before` in UAT (if PA001 exists)", "Developer", "snapshot files"],
    ["1", "Group A: confirm or create the prerequisites (section 3)", "Platform team", "checklist"],
    ["2", "Group C: create the 12 tables and load the rows with the environment values (section 5)", "Developer", "row counts equal MC (+ environment changes)"],
    ["3", "Group E: push 10 functions then 12 APIs in order (section 8); every compile OK", "Developer", "push log"],
    ["4", "Group B: create products, bindings, ratings (section 4)", "Developer + platform", "product list, rating loads"],
    ["5", "Group D: upload and test the 14 templates (section 6)", "Developer", "test PDFs"],
    ["6", "Group F: environment settings, channel row, users and roles, gateway route (section 7)", "Platform team", "config rows, user list"],
    ["7", "Smoke test: `carrier_check.py` (one flow per product) and `ref_flow.py` for one plan per product, Newman run of the Sohar Bank collection against UAT", "Developer / QA", "results files, Newman log"],
    ["8", "Security probe `security_probe.py` against UAT (after step 7 passes)", "QA / security", "probe results"],
    ["9", "Compare the UAT table row counts and the asset list with MC; `snapshot.py after` (PA001 unchanged)", "Developer", "comparison"],
    ["10", "Sign-off and go / no-go (section 12)", "Project", "signed checklist"]], [6, 56, 18, 20])
# ================================================================== 10
H1("10. Verification in UAT")
TBL(["Check", "Expected", "Tool"], [
    ["Every API answers 200 for a valid request, one product at a time", "7 products x 8 calls pass, `CarrierCode` AFIC and the insurer name in every response", "`carrier_check.py`"],
    ["13-step flow for one plan per product incl. documents and cancellation", "all steps 200, policy status 3 after APPROVE, refund returned", "`ONLY_PLAN=1 ref_flow.py <TAG>`"],
    ["Free look and pro-rata refund", "day 15 = 100%, day 16 = 80% pro-rata (see the specification section 6.2)", "`run_tests.py all ST` (cancellation by product block)"],
    ["Error contract", "400 / 404 / 409 bodies with `trace_id`; no stack traces", "`security_probe.py`"],
    ["Security", "no FAIL other than the known gateway findings", "`security_probe.py`"],
    ["PDFs", "application form and certificate render for every product", "collection folders / `os_gen.py`"],
    ["Master data", "code tables equal MC; `UP_Carrier` lists AFIC", "`/up/list-master-table`"],
    ["PA001 guard", "PA001 and PA001_TECH hashes unchanged", "`snapshot.py`"]], [34, 44, 22])
# ================================================================== 11
H1("11. Rollback")
BUL(["Code: keep the exported MC sources and the UAT sources of the previous push; roll back by pushing the previous files in the reverse order (APIs first, then functions).", "Tables: before loading, export the existing UAT rows (if any); rollback = delete the added rows (`record-batch-delete`) or `record-delete-all` for a table created by this deployment and restore the export.",
     "Products: new products are not used by anything else; if they must be removed, deactivate the market products (do not touch PA001).", "Templates: restore the previous template version in the Output Service.", "Because the APIs read tables at run time, a bad row can be corrected by a row change; no code deployment is needed for data fixes."])
# ================================================================== 12
H1("12. Risks, Dependencies and Go / No-Go")
TBL(["Risk / dependency", "Impact", "Mitigation"], [
    ["Ids differ per tenant (products, data tables, templates, DD objects)", "Copying MC ids breaks the configuration", "Re-resolve by name with the build scripts; never copy ids"], ["PA001 or the base code tables missing in UAT", "Products and rating cannot be built", "Check group A first"],
    ["Cancellation delta fields not bound", "APPROVE returns 409 at calculation", "Run `fix_endo_fields.py` per product (section 4.2)"], ["PubBranch has no value 1 in UAT", "APPROVE returns 409 at validation", "Add the value or change the `OrgCode` override"],
    ["Wrong host in `AllowedHosts` / `GatewayUrl` / `PrintUrl`", "Cancellation and documents fail with `UP-CONFIG` / host error", "Set the three keys to the UAT gateway before smoke tests"], ["Role access not built", "Checker / Approver separation is organisational only", "Agree the interim control with the partner; build the access table later"],
    ["Gateway findings (CORS, rate limiting)", "Known platform level observations", "Platform team before production"], ["Per-plan collections not refreshed", "Examples lack the insurer fields", "Optional: regenerate after UAT"]], [34, 30, 36])
H2("12.1 Go / No-Go Checklist")
TBL(["#", "Criterion", "Status", "Signed by"], [[str(i), c, "", ""] for i, c in enumerate([
    "Group A prerequisites confirmed in UAT", "12 tables loaded, row counts verified", "10 functions and 12 APIs pushed, all compiled", "7 products, bindings and rating definitions created", "14 templates uploaded, PDFs checked", "Environment keys, channel row, users, roles and route set",
    "carrier_check.py: all products pass", "Plan flow with cancellation passes for one plan per product", "Security probe: no unexplained FAIL", "PA001 snapshot identical", "Rollback tested on one table and one function", "Partner informed of the UAT URL and credentials process"], 1)], [6, 70, 12, 12])
