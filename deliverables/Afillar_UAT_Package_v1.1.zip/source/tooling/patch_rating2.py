import os,json,subprocess,sys
B=os.environ['B']; GW=os.environ['GW']; TOK=os.environ['TOK']
R=["python3","/tmp/insuremo/insuremo-gi-rating-config/scripts/rating_api.py"]
def api(cmd,payload=None,extra=None,confirm=False):
    a=R+[cmd]+(extra or [])+(["--confirm"] if confirm else [])+["--gateway",GW,"--token",TOK]
    r=subprocess.run(a,input=json.dumps(payload) if payload is not None else None,capture_output=True,text=True); o=r.stdout+r.stderr
    try: return json.loads(o[o.index("{"):])
    except Exception: return {"raw":o[-300:]}
mode=sys.argv[1]
for code in sys.argv[2:]:
    d=api("definition-load",extra=["--code",f"{code}_PREM_CALC"]); vid=d["VersionList"][0]["VersionId"]
    ver=api("version-load",extra=["--version-id",str(vid)])
    for n in ver.get("TopCalcList",[]):
        for st in n["CalculationSteps"]:
            if st["Name"] in("AllPlanPremium","PlanPremium"):
                full=api("step-load",extra=["--step-id",str(st["StepId"])]); fc=full["FormulaContent"]; new=fc
                if mode=="norvat":
                    new=new.replace("\nPolicy().Vat.update(0)\nPolicyLob().Vat.update(0)","")
                    if "def prem=selRow.Premium" in new and "round(2)" not in new:
                        new=new.replace("def prem=selRow.Premium\n\tdef comm=selRow.Commission","def prem=(selRow.Premium as BigDecimal).setScale(2, java.math.RoundingMode.HALF_UP)\n\tdef comm=(selRow.Commission as BigDecimal).setScale(2, java.math.RoundingMode.HALF_UP)")
                if mode=="noplanprem":
                    for line in ("Plans[i].DuePremium.update(prem)","Plans[i].Commission.update(comm)"):
                        new=new.replace(line,"//"+line)
                if new==fc: print(code,st["Name"],"no change"); continue
                full["FormulaContent"]=new; print(code,st["Name"],api("step-save",full,["--mode","update"],True))
