#!/usr/bin/env python3
"""Admin script: makes the platform's cancellation calculation pass for an Uponly product by binding the fields it reports as 'not bound'.
usage: fix_endo_fields.py TAG [TAG ...]        (e.g. FP001_1)
For each product: takes an issued Uponly policy, creates a cancellation endorsement, runs calculateEx, reads the 'Field was not bound' error,
creates the binding on the Uponly TECH product only (never PA001), and repeats. The pending endorsement is always suspended afterwards.
Every binding created is logged to endo_fix_fields.log."""
import json, os, re, sys, subprocess, time, glob, urllib.request, urllib.parse, urllib.error
from datetime import date, timedelta
B = os.environ["B"]; GW = os.environ["GW"]; TOK = os.environ["TOK"]
H = {"Authorization": "Bearer " + TOK, "Content-Type": "application/json", "x-mo-tenant-id": "uponly"}
E = "/platform/endo/core/endo/v1"
PRODUCTS = json.load(open(B + "/products.json")); ALLOWED = {v["tech"] for v in PRODUCTS.values()}   # only these product contexts may be changed
allf = json.load(open(B + "/dd/_tenant_fields.json")); up = {}
for grp in allf:
    for f in allf[grp]: up.setdefault(f["name"], f)
PF = ["python3", "/tmp/insuremo/insuremo-gi-product-config/scripts/policy_field.py", "--gateway", GW, "--token", TOK, "--workspace", B + "/ws"]
LOG = open(B + "/endo_fix_fields.log", "a")
def log(m): print(m, flush=True); LOG.write(time.strftime("%H:%M:%S ") + m + "\n"); LOG.flush()
def call(m, path, body=None):
    req = urllib.request.Request(GW + path, data=json.dumps(body).encode() if body is not None else (b"" if m == "POST" else None), method=m, headers=H)
    try:
        with urllib.request.urlopen(req, timeout=240) as r: return r.status, r.read().decode()
    except urllib.error.HTTPError as e: return e.code, e.read().decode()
def withdraw(p):
    s, t = call("GET", E + "/queryPendingEndo?policyId=" + p["PolicyId"])
    if s == 200 and t.strip().startswith("{"): call("POST", E + "/suspendEndorsement?endoId=" + str(json.loads(t)["EndoId"]))
def bind(techid, obj, name):
    if int(techid) not in ALLOWED: raise SystemExit("refusing to change context %s: not an Uponly tech product" % techid)
    f = up.get(name); ftype = f["type"] if f else -3
    b = {"BusinessObjectId": obj, "FieldType": ftype, "FieldName": name, "FieldCommentsEn": name, "FieldLabelEn": name, "IsFixed": "N", "IsDeprecated": "N", "IsMandatory": "N", "IsTemp": "N", "IsUnique": "N", "IsIndexed": "N", "IsInput": "Y"}
    if f and f.get("ct"): b["CodeTableName"] = f["ct"]
    path = f"{B}/payloads/endofix2_{name}_{obj}.json"; json.dump({"ContextTypeId": "5", "ContextId": str(techid), "BusinessFieldBinding": b}, open(path, "w"))
    r = subprocess.run(PF + ["--body-file", path, "--confirm", "create-binding"], capture_output=True, text=True)
    ok = "BindingId" in r.stdout; log(f"   bind {name} on object {obj} (product tech {techid}, type {ftype}): " + ("ok" if ok else r.stdout[-200:].replace("\n", " ")))
    return ok
def run(tag):
    code = tag.split("_")[0]; techid = PRODUCTS[code]["tech"]
    po = json.load(open(glob.glob(f"{B}/samples/ref/{tag}_P1/06_load-policy.json")[0]))["response"]["body"]["PolicyNo"]
    s, t = call("GET", f"/platform/proposal/v1/load?policyNo={po}"); p = json.loads(t)
    if str(p.get("PolicyStatus")) != "2": log(f"{tag} {po}: policy not in force ({p.get('PolicyStatus')}), skipped"); return "skipped"
    eff = (date.today() + timedelta(days=60)).isoformat(); seen = set(); log(f"== {tag} policy {po}")
    for i in range(25):
        withdraw(p)
        env = {"EndoEffectiveDate": eff, "EndoType": "3", "CancelType": "32", "CancelReasonCode": "1", "OtherCancelReason": "field check", "PolicyNo": po, "ProductId": p["ProductId"], "ProductCode": p["ProductCode"],
               "EndorsementPaymentInfoList": [{"PayModeCode": "30", "IsInstallment": "Y", "InstallmentType": "1"}]}
        s, t = call("POST", E + "/createEx", env)
        if s != 200: log("   create failed: " + t[:200]); return "create-failed"
        s, t = call("POST", E + "/calculateEx", json.loads(t))
        withdraw(p)
        if s == 200: log("   CALCULATE OK"); return "ok"
        m = re.search(r"(?:businessObjectId|ObjectId)=(\d+).{0,200}?(?:businessFiledName|businessField\.field)=(\w+)", t, re.S)
        if not m: log("   OTHER ERROR: " + t[:400].replace("\n", " ")); return "other-error"
        obj, name = int(m.group(1)), m.group(2); key = (obj, name)
        if key in seen: log(f"   {name} on {obj} is still reported after binding it: stop"); return "not-fixable"
        seen.add(key); log(f"   missing {name} on object {obj}")
        if name.upper() == "VAT": log("   VAT is reported for the policy object: not created here (needs the admin fix or an authorised workaround)"); return "vat"
        if not bind(techid, obj, name): return "bind-failed"
    return "gave-up"
if __name__ == "__main__":
    args = [a for a in sys.argv[1:] if not a.startswith("--prebind=")]
    pre = [a.split("=", 1)[1] for a in sys.argv[1:] if a.startswith("--prebind=")]
    for t in args:
        for name in (pre[0].split(",") if pre else []):
            code = t.split("_")[0]; log(f"== prebind {name} on the policy object of {code}"); bind(PRODUCTS[code]["tech"], PRODUCTS[code]["policyObj"], name)
        print(t, "->", run(t))
