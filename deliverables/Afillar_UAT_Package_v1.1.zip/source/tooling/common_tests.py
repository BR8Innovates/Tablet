import json, os, glob, re
B = os.environ["B"]
KNOWN = ["UPPA001", "TL001", "FP001", "HC001", "CI001", "LP001", "DH001"]
def load():
    res = json.load(open(B + "/tests/results.json"))
    return res
def product_of(r):
    b = r.get("body")
    if isinstance(b, dict):
        pc = b.get("ProductCode") or (b.get("Conditions") or {}).get("ProductCode") if isinstance(b.get("Conditions", None), dict) or b.get("ProductCode") else b.get("ProductCode")
        if pc in KNOWN: return pc
    if r.get("product"): return r["product"].split("_")[0]
    return "Common"
def sub_of(r):
    if r.get("product") and "_" in r["product"]: return r["product"].split("_")[1]
    b = r.get("body")
    if isinstance(b, dict) and b.get("ProductSubcode"): return str(b["ProductSubcode"])
    return ""
def kind(r):
    e = r["expect"]
    return "Success" if e.get("status") == 200 else "Failure"
def exp_text(e):
    if e.get("errors"): return "400 " + ", ".join(f"{f}/{c}" for f, c in e["errors"])
    if e.get("status_in"): return "/".join(map(str, e["status_in"]))
    x = str(e.get("status", ""))
    if e.get("plans"): x += f", {e['plans']} plans"
    if e.get("nonempty"): x += ", list not empty"
    if e.get("empty"): x += ", empty list"
    return x
def trace(r):
    b = r.get("response")
    return b.get("trace_id", "") if isinstance(b, dict) else ""
