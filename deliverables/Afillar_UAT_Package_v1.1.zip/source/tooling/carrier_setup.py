#!/usr/bin/env python3
"""Creates the insurer table UP_Carrier and the rows that expose CarrierCode / CarrierName (field rules, feed columns, master table list). Idempotent: ids are fixed."""
import sys, json
sys.path.insert(0, ".")
from uptab import *
tid = table("UP_Carrier", [("CarrierCode", S), ("CarrierName", S), ("IsActive", S)])
print("UP_Carrier table id", tid)
save("UP_Carrier", tid, [dict(CarrierCode="AFIC", CarrierName="Afillar Insurance Company", IsActive="Y")], 1, "carrier")
FR = 1188575333; FC = 1188591810; CFG = 1188575596
rules = []
for i, api in enumerate(("UPGetPlans", "UPProposal", "UPUpdateProposal")):
    rules.append(dict(Api=api, Path="CarrierCode", Label="Carrier code", Required="N", DataType="string", MinLength=2, MaxLength=10, Pattern="^[A-Z0-9_]+$", CodeTable="UP_Carrier", CodeColumn="CarrierCode", AppliesTo="*"))
save("UP_FieldRule", FR, rules, 136, "carrierrule")
save("UP_FeedColumn", FC, [dict(Sequence=27, Heading="Carrier Code", Source="CarrierCode"), dict(Sequence=28, Heading="Carrier Name", Source="CarrierName")], 27, "carrierfeed")
save("UP_ApiConfig", CFG, [dict(Api="*", Scope="*", Key="MasterTables", Value="BranchCode,CustomerType,GenderCode,IdType,InsMaritalStatus,Plan,PremiumMode,Relationship,ResidentStatus,Salutation,Document,ProductMaster,ProductRule,UP_Carrier")], 19, "carriermaster")
print("done")
