import json,os,sys,urllib.request,urllib.parse,urllib.error
GW=os.environ['GW']; TOK=os.environ['TOK']; po=sys.argv[1]
H={"Authorization":"Bearer "+TOK,"Content-Type":"application/json","x-mo-tenant-id":"uponly"}
def call(m,path,body=None):
    req=urllib.request.Request(GW+path,data=json.dumps(body).encode() if body is not None else (b"" if m=="POST" else None),method=m,headers=H)
    try:
        with urllib.request.urlopen(req,timeout=240) as r: return r.status,r.read().decode()
    except urllib.error.HTTPError as e: return e.code,e.read().decode()
E="/platform/endo/core/endo/v1"
s,t=call("GET",f"/platform/proposal/v1/load?policyNo={po}"); p=json.loads(t)
s,t=call("GET",E+"/queryPendingEndo?policyId="+urllib.parse.quote(p['PolicyId']))
if s==200 and t.strip().startswith('{'): call("POST",E+"/suspendEndorsement?endoId="+str(json.loads(t)['EndoId']))
env={"EndoEffectiveDate":"2027-01-10","EndoType":"3","CancelType":"32","CancelReasonCode":"1","OtherCancelReason":"t","PolicyNo":po,"ProductId":p['ProductId'],"ProductCode":p['ProductCode'],"EndorsementPaymentInfoList":[{"PayModeCode":"30","IsInstallment":"Y","InstallmentType":"1"}]}
s,t=call("POST",E+"/createEx",env); c=json.loads(t)
c.update({"CancellationDate":"2027-01-10","CancellationType":"PRO_RATA","CancellationRefundPremium":"16.26","CancellationRef":"x"})
s,t=call("POST",E+"/calculateEx",c); print("calc",s,t[:800])
if s==200:
    c=json.loads(t); print({k:c.get(k) for k in ("CancellationDate","CancellationRefundPremium")})
call("POST",E+"/suspendEndorsement?endoId="+str(c['EndoId']))
