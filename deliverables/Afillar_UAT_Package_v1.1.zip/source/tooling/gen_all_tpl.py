import os,json,subprocess,sys,time
src=open(os.environ["B"]+"/ref_flow.py").read().split("def build(")[0]; ns={}; exec(src,ns); call=ns["call"]; B=os.environ["B"]
T=str(int(time.time()))
for tag,plan in [("UPPA001_1","2"),("TL001_1","2"),("FP001_1","2"),("HC001_1","3"),("CI001_1","2"),("LP001_1","2"),("DH001_1","1")]:
    code=tag.split("_")[0]; d=f"{B}/samples/ref/{tag}_P{plan}"
    pol=json.load(open(d+"/05_issue.json"))["response"]["body"]["PolicyNo"]; pno=json.load(open(d+"/02_proposal.json"))["response"]["body"]["ProposalNo"]
    for typ,body,tn in (("policy",{"DocType":"Policy","PolicyNo":pol,"PreviewData":"Y"},"POLICY"),("application",{"DocType":"Application","ProposalNo":pno,"PreviewData":"Y"},"APPLICATION")):
        st,r=call("POST","/doc_generation",body); json.dump(r["PrintData"],open(f"{B}/tpl2/{code}_{typ}.json","w"),indent=1,ensure_ascii=False)
        out=f"{B}/tpl2/{code}_{typ}.pdf"
        subprocess.run(["python3",B+"/os_gen.py",f"UP_{code}_{tn}_T{T}",f"{B}/tpl2/UP_{code}_{tn}_EN.html",f"{B}/tpl2/{code}_{typ}.json",out],capture_output=True)
        pg=subprocess.run(["pdfinfo",out],capture_output=True,text=True).stdout
        print(code,typ,[l for l in pg.splitlines() if "Pages" in l])
