#!/usr/bin/env python3
"""Read-only snapshot of PA001 related Uponly objects. usage: snapshot.py before|after"""
import json, subprocess, sys, hashlib, os
tag = sys.argv[1]; out = os.path.dirname(os.path.abspath(__file__)) + f"/snap/{tag}"; os.makedirs(out, exist_ok=True)
def run(args):
    r = subprocess.run(["imo"] + args + ["--profile", "portal:uponly"], capture_output=True, text=True, cwd="/home/user/Tablet"); return r.stdout
lst = json.load(open(os.path.dirname(os.path.abspath(__file__)) + "/../uponly-export/datatables/_list.json"))
lst = lst if isinstance(lst, list) else lst.get("ElementsInCurrentPage", [])
want = ["ProductLobMapping", "CarrierMaster", "ChannelMaster", "ProductMaster", "ProductPlanRelation", "PlanBenefitRelation", "DocTemplate", "AdapterServiceCfg", "Plan", "PlanMaster", "PremiumMode", "Relationship", "BranchCode", "Document", "GenderCode", "IdType", "InsMaritalStatus", "ResidentStatus", "CustomerType", "Salutation"]
summary = {}
for t in lst:
    if t["Name"] in want or t["Name"].startswith("PA001"):
        tid = t.get("Id") or t.get("DataTableId")
        txt = run(["config", "datatable", "record-list", "--id", str(tid), "--json"])
        open(f"{out}/dt_{t['Name']}_{tid}.json", "w").write(txt)
        summary[f"{t['Name']}:{tid}"] = hashlib.sha256(txt.encode()).hexdigest()[:16]
txt = run(["config", "product", "list", "--code", "PA001", "--json"]); open(f"{out}/product_PA001.json", "w").write(txt); summary["product:PA001"] = hashlib.sha256(txt.encode()).hexdigest()[:16]
json.dump(summary, open(f"{out}/_hashes.json", "w"), indent=1, sort_keys=True); print(len(summary), "objects hashed")
