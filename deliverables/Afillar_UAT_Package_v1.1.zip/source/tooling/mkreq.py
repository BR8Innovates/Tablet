import os,json,sys,time
src=open(os.environ["B"]+"/ref_flow.py").read().split("def build(")[0]; ns={}; exec(src,ns)
tag,plan=sys.argv[1],sys.argv[2]
d=json.load(open(f"{os.environ['B']}/samples/ref/{tag}_P{plan}/02_proposal.json")) if os.path.exists(f"{os.environ['B']}/samples/ref/{tag}_P{plan}/02_proposal.json") else None
b=d["request"]["body"]
body=ns["concrete"](b,{"applicationNo":str(int(time.time()*1000))})
json.dump(body,open(f"{os.environ['B']}/payloads/req_{tag}.json","w")); print("ok")
