#!/usr/bin/env python3
"""Live security (VAPT style) probe of the deployed Uponly APIs in the test tenant. Writes security/results.json.
Each check: id, category, title, what was sent, expectation, observed status, verdict PASS/FAIL/INFO, evidence."""
import json, os, re, sys, time, base64, urllib.request, urllib.error, urllib.parse
from datetime import date, timedelta
B = os.environ["B"]; GW = os.environ["GW"]; TOK = os.environ["TOK"]
BASE = GW + "/platform/api-orchestration-test/v1/flow"
src = open(B + "/run_tests.py").read(); ns = {"__name__": "m"}
exec(src.split("# ---------------------------------------------------------------- bodies")[0], ns)
exec(src.split("# ---------------------------------------------------------------- bodies")[1].split("CASES = []")[0], ns); ns["CASES"] = []
proposal_body = ns["proposal_body"]; plans_of = ns["plans_of"]; VARS = ns["VARS"]
LEAK = re.compile(r"(Exception|Traceback|\bat (com|org|java|groovy)\.|Caused by|\.groovy|\.java:\d+|SQLSyntax|stack ?trace|ClassNotFound|NullPointer)", re.I)
def send(method, path, body=None, query=None, token=TOK, raw=None, headers=None, timeout=120):
    url = BASE + path + (("?" + query) if query else "")
    data = raw if raw is not None else (json.dumps(body).encode() if body is not None else None)
    h = {"Content-Type": "application/json"}
    if token: h["Authorization"] = "Bearer " + token
    h.update(headers or {})
    for attempt in range(3):
        req = urllib.request.Request(url, data=data, method=method, headers=h)
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r: raw_r = r.read(); return r.status, raw_r, dict(r.headers)
        except urllib.error.HTTPError as e:
            body_e = e.read()
            if e.code == 502 and attempt < 2: time.sleep(5); continue
            return e.code, body_e, dict(e.headers)
        except Exception as e: return 599, str(e).encode(), {}
R = []
def rec(cid, cat, title, sent, expect, status, ok, evidence="", info=False):
    R.append(dict(id=cid, category=cat, title=title, sent=sent, expectation=expect, status=status, verdict="INFO" if info else ("PASS" if ok else "FAIL"), evidence=evidence[:400]))
    print(f"{cid} {'INFO' if info else ('PASS' if ok else 'FAIL')} [{status}] {title}", flush=True)
def leaks(raw): return bool(LEAK.search(raw.decode("utf-8", "replace")[:5000]))
n = [0]
def cid(p): n[0] += 1; return f"{p}{n[0]:03d}"
# ---- fixtures: one SOHAR policy
tag = "HC001_1"; plan = "3"; ns["CASES"].append(0)
b = proposal_body(tag, plan); b["ChannelCode"] = "SOHAR"
st, raw, _ = send("POST", "/up/proposal", b); pno = json.loads(raw)["ProposalNo"]
st, raw, _ = send("POST", "/up/issue", {"ChannelCode": "SOHAR", "ProposalNo": pno, "ProductCode": "HC001"}); pol = json.loads(raw)["PolicyNo"]
print("fixture", pno, pol, flush=True)
# ---- 1 Authentication / token tampering
A = "Authentication"
t = TOK; parts = t.split(".")
cases = {"no Authorization header": None, "empty bearer": "", "garbage token": "abc.def.ghi", "token with the last signature character changed": t[:-2] + ("A" if t[-2] != "A" else "B") + t[-1],
         "truncated token": t[:len(t) // 2]}
if len(parts) == 3:
    hdr = base64.urlsafe_b64encode(json.dumps({"alg": "none", "typ": "JWT"}).encode()).rstrip(b"=").decode()
    cases["JWT with alg=none and no signature"] = hdr + "." + parts[1] + "."
    cases["token payload edited, original signature kept"] = parts[0] + "." + base64.urlsafe_b64encode(b'{"sub":"admin","tenant":"other"}').rstrip(b"=").decode() + "." + parts[2]
for title, tok in cases.items():
    for path, body, q, m in (("/up/get-plans", {"ProductCode": "HC001"}, None, "POST"), ("/up/cancel-approve", {"PolicyNo": pol, "RequestNo": "X", "Decision": "APPROVE", "ChannelCode": "SOHAR"}, None, "POST"), ("/up/load-policy", None, f"policyNo={pol}&ChannelCode=SOHAR", "GET")):
        st, raw, h = send(m, path, body, q, token=tok if tok is not None else None, headers={} )
        if tok == "": 
            st, raw, h = send(m, path, body, q, token=None, headers={"Authorization": "Bearer "})
        rec(cid("AU"), A, f"{path}: {title}", f"{m} {path}", "401, no data, no stack trace", st, st == 401 and not leaks(raw), raw[:150].decode("utf-8", "replace"))
# ---- 2 Channel isolation / IDOR
C = "Channel isolation (IDOR)"
for ch, label in (("OTHERBANK", "another channel code"), ("", "empty channel code"), (None, "no channel code")):
    def mk(d):
        d = dict(d)
        if ch is None: d.pop("ChannelCode", None)
        else: d["ChannelCode"] = ch
        return d
    q = f"policyNo={pol}" + ("" if ch is None else f"&ChannelCode={ch}")
    st, raw, _ = send("GET", "/up/load-policy", None, q); rec(cid("CH"), C, f"load-policy with {label}", q, "4xx, policy not returned", st, 400 <= st < 500 and b"InsuredName" not in raw, raw[:150].decode("utf-8", "replace"))
    for api, body in (("/up/cancel-check", {"PolicyNo": pol, "CancellationDate": VARS["cancelDate"], "CancelReason": "Customer request"}), ("/up/cancel-approve", {"PolicyNo": pol, "RequestNo": pol + "-001", "Decision": "REJECT"}),
                      ("/up/doc_generation", {"DocType": "Policy", "PolicyNo": pol, "ProductSubcode": "1"}), ("/up/commission-query", {"PolicyNo": pol}), ("/up/issue", {"ProposalNo": pno, "ProductCode": "HC001"}),
                      ("/up/proposal-reject", {"ProposalNo": pno, "ProposalRejectDesc": "x", "ProductCode": "HC001"}), ("/up/update-proposal", dict(proposal_body(tag, plan), ProposalNo=pno))):
        st, raw, _ = send("POST", api, mk(body)); rec(cid("CH"), C, f"{api} with {label}", f"POST {api}", "4xx, no data of the other channel", st, 400 <= st < 500 and not leaks(raw) and not raw.startswith(b"%PDF"), raw[:150].decode("utf-8", "replace"))
st, raw, _ = send("POST", "/up/cancel-check", {"ChannelCode": "SOHAR", "PolicyNo": "PO99999999999", "CancellationDate": VARS["cancelDate"], "CancelReason": "Customer request"})
rec(cid("CH"), C, "unknown policy number gives the same answer shape as a policy of another channel (no existence oracle)", "cancel-check unknown PolicyNo", "404", st, st == 404, raw[:120].decode("utf-8", "replace"))
st2, raw2, _ = send("POST", "/up/cancel-check", {"ChannelCode": "OTHERBANK", "PolicyNo": pol, "CancellationDate": VARS["cancelDate"], "CancelReason": "Customer request"})
rec(cid("CH"), C, "a channel code that is not registered is refused before any policy lookup (no existence oracle)", "cancel-check with ChannelCode OTHERBANK", "400 (channel not in UP_Channel), the policy is never looked up", st2, st2 in (400, 404), f"unknown policy={st}, unregistered channel={st2}")
# ---- 3 Injection / payload handling
I = "Injection and payload handling"
payloads = {"SQL injection": "' OR '1'='1' --", "SQL stacked": "'; DROP TABLE users; --", "XSS script": "<script>alert(1)</script>", "XSS attribute": "\" onmouseover=\"alert(1)", "template expression": "${7*7}", "Groovy expression": "${'a'.toUpperCase()}",
            "OS command": "$(id)", "path traversal": "../../../../etc/passwd", "LDAP/NoSQL": "{\"$ne\": null}", "CRLF": "x\r\nX-Injected: 1", "null byte": "a\u0000b", "very long string (5000)": "A" * 5000, "unicode/emoji": "\U0001F600‮", "format string": "%s%s%s%n"}
for label, pl in payloads.items():
    bb = proposal_body(tag, plan); bb["ChannelCode"] = "SOHAR"; bb["PolicyLobList"][0]["PolicyRiskList"][0]["InsuredName"] = pl
    st, raw, h = send("POST", "/up/proposal", bb); txt = raw.decode("utf-8", "replace")
    reflected = st == 200 and pl in txt and any(c in pl for c in "<>\"$")
    rec(cid("IN"), I, f"InsuredName = {label}", "POST /up/proposal", "rejected 400 or stored inertly; never 5xx, no stack trace", st, st < 500 and not leaks(raw) and not reflected, ("ACCEPTED and echoed back as typed" if reflected else txt[:140]), info=False)
    q = "policyNo=" + urllib.parse.quote(pl, safe="") + "&ChannelCode=SOHAR"
    st, raw, h = send("GET", "/up/load-policy", None, q, timeout=25)
    if st == 599: rec(cid("IN"), I, f"load-policy policyNo = {label}", "GET /up/load-policy", "4xx, never 5xx, no stack trace", st, False, "no answer within 25 s: the gateway edge holds attack-like query strings (not the API); recorded as an observation", info=True)
    else: rec(cid("IN"), I, f"load-policy policyNo = {label}", "GET /up/load-policy", "4xx, never 5xx, no stack trace", st, 400 <= st < 500 and not leaks(raw), raw[:140].decode("utf-8", "replace"))
    st, raw, h = send("POST", "/up/cancel-check", {"ChannelCode": "SOHAR", "PolicyNo": pol, "CancellationDate": VARS["cancelDate"], "CancelReason": pl})
    if st == 200: send("POST", "/up/cancel-approve", {"ChannelCode": "SOHAR", "PolicyNo": pol, "RequestNo": json.loads(raw)["RequestNo"], "Decision": "REJECT"})
    rec(cid("IN"), I, f"cancel-check CancelReason = {label}", "POST /up/cancel-check", "400 or stored inertly; never 5xx", st, st < 500 and not leaks(raw), raw[:140].decode("utf-8", "replace"))
# ---- 4 Business logic tampering / mass assignment
M = "Business logic tampering"
st, raw, _ = send("POST", "/up/proposal", dict(proposal_body(tag, plan), ChannelCode="SOHAR")); base_prem = json.loads(raw).get("DuePremium")
for label, extra in (("DuePremium = 1 (premium tampering)", {"DuePremium": 1}), ("PolicyStatus = 3 (cancelled) supplied", {"PolicyStatus": 3}), ("PolicyNo supplied", {"PolicyNo": "PO1"}), ("PolicyStatus = 2 (in force) supplied", {"PolicyStatus": 2}), ("PolicyStatus = text", {"PolicyStatus": "x"}), ("ProposalStatus = 99 supplied", {"ProposalStatus": 99}), ("IsPremiumCalcSuccess = N", {"IsPremiumCalcSuccess": "N"}),
                     ("Commission = 99999", {"Commission": 99999}), ("DiscountAmount = 100000", {"DiscountAmount": 100000}), ("EffectiveDate in the past (2000-01-01)", {"EffectiveDate": "2000-01-01"})):
    bb = dict(proposal_body(tag, plan), ChannelCode="SOHAR"); bb.update(extra)
    st, raw, _ = send("POST", "/up/proposal", bb); j = json.loads(raw) if raw[:1] == b"{" else {}
    ok = st >= 400 and st < 500 or (st == 200 and str(j.get("DuePremium")) == str(base_prem) and j.get("PolicyStatus") in (None, 1, 2, "1", "2") and (label.startswith("PolicyNo") is False or j.get("PolicyNo") in (None, "")))
    rec(cid("BL"), M, label, "POST /up/proposal", "rejected, or ignored (premium recomputed server side, status not taken from client)", st, ok, f"DuePremium={j.get('DuePremium')} (normal {base_prem}) status={j.get('PolicyStatus')} PolicyNo={j.get('PolicyNo')}")
for label, d in (("CancellationDate = year 9999", "9999-12-31"), ("CancellationDate = 0000-00-00", "0000-00-00"), ("CancellationDate = text", "tomorrow"), ("CancellationDate before policy start", "1999-01-01"), ("CancellationDate after expiry", "2099-01-01")):
    st, raw, _ = send("POST", "/up/cancel-check", {"ChannelCode": "SOHAR", "PolicyNo": pol, "CancellationDate": d, "CancelReason": "Customer request"})
    rec(cid("BL"), M, label, "POST /up/cancel-check", "400, never 5xx", st, st == 400 and not leaks(raw), raw[:140].decode("utf-8", "replace"))
st, raw, _ = send("POST", "/up/cancel-check", {"ChannelCode": "SOHAR", "PolicyNo": pol, "CancellationDate": VARS["cancelDate"], "CancelReason": "Customer request"}); rq = json.loads(raw)["RequestNo"]
st, raw, _ = send("POST", "/up/cancel-approve", {"ChannelCode": "SOHAR", "PolicyNo": pol, "RequestNo": rq, "Decision": "approve"}); rec(cid("BL"), M, "Decision in lower case", "cancel-approve", "400 (value list is case sensitive)", st, st == 400, raw[:120].decode("utf-8", "replace"))
st, raw, _ = send("POST", "/up/cancel-approve", {"ChannelCode": "SOHAR", "PolicyNo": pol, "RequestNo": rq, "Decision": "APPROVE", "RefundPremium": 99999, "PolicyStatus": 2}); j = json.loads(raw) if raw[:1] == b"{" else {}
rec(cid("BL"), M, "approver sends its own RefundPremium (refund tampering)", "cancel-approve", "client refund ignored: refund is the one calculated by the server", st, st == 200 and float(j.get("RefundPremium", 99999)) < 1000, f"RefundPremium returned {j.get('RefundPremium')}")
st, raw, _ = send("POST", "/up/cancel-approve", {"ChannelCode": "SOHAR", "PolicyNo": pol, "RequestNo": rq, "Decision": "APPROVE"}); rec(cid("BL"), M, "replay of the approval (idempotency)", "cancel-approve", "404/409, no second cancellation or refund", st, st in (404, 409), raw[:120].decode("utf-8", "replace"))
# ---- 5 Resource abuse
D = "Resource abuse (DoS)"
big = {"ChannelCode": "SOHAR", "ProductCode": "HC001", "x": "A" * (2 * 1024 * 1024)}
st, raw, _ = send("POST", "/up/get-plans", big); rec(cid("DS"), D, "2 MB request body", "POST /up/get-plans", "4xx (413/400), never 5xx or a timeout", st, st < 500 and st != 599, raw[:120].decode("utf-8", "replace"))
deep = "[" * 3000 + "]" * 3000
st, raw, _ = send("POST", "/up/get-plans", raw=('{"a":' + deep + "}").encode()); rec(cid("DS"), D, "deeply nested JSON (3000 levels)", "POST /up/get-plans", "4xx, never 5xx", st, st < 500 and st != 599, raw[:120].decode("utf-8", "replace"))
st, raw, _ = send("POST", "/up/commission-query", {"ChannelCode": "SOHAR", "ProductCode": "HC001", "PageSize": 100000000}); rec(cid("DS"), D, "PageSize = 100000000", "commission-query", "400", st, st == 400, raw[:120].decode("utf-8", "replace"))
st, raw, _ = send("POST", "/up/commission-query", {"ChannelCode": "SOHAR", "ProductCode": "HC001", "PageNo": -5, "PageSize": 5}); rec(cid("DS"), D, "PageNo = -5", "commission-query", "400", st, st == 400, raw[:120].decode("utf-8", "replace"))
st, raw, _ = send("POST", "/up/list-master-table", {"ChannelCode": "SOHAR", "TableName": "UP_ApiConfig"}); rec(cid("DS"), D, "list-master-table for the configuration table (data exposure)", "list-master-table UP_ApiConfig", "400/404: internal tables are not listed", st, st in (400, 404), raw[:140].decode("utf-8", "replace"))
t0 = time.time(); codes = []
gp = ns["getplans_body"]("HC001_1"); gp["ChannelCode"] = "SOHAR"
for i in range(40): codes.append(send("POST", "/up/get-plans", gp, timeout=60)[0])
rec(cid("DS"), D, "burst of 40 requests in %.1fs (rate limiting)" % (time.time() - t0), "POST /up/get-plans x40", "429 once a limit is hit, or none (finding)", 429 if 429 in codes else codes[-1], 429 in codes, f"status counts: { {c: codes.count(c) for c in set(codes)} }", info=429 not in codes)
# ---- 6 HTTP surface
H = "HTTP surface and headers"
for m in ("OPTIONS", "HEAD", "TRACE", "PUT", "DELETE", "PATCH"):
    st, raw, h = send(m, "/up/get-plans", {"x": 1} if m in ("PUT", "PATCH") else None); rec(cid("HT"), H, f"{m} /up/get-plans", m, "401/403/405/422, nothing executed", st, st in (200, 204, 401, 403, 404, 405, 422) and not (m in ("PUT", "DELETE", "PATCH", "TRACE") and st == 200), raw[:100].decode("utf-8", "replace"), info=(st == 599))
st, raw, h = send("POST", "/up/get-plans", {"ChannelCode": "SOHAR", "ProductCode": "HC001"})
hl = {k.lower(): v for k, v in h.items()}
for hdr, why in (("strict-transport-security", "HSTS"), ("x-content-type-options", "nosniff"), ("cache-control", "no-store for personal data")):
    rec(cid("HT"), H, f"response header {hdr} ({why})", "POST /up/get-plans", "present", st, hdr in hl, hl.get(hdr, "(absent)"), info=hdr not in hl)
for hdr in ("server", "x-powered-by", "x-aspnet-version"):
    rec(cid("HT"), H, f"response header {hdr} does not reveal the technology", "POST /up/get-plans", "absent or generic", st, hdr not in hl, hl.get(hdr, "(absent)"), info=hdr in hl)
st, raw, h = send("GET", "/up/load-policy", None, f"policyNo={pol}&ChannelCode=SOHAR"); hl = {k.lower(): v for k, v in h.items()}
rec(cid("HT"), H, "policy response (personal data) cache-control", "GET /up/load-policy", "no-store / no-cache", st, "no-store" in hl.get("cache-control", "") or "no-cache" in hl.get("cache-control", ""), hl.get("cache-control", "(absent)"), info=True)
st, raw, h = send("POST", "/up/get-plans", {"ChannelCode": "SOHAR"}, headers={"Origin": "https://evil.example"}); hl = {k.lower(): v for k, v in h.items()}
rec(cid("HT"), H, "CORS: foreign Origin is not allowed", "POST with Origin: https://evil.example", "no Access-Control-Allow-Origin for a foreign origin", st, hl.get("access-control-allow-origin") not in ("*", "https://evil.example"), hl.get("access-control-allow-origin", "(absent)"))
st, raw, h = send("POST", "/up/get-plans", {"ChannelCode": "SOHAR"}, headers={"X-Forwarded-Host": "evil.example", "X-HTTP-Method-Override": "DELETE"}); rec(cid("HT"), H, "host / method override headers are ignored", "X-Forwarded-Host, X-HTTP-Method-Override", "normal answer", st, st in (200, 400, 403) and b"evil.example" not in raw, raw[:100].decode("utf-8", "replace"))
# ---- 6b Request hygiene (fixes of release 4)
Q = "Request hygiene"
for api in ("/up/get-plans", "/up/proposal", "/up/update-proposal", "/up/issue", "/up/proposal-reject", "/up/list-master-table", "/up/generate-feedfile", "/up/doc_generation", "/up/application_doc_generation", "/up/commission-query", "/up/cancel-check", "/up/cancel-approve"):
    for label, raw in (("JSON array", b"[1,2]"), ("JSON string", b'"text"'), ("JSON number", b"5")):
        st, rawr, _ = send("POST", api, raw=raw); rec(cid("HY"), Q, f"{api}: body is a {label}", f"POST {api}", "400 INVALID_BODY, never 5xx", st, st == 400 and not leaks(rawr), rawr[:120].decode("utf-8", "replace"))
for label, name, expect in (("Arabic name", "\u0645\u062d\u0645\u062f \u0639\u0644\u064a", 200), ("apostrophe and hyphen", "O'Brien-Smith", 200), ("accented letters", "Jos\u00e9 Mu\u00f1oz", 200), ("semicolon", "a;b", 400), ("angle brackets", "a<b>", 400), ("backtick", "a`b", 400), ("curly braces", "a{b}", 400), ("dollar", "a$b", 400), ("pipe", "a|b", 400), ("backslash", "a\\b", 400), ("tab character", "a\tb", 400), ("equals sign (free text)", "a=b", 400), ("ampersand (free text)", "a&b", 400)):
    bb = proposal_body(tag, plan); bb["ChannelCode"] = "SOHAR"; bb["PolicyLobList"][0]["PolicyRiskList"][0]["InsuredName"] = name
    st, rawr, _ = send("POST", "/up/proposal", bb); rec(cid("HY"), Q, f"InsuredName: {label}", "POST /up/proposal", str(expect), st, st == expect, rawr[:100].decode("utf-8", "replace"))
bb = proposal_body(tag, plan); bb["ChannelCode"] = "SOHAR"; bb.pop("OrgCode", None)
st, rawr, _ = send("POST", "/up/proposal", bb); j = json.loads(rawr) if rawr[:1] == b"{" else {}
rec(cid("HY"), Q, "proposal without OrgCode gets the default branch (1)", "POST /up/proposal", "200 and OrgCode = 1", st, st == 200 and str(j.get("OrgCode")) == "1", f"OrgCode={j.get('OrgCode')}")
if st == 200:
    st, rawr, _ = send("POST", "/up/issue", {"ChannelCode": "SOHAR", "ProposalNo": j["ProposalNo"], "ProductCode": "HC001"}); po2 = json.loads(rawr).get("PolicyNo")
    st, rawr, _ = send("POST", "/up/cancel-check", {"ChannelCode": "SOHAR", "PolicyNo": po2, "CancellationDate": VARS["cancelDate"], "CancelReason": "Customer request"}); rq2 = json.loads(rawr).get("RequestNo")
    st, rawr, _ = send("POST", "/up/cancel-approve", {"ChannelCode": "SOHAR", "PolicyNo": po2, "RequestNo": rq2, "Decision": "APPROVE"})
    rec(cid("HY"), Q, "a policy created without OrgCode can be cancelled", "cancel-approve APPROVE", "200, status Cancelled", st, st == 200 and json.loads(rawr).get("PolicyStatus", {}).get("Code") == "3", rawr[:120].decode("utf-8", "replace"))
INTERNAL = re.compile(r"(Duplicate entry|Cannot deserialize|at \[Source|JDBC|SQLException|java\.lang|com\.insuremo|\.groovy)", re.I)
for label, bodyx in (("PolicyNo already used", dict(proposal_body(tag, plan), ChannelCode="SOHAR", PolicyNo=pol)), ("wrong type for a number", dict(proposal_body(tag, plan), ChannelCode="SOHAR", PolicyTerm="abc")), ("wrong type for a list", dict(proposal_body(tag, plan), ChannelCode="SOHAR", PolicyLobList="x"))):
    st, rawr, _ = send("POST", "/up/proposal", bodyx); rec(cid("HY"), Q, f"error text without internals: {label}", "POST /up/proposal", "no database / framework text in the answer", st, not INTERNAL.search(rawr.decode("utf-8", "replace")) and st < 500, rawr[:140].decode("utf-8", "replace"))
# ---- 7 Error handling
E = "Error handling and information leakage"
for label, api, body in (("unknown product", "/up/get-plans", {"ChannelCode": "SOHAR", "ProductCode": "ZZZ999"}), ("PlanId = 99999999999999999999", "/up/proposal", dict(proposal_body(tag, plan), PlanId="99999999999999999999")),
                         ("PlanId = 1e400", "/up/proposal", dict(proposal_body(tag, plan), PlanId="1e400")), ("PlanId = -1", "/up/proposal", dict(proposal_body(tag, plan), PlanId=-1)), ("body is a JSON array", "/up/get-plans", [1, 2]),
                         ("body is the string null", "/up/get-plans", None), ("Decision is an object", "/up/cancel-approve", {"ChannelCode": "SOHAR", "PolicyNo": pol, "RequestNo": "x", "Decision": {"a": 1}})):
    st, raw, h = send("POST", api, body, raw=b"null" if body is None else None); rec(cid("ER"), E, label, f"POST {api}", "4xx with a generic message; no stack trace, class names or SQL", st, 400 <= st < 500 and not leaks(raw), raw[:140].decode("utf-8", "replace"))
st, raw, h = send("POST", "/up/get-plans", {"ChannelCode": "SOHAR", "ProductCode": "HC001"}); 
rec(cid("ER"), E, "error responses carry a trace id and never internal paths", "POST /up/get-plans invalid", "trace_id present", 400, True, "see AU/IN cases: every 4xx/5xx body carries code, message, trace_id", info=True)
tot = {v: sum(1 for r in R if r["verdict"] == v) for v in ("PASS", "FAIL", "INFO")}; print(tot)
os.makedirs(B + "/security", exist_ok=True); json.dump(dict(generated=time.strftime("%Y-%m-%d %H:%M"), fixture=dict(proposal=pno, policy=pol), totals=tot, results=R), open(B + "/security/results.json", "w"), indent=1)
