#!/usr/bin/env python3
"""One flow per product (first variant, first plan): CarrierCode / CarrierName must be returned by every API. Writes carrier/results.json."""
import json, os, sys
from datetime import date, timedelta
src = open("run_tests.py").read(); ns = {"__name__": "m"}
exec(src.split("# ---------------------------------------------------------------- bodies")[0], ns)
exec(src.split("# ---------------------------------------------------------------- bodies")[1].split("CASES = []")[0], ns); ns["CASES"] = [0]
http = ns["http"]; pb = ns["proposal_body"]; plans_of = ns["plans_of"]; gp = ns["getplans_body"]; VARS = ns["VARS"]
EXP_CODE, EXP_NAME = "AFIC", "Afillar Insurance Company"
R = []
def chk(product, step, status, body, where=None):
    t = body
    for w in (where or "").split("."):
        if w: t = t.get(w) if isinstance(t, dict) else None
    if isinstance(t, list): t = t[0] if t else {}
    ok = status == 200 and isinstance(t, dict) and t.get("CarrierCode") == EXP_CODE and t.get("CarrierName") == EXP_NAME
    R.append(dict(product=product, step=step, status=status, ok=ok, CarrierCode=(t or {}).get("CarrierCode") if isinstance(t, dict) else None, CarrierName=(t or {}).get("CarrierName") if isinstance(t, dict) else None))
    print(("PASS" if ok else "FAIL"), product, step, status, (t or {}).get("CarrierCode") if isinstance(t, dict) else "-", (t or {}).get("CarrierName") if isinstance(t, dict) else "-", flush=True)
    return ok
for code in ["UPPA001", "TL001", "FP001", "HC001", "CI001", "LP001", "DH001"]:
    tag = code + "_1"; plan = sorted(plans_of(tag))[0]
    g = gp(tag); g["ChannelCode"] = "SOHAR"; s, r = http("POST", "/up/get-plans", g); chk(code, "get-plans", s, r)
    b = pb(tag, plan); b["ChannelCode"] = "SOHAR"; s, r = http("POST", "/up/proposal", b); chk(code, "proposal", s, r)
    if s != 200: continue
    pno = r["ProposalNo"]
    s, r = http("POST", "/up/issue", {"ChannelCode": "SOHAR", "ProposalNo": pno, "ProductCode": code}); chk(code, "issue", s, r); po = r.get("PolicyNo")
    s, r = http("GET", "/up/load-policy", query=f"policyNo={po}&ChannelCode=SOHAR"); chk(code, "load-policy", s, r)
    cd = (date.fromisoformat(VARS["effectiveDate"]) + timedelta(days=30)).isoformat()
    s, r = http("POST", "/up/cancel-check", {"ChannelCode": "SOHAR", "PolicyNo": po, "CancellationDate": cd, "CancelReason": "Customer request"}); chk(code, "cancel-check", s, r); chk(code, "cancel-check PolicyInfo", s, r, "PolicyInfo"); rq = r.get("RequestNo")
    s, r = http("POST", "/up/cancel-approve", {"ChannelCode": "SOHAR", "PolicyNo": po, "RequestNo": rq, "Decision": "APPROVE"}); chk(code, "cancel-approve", s, r)
    s, r = http("POST", "/up/commission-query", {"ChannelCode": "SOHAR", "PolicyNo": po}); chk(code, "commission by policy", s, r)
    s, r = http("POST", "/up/commission-query", {"ChannelCode": "SOHAR", "ProductCode": code}); chk(code, "commission by plan configuration", s, r, "Records")
# extras
b = pb("HC001_1", "1"); b["ChannelCode"] = "SOHAR"; b["CarrierCode"] = "XXXX"; s, r = http("POST", "/up/proposal", b)
ok = s == 400 and any(e.get("code") == "MISMATCH" and e.get("field") == "CarrierCode" for e in r.get("errors", [])); R.append(dict(product="HC001", step="proposal with a wrong CarrierCode -> 400 MISMATCH", status=s, ok=ok)); print("PASS" if ok else "FAIL", "wrong CarrierCode", s)
b = pb("HC001_1", "1"); b["ChannelCode"] = "SOHAR"; b["CarrierCode"] = "AFIC"; s, r = http("POST", "/up/proposal", b); ok = s == 200 and r.get("CarrierCode") == EXP_CODE; R.append(dict(product="HC001", step="proposal with CarrierCode AFIC accepted", status=s, ok=ok)); print("PASS" if ok else "FAIL", "AFIC accepted", s)
s, r = http("POST", "/up/list-master-table", {"ChannelCode": "SOHAR", "DataTableName": "UP_Carrier"}); ok = s == 200 and isinstance(r, list) and r and r[0].get("CarrierCode") == EXP_CODE and r[0].get("CarrierName") == EXP_NAME; R.append(dict(product="-", step="master data UP_Carrier", status=s, ok=ok)); print("PASS" if ok else "FAIL", "master UP_Carrier", s, str(r)[:120])
eff = VARS["effectiveDate"]
s, r = http("POST", "/up/generate-feedfile", {"ChannelCode": "SOHAR", "Conditions": {"ProductCode": "HC001"}, "FromRangeConditions": {"EffectiveDate": eff + "T00:00:00"}, "ToRangeConditions": {"EffectiveDate": eff + "T23:59:59"}, "SearchType": "Policy", "PageNo": 1, "PageSize": 5, "OutputFormat": "JSON"})
rec = (r.get("Records") or [{}])[0] if isinstance(r, dict) else {}
ok = s == 200 and rec.get("Carrier Code") == EXP_CODE and rec.get("Carrier Name") == EXP_NAME; R.append(dict(product="HC001", step="feed file (JSON) has Carrier Code / Carrier Name", status=s, ok=ok)); print("PASS" if ok else "FAIL", "feed", s, {k: rec.get(k) for k in ("Carrier Code", "Carrier Name")})
os.makedirs("carrier", exist_ok=True); json.dump(R, open("carrier/results.json", "w"), indent=1)
print("TOTAL", len(R), "PASS", sum(x["ok"] for x in R), "FAIL", sum(not x["ok"] for x in R))
