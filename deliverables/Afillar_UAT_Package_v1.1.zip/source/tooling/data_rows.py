import json,os,subprocess
B=os.environ['B']
def tid(n):
    d=json.loads(subprocess.run(["imo","config","datatable","by-name","--profile","portal:uponly","--name",n,"--json"],capture_output=True,text=True).stdout)
    d=d if isinstance(d,list) else [d]; return d[0]['DataTableId']
# product variants: code -> list of (subcode, description, lob)
V=[("UPPA001","1","Personal Accident with TTD"),("UPPA001","2","Personal Accident without TTD"),
   ("TL001","1","Term Life with Travel"),("TL001","2","Term Life without Travel"),
   ("FP001","1","Female Protection"),("HC001","1","Hospital Cash Benefit"),
   ("CI001","1","Critical Illness - 7 CI"),("CI001","2","Critical Illness - 11 CI"),("CI001","3","Critical Illness - 32 CI"),
   ("LP001","1","Life Protect"),("DH001","1","Domestic Helper Insurance")]
LOB={"UPPA001":"Personal Accident","TL001":"Term Life","FP001":"Female Protection","HC001":"Hospital Cash Benefit","CI001":"Critical Illness","LP001":"Life Protect","DH001":"Domestic Helper"}
# (premiums, commissions) per variant; LP has annual & monthly
P={("UPPA001","1"):([68,96,124,152,180],[44.1,63.7,83.3,102.9,122.5]),
   ("UPPA001","2"):([55,81,109,137,165],[35,53.2,72.8,92.4,112]),
   ("TL001","1"):([216,328,440,552,664],[151.2,229.6,308,386.4,464.8]),
   ("TL001","2"):([132,244,360,472,580],[92.4,170.8,252,330.4,406]),
   ("FP001","1"):([11,28,56,84,112],[7.7,19.6,39.2,58.8,78.4]),
   ("HC001","1"):([70,140,280,420,560],[49,98,196,294,392]),
   ("CI001","1"):([73,146,292,730,1460],None),("CI001","2"):([100,200,400,1000,2000],None),("CI001","3"):([150,300,600,1500,3000],None),
   ("DH001","1"):([49,31],[34.3,21.7])}
LPA=([60,120,180,300,600],[15,30,45,75,150]); LPM=([5,10,15,25,50],[1.25,2.5,3.75,6.25,12.5])
# benefits: (code, desc, [limits per plan], basis, maxdays)
def per(code,desc,lim,basis="",md=""): return (code,desc,lim,basis,md)
B5=lambda a:[a*i for i in (1,2,3,4,5)]
BEN={("UPPA001","1"):[per("ACD","Death due to accident",[12000,22000,32000,42000,52000]),per("PTD","PTD due to accident",[12000,22000,32000,42000,52000]),per("PPD","PPD due to accident",[12000,22000,32000,42000,52000]),per("TTD","TTD due to accident",[3000]*5),per("HCB","HCB due to accident",[20]*5,"PerDay"),per("REX","Repatriation Expenses",[1500]*5)],
    ("UPPA001","2"):[per("ACD","Death due to accident",[10000,20000,30000,40000,50000]),per("PTD","PTD due to accident",[10000,20000,30000,40000,50000]),per("PPD","PPD due to accident",[10000,20000,30000,40000,50000]),per("HCB","HCB due to accident",[20]*5,"PerDay"),per("REX","Repatriation Expenses",[1500]*5)],
    ("TL001","1"):[per("DTH","Death",[10000,20000,30000,40000,50000]),per("PTD","Permanent Total Disability",[10000,20000,30000,40000,50000]),per("PPD","Permanent Partial Disability",[10000,20000,30000,40000,50000]),per("TRV","Annual Family Travel",[0]*5,"Included"),per("REX","Repatriation Expenses",[1000]*5)],
    ("TL001","2"):[per("DTH","Death",[7500,17500,27500,37500,47500]),per("PTD","Permanent Total Disability",[7500,17500,27500,37500,47500]),per("PPD","Permanent Partial Disability",[7500,17500,27500,37500,47500]),per("REX","Repatriation Expenses",[1000]*5)],
    ("FP001","1"):[per("FCC","Female Cancer Cover",[1000,2000,3000,4000,5000])],
    ("HC001","1"):[per("HCB","Hospital Cash Benefit",[50,100,200,300,400],"PerDay",90)],
    ("CI001","1"):[per("CIB","Critical Illness Benefit",[2500,5000,10000,25000,50000])],
    ("CI001","2"):[per("CIB","Critical Illness Benefit",[2500,5000,10000,25000,50000])],
    ("CI001","3"):[per("CIB","Critical Illness Benefit",[2500,5000,10000,25000,50000])],
    ("LP001","1"):[per("DTH","Death due to any cause",[7500,10000,15000,25000,50000]),per("PTD","PTD due to any cause",[7500,10000,15000,25000,50000]),per("PPD","PPD due to any cause",[7500,10000,15000,25000,50000])],
    ("DH001","1"):[per("DTH","Death due to any cause",[3000,1500]),per("AME","Accidental Medical Expenses",[1500,1000],"ActualsPerPolicyYear"),per("RHE","Replacement Domestic Helper Expenses",[500,350],"Actuals"),per("REP","Repatriation due to Death",[500,500],"Fixed")]}
RULE={"UPPA001":("1,2",2,10),"TL001":("1,2",2,10),"CI001":("1,2",2,10),"FP001":("2",1,1),"HC001":("2",1,1),"DH001":("2",1,1),"LP001":("2,3",1,1)}
t={n:tid(n) for n in ["ProductMaster","ProductPlanRelation","UP_PlanBenefitRelation","ProductRule","DocTemplate"]}
def rec(n,d): d.update({"DataTableId":t[n],"RecordUsage":5}); return d
pm=[rec("ProductMaster",{"Id":s,"IMOProductCode":c,"Description":d,"LOB":LOB[c],"HasPlans":"Y","IsActive":"Y","IsRenewable":"Y","IsResident":"Y","CarrierCode":"AFIC","CarrierProductCode":s,"CarrierProductName":d}) for c,s,d in V]
ppr=[];i=0
def addplans(c,s,d,prem,comm,mode=""):
    global i
    for n,p in enumerate(prem,1):
        i+=1; cm=comm[n-1] if comm else round(p*0.7,2)
        ppr.append(rec("ProductPlanRelation",{"Id":str(i),"CarrierCode":"AFIC","CarrierPlanCode":f"Plan {n}","CarrierPlanName":f"Plan {n}","CarrierProductCode":s,"CarrierProductName":d,"Commission":cm,"IMOPlanCode":str(n),"IMOPlanName":f"Plan {n}","IMOProductCode":c,"IsActive":"Y","Premium":p,"PremiumModeCode":mode}))
for c,s,d in V:
    if c=="LP001": addplans(c,s,d,*LPA,"2"); addplans(c,s,d,*LPM,"3")
    else: addplans(c,s,d,*P[(c,s)])
pbr=[];j=0
for c,s,d in V:
    for code,desc,lim,basis,md in BEN[(c,s)]:
        for n,l in enumerate(lim,1):
            j+=1
            pbr.append(rec("UP_PlanBenefitRelation",{"Id":str(j),"BenefitCode":code,"BenefitDesc":desc,"BenefitLevel":"COVER","BenefitLimit":str(l),"BenefitLimitDesc":basis or "Covered","CarrierCode":"AFIC","CarrierPlanCode":f"Plan {n}","CarrierProductCode":s,"IMOPlanCode":str(n),"IMOProductCode":c,"IsAdditionalBenefit":"N","IsApplicable":"Y","IsMainBenefit":"Y","ParentBenefitCode":"NA","LimitBasis":basis,"MaxDays":md if md!="" else None}))
pr=[];k=0
for c,s,d in V:
    k+=1; m,mn,mx=RULE[c]
    pr.append(rec("ProductRule",{"Id":str(k),"ProductCode":c,"ProductSubcode":s,"PremiumModes":m,"MinTerm":mn,"MaxTerm":mx,"MinAge":18,"MaxAge":69,"MaxEntryAge":64,"MaxExitAge":70,"MandatoryDocuments":"1,2,3","SinglePremiumRule":"Premium is the same for any term within the allowed range" if "1" in m.split(",") else ""}))
dt=[];q=0
for c,s,d in V:
    for typ,code in (("Application","APPLICATION"),("Policy","POLICY")):
        q+=1; dt.append(rec("DocTemplate",{"Id":str(q),"ProductCode":c,"ProductSubcode":s,"DocType":typ,"DocumentCode":code,"FileName":"COI" if typ=="Policy" else "APPLICATION","TemplateName":f"UP_{c}_{s}_{code}_EN"}))
os.makedirs(B+"/rows",exist_ok=True)
for n,rows in (("ProductMaster",pm),("ProductPlanRelation",ppr),("UP_PlanBenefitRelation",pbr),("ProductRule",pr),("DocTemplate",dt)):
    rows=[{k:v for k,v in r.items() if v is not None} for r in rows]
    json.dump(rows,open(f"{B}/rows/{n}.json","w"),indent=1); print(n,len(rows))
