import json,os,datetime
B=os.environ['B']; os.makedirs(B+'/samples/req',exist_ok=True)
# code, sub, name, plan, mode, term, person
V=[("UPPA001","1","Personal Accident with TTD","2","2",1,"M1"),
   ("UPPA001","2","Personal Accident without TTD","1","1",3,"M2"),
   ("TL001","1","Term Life with Travel","3","2",1,"M3"),
   ("TL001","2","Term Life without Travel","1","2",1,"F1"),
   ("FP001","1","Female Protection","2","2",1,"F2"),
   ("HC001","1","Hospital Cash Benefit","3","2",1,"M4"),
   ("CI001","1","Critical Illness 7 CI","2","2",1,"M5"),
   ("CI001","2","Critical Illness 11 CI","2","1",5,"F3"),
   ("CI001","3","Critical Illness 32 CI","4","2",1,"M6"),
   ("LP001","1","Life Protect","2","3",1,"F4"),
   ("DH001","1","Domestic Helper Insurance","1","2",1,"F5")]
P={"M1":("Mr.","1","Mohamed Al Harthy","1988-10-01","1","P1001001"),"M2":("Mr.","1","Khalid Al Rawahi","1985-03-22","2","P2002002"),
   "M3":("Mr.","1","Salim Al Busaidi","1979-07-15","1","P3003003"),"F1":("Mrs","2","Fatma Al Lawati","1991-01-30","1","P4004004"),
   "F2":("Miss","2","Aisha Al Balushi","1990-05-12","1","P5005005"),"M4":("Mr.","1","Hamad Al Kindi","1982-11-09","1","P6006006"),
   "M5":("Mr.","1","Yousuf Al Siyabi","1976-04-18","1","P7007007"),"F3":("Mrs","2","Maryam Al Hinai","1984-09-27","1","P8008008"),
   "M6":("Mr.","1","Ahmed Al Amri","1973-12-02","1","P9009009"),"F4":("Miss","2","Noor Al Saadi","1995-06-21","2","P1010101"),
   "F5":("Mrs","2","Rashid Al Maamari","1980-02-14","1","P1111111")}
n=0
for code,sub,name,plan,mode,term,who in V:
    n+=1; sal,gender,iname,dob,res,idno=P[who]
    start=datetime.date(2026,10,2); end=datetime.date(2026+term,10,1)
    body={"ApplicationNo":f"APP2610{n:04d}","EffectiveDate":start.isoformat(),"ExpiryDate":end.isoformat()+"T23:59:59","UserName":"maker01","ApplyDate":"2026-10-01",
      "BranchCode":"001","DiscountAmount":0,"StaffId":"76",
      "PolicyCustomerList":[{"CIFNumber":f"CIF{n:05d}","CustomerType":"1"}],
      "PolicyLobList":[{"PolicyRiskList":[{"Gender":gender,"IdNo":idno,"IdType":"1","Salutation":{"Mr.":"1","Mrs":"2","Miss":"3"}[sal],"InsuredName":iname,
        "DateOfBirth":dob,"ResidentStatus":res,"Email":iname.split()[0].lower()+"@example.com","MaritalStatus":"1","PostCode":"100","Mobile":f"9681234{n:04d}",
        "Address":"Muscat, Oman","MonthSalaryIncome":"1200","PlanList":[{"PlanId":plan}],
        "BeneficiaryList":[{"BeneficaryName":"Sample Beneficiary","RelationshipCode":"6","Share":"100","BeneficarySequence":"1"}],"ProductElementCode":"R00001"}],"ProductCode":code}],
      "PolicyPaymentInfoList":[{"LGCode":"23","LCCode":45,"IsInstallment":"N","DebitAccountNo":f"89623{n:04d}","DebitRefNo":f"REF{n:05d}","TransactionDate":"2026-10-01"}],
      "PolicyType":"1","ProductCode":code,"PremiumModeCode":mode,"ProductSubcode":sub,"PlanId":plan,"PolicyTerm":str(term)}
    json.dump(body,open(f"{B}/samples/req/{code}_{sub}_proposal.json","w"),indent=2)
    nop=dict(body); nop.pop("PolicyPaymentInfoList"); json.dump(nop,open(f"{B}/samples/req/{code}_{sub}_nopay.json","w"),indent=2)
print(n,"samples")
