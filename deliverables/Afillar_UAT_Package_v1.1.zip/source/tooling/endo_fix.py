import json,os,re,sys,subprocess,urllib.request,urllib.parse,urllib.error,time
B=os.environ['B']; GW=os.environ['GW']; TOK=os.environ['TOK']
po,eff,ctype,techid=sys.argv[1:5]
H={"Authorization":"Bearer "+TOK,"Content-Type":"application/json","x-mo-tenant-id":"uponly"}
E="/platform/endo/core/endo/v1"
allf=json.load(open(B+'/dd/_tenant_fields.json')); up={}
for grp in allf:
    for f in allf[grp]: up.setdefault(f['name'],f)
PF=["python3","/tmp/insuremo/insuremo-gi-product-config/scripts/policy_field.py","--gateway",GW,"--token",TOK,"--workspace",B+"/ws"]
def call(m,path,body=None):
    req=urllib.request.Request(GW+path,data=json.dumps(body).encode() if body is not None else (b"" if m=="POST" else None),method=m,headers=H)
    try:
        with urllib.request.urlopen(req,timeout=240) as r: return r.status,r.read().decode()
    except urllib.error.HTTPError as e: return e.code,e.read().decode()
def withdraw(p):
    s,t=call("GET",E+"/queryPendingEndo?policyId="+urllib.parse.quote(p['PolicyId']))
    if s==200 and t.strip().startswith('{'): call("POST",E+"/suspendEndorsement?endoId="+urllib.parse.quote(str(json.loads(t)['EndoId'])))
for i in range(60):
    s,t=call("GET",f"/platform/proposal/v1/load?policyNo={po}"); p=json.loads(t); withdraw(p)
    env={"EndoEffectiveDate":eff,"EndoType":"3","CancelType":ctype,"CancelReasonCode":"1","OtherCancelReason":"test","PolicyNo":po,"ProductId":p['ProductId'],"ProductCode":p['ProductCode'],"EndorsementPaymentInfoList":[{"PayModeCode":"30","IsInstallment":"Y","InstallmentType":"1"}]}
    s,t=call("POST",E+"/createEx",env)
    if s!=200: print("create failed",t[:300]); break
    created=json.loads(t); s,t=call("POST",E+"/calculateEx",created)
    if s==200:
        c=json.loads(t); print("CALC OK",{k:c.get(k) for k in ('GrossPremium','ShortRate','DuePremium','BeforeVatPremium')}); s2,t2=call("POST",E+"/validate",c); print("validate",s2,t2[:300]); withdraw(p); break
    withdraw(p)
    m=re.search(r'ObjectId=(\d+).{0,160}?(?:businessField\.field|businessFiledName)=(\w+)',t,re.S)
    if not m: print("OTHER ERROR",t[:700]); break
    obj,name=int(m.group(1)),m.group(2)
    if name=='VAT': name='Vat'
    f=up.get(name); ftype=f['type'] if f else -3
    print(i,"missing",name,"on",obj,"type",ftype,"(uponly)" if f else "(guess)")
    b={"BusinessObjectId":obj,"FieldType":ftype,"FieldName":name,"FieldCommentsEn":name,"FieldLabelEn":name,"IsFixed":"N","IsDeprecated":"N","IsMandatory":"N","IsTemp":"N","IsUnique":"N","IsIndexed":"N","IsInput":"Y"}
    body={"ContextTypeId":"5","ContextId":techid,"BusinessFieldBinding":b}
    path=f"{B}/payloads/endofix_{name}_{obj}.json"; json.dump(body,open(path,"w"))
    r=subprocess.run(PF+["--body-file",path,"--confirm","create-binding"],capture_output=True,text=True)
    print("   ->","ok" if "BindingId" in r.stdout else r.stdout[-200:])
