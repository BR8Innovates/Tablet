import json,os,sys
from datetime import date,timedelta
src=open("run_tests.py").read()
ns={"__name__":"m"}; exec(src.split("# ---------------------------------------------------------------- bodies")[0],ns)
exec(src.split("# ---------------------------------------------------------------- bodies")[1].split("CASES = []")[0],ns); ns["CASES"]=[]
http=ns["http"]; pb=ns["proposal_body"]; plans_of=ns["plans_of"]
for tag in sys.argv[1:]:
    code=tag.split("_")[0]
    plan=sorted(plans_of(tag))[0]
    b=pb(tag,plan); b["ChannelCode"]="SOHAR"; b["OrgCode"]="1"
    s,r=http("POST","/up/proposal",b)
    if s!=200: print(tag,"proposal",s,str(r)[:200]); continue
    s,r=http("POST","/up/issue",{"ChannelCode":"SOHAR","ProposalNo":r["ProposalNo"],"ProductCode":code})
    if s!=200: print(tag,"issue",s,str(r)[:200]); continue
    po=r["PolicyNo"]
    cd=(date.today()+timedelta(days=30)).isoformat()
    s,c=http("POST","/up/cancel-check",{"ChannelCode":"SOHAR","PolicyNo":po,"CancellationDate":cd,"CancelReason":"Customer request"})
    print(tag,po,"check",s,json.dumps(c)[:350])
    if s!=200: continue
    s,a=http("POST","/up/cancel-approve",{"ChannelCode":"SOHAR","PolicyNo":po,"RequestNo":c.get("RequestNo"),"Decision":"APPROVE"})
    print("   approve",s,json.dumps(a)[:500])
    s,l=http("GET","/up/load-policy",query="policyNo=%s&ChannelCode=SOHAR"%po); print("   policy status after:",l.get("PolicyStatus"))
