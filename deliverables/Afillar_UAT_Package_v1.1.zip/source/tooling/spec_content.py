"""Content model of the API specification (list of blocks) in the structure of the InsureMO reference specification."""
import json, os, re, collections
import model_data as md, api_spec_data as asd
INSURER = "Afillar Insurance Company"
SHORT = "Afillar"
BASE = "https://portal-gw.insuremo.com/platform/api-orchestration-test/v1/flow"
prods = md.products(); cts = md.code_tables(); rules = md.field_rules(); ex, vars_ = md.examples(); top = md.top_examples()
spec = asd.build(); res = json.load(open(os.environ["B"] + "/tests/results.json"))
blocks = []
def H1(t, anchor=None): blocks.append(("h1", t))
def H2(t, page=False): blocks.append(("h2", t, page))
def H3(t): blocks.append(("h3", t))
def P(t): blocks.append(("p", t))
def NOTE(t): blocks.append(("note", t))
def BUL(items): blocks.append(("bul", items))
def NUM(items): blocks.append(("num", items))
def TBL(head, rows, widths=None): blocks.append(("tbl", head, rows, widths))
def KV(k, v): blocks.append(("kv", k, v))
def CODE(t): blocks.append(("code", t))
def LBL(t): blocks.append(("lbl", t))
def FIG(name, caption): blocks.append(("fig", name, caption))
def js(o, n=45):
    t = json.dumps(o, indent=2, ensure_ascii=False).split("\n"); return "\n".join(t[:n] + (["  ..."] if len(t) > n else []))
def cond_desc(x):
    d = x["desc"]
    if x["req"] in ("C", "X") and x["cond"]: d += " - " + x["cond"][0].lower() + x["cond"][1:] if x["req"] == "C" else " - " + x["cond"]
    elif x["req"] == "O" and x["cond"]: d += " - " + x["cond"][0].lower() + x["cond"][1:]
    if x.get("allowed") and len(x["allowed"]) < 90: d += " (" + x["allowed"] + ")"
    elif x.get("allowed"): d += " (code table values in section 5)"
    if x.get("limits") and x["req"] in ("M", "C", "O") and "format" not in x["limits"][:7]:
        lim = re.sub(r";?\s*format .*$", "", x["limits"]).strip()
        if lim: d += "; " + lim
    return d
# ------------------------------------------------------------------ 1 Introduction
H1("1. Introduction")
H2("1.1 Purpose of the Document")
P(f"This document defines the Standard API Specification for selling and servicing {INSURER} retail insurance products through the InsureMO platform. It establishes a single orchestration layer — one request and response structure, one field-level data model and one workflow — that a channel, bank or broker integrates against once, while the platform absorbs the underlying rating, policy administration, endorsement and document services. It is designed to guide channel partners and integration teams through the technical and functional aspects of quoting, proposing, issuing, printing, cancelling and reporting policies.")
NOTE("This specification is a standard contract: every API, field and workflow described here applies uniformly to all products listed in section 4. Product specific values (plans, premiums, covers, age and term limits) are reference data and are listed in sections 4 and 5; they are returned by the APIs and are not hard-coded in the integration.")
H2("1.2 Target Audience")
BUL(["Digital Banking and Insurance Product Teams", "Integration Engineers and Solution Architects", "Insurance Product and Operations SMEs", "QA Automation Engineers", "InsureMO System Integrators"])
H2("1.3 Supported Use Cases")
BUL(["Plan, premium and cover lookup for an insured person (Get Plans), for single, annual and monthly premium modes",
     "Application (proposal) creation and update, with insured, beneficiary and payment details",
     "Policy issuance and retrieval of the proposal or policy record (Load Proposal / Policy)",
     "Policy documents — application form and policy certificate as PDF",
     "Policy cancellation with a maker-checker approval: the Checker calculates the refund (free look or pro-rata) and creates the request, the Approver approves or rejects it",
     "Proposal rejection for applications that are not taken forward",
     "Master data (code tables), commission query and policy feed file for reporting and reconciliation"])
H2("1.4 Contact Information")
TBL(["Contact Person", "Role", "Email"], [["", "", ""], ["", "", ""], ["", "", ""]], [34, 33, 33])
H2("1.5 Versioning & Release Log")
TBL(["Version", "Date", "Status", "Description"], [["v1.1", "02-Oct-2026", "Released", "CarrierCode and CarrierName (insurer code and name, from the insurer table) returned by every API and accepted as an optional, validated request field on Get Plans, Create Proposal and Update Proposal; insurer table added to the data tables; insurer master data available from Master Data."], ["v1.0", "02-Oct-2026", "Released", f"Standard API Kit — {INSURER}: Get Plans, Create Proposal, Update Proposal, Issue Policy, Load Proposal / Policy, Reject Proposal, Policy Documents, Cancellation (Checker and Approver), Master Data, Commission Query and Policy Feed File for seven products, with ChannelCode on every request."]], [12, 14, 12, 62])
# ------------------------------------------------------------------ 2 Workflow
H1("2. Workflow Overview")
H2("2.1 High-Level Integration Flow")
for t in ["Generate Access Token", "Get Plans — plans, premiums, commission and covers for the insured and the chosen product variant; plan eligibility, age and term rules are checked in the same call",
          "Create Proposal — captures the insured, beneficiary and payment detail for the chosen plan; the premium is calculated by the platform and returned in the same call",
          "Update Proposal — optional, while the proposal is open (enrolment, corrections)", "Issue Policy — issues the policy and returns the policy number",
          "Policy Documents — application form and policy certificate (PDF)", "Load Proposal / Policy — full record of a proposal or an issued policy",
          "Cancel Check (Checker) and Cancel Approve (Approver) — refund calculation, request and approval", "Reject Proposal — closes an open proposal that is not taken forward",
          "Master Data, Commission Query and Policy Feed File — reference data and reporting"]: P(t)
H2("2.2 Two Journeys: Sales and Servicing")
LBL("Journey A — Sales")
P("The channel shows the plans, creates the proposal for the chosen plan, optionally updates it with beneficiary and payment details, issues the policy and prints the documents. A proposal that is not wanted is rejected. An issued proposal cannot be updated, issued again or rejected.")
BUL(["Get Plans", "Create Proposal", "Update Proposal (optional)", "Issue Policy", "Policy Documents", "Load Proposal / Policy"])
LBL("Journey B — Cancellation (maker-checker)")
P("Cancellation needs two steps by two roles. The Checker calls Cancel Check with the cancellation date; the platform calculates the refund and creates a pending request. The Approver calls Cancel Approve with the request number: APPROVE cancels the policy and returns the refund, REJECT closes the request and keeps the policy in force.")
BUL(["Cancel Check (Checker) — premium details, refund details, request number", "Cancel Approve (Approver) — APPROVE or REJECT", "Load Policy — status Cancelled and the endorsement"])
H2("2.3 Step-by-Step Dependencies")
TBL(["Step", "Depends On", "Produces"], [
    ["Get Token", "Credentials", "Bearer Token"], ["Get Plans", "Token, ChannelCode, Product, Premium Mode, Insured date of birth", "Plans with DuePremium, Commission and covers"],
    ["Create Proposal", "Get Plans response (PlanId), insured detail", "ProposalNo, premium"], ["Update Proposal (Optional)", "ProposalNo", "Updated proposal"],
    ["Issue Policy", "ProposalNo (open proposal)", "PolicyNo"], ["Policy Documents", "PolicyNo or ProposalNo", "PDF"], ["Load Proposal / Policy", "ProposalNo or PolicyNo", "Full record"],
    ["Cancel Check (Checker)", "PolicyNo (in force), cancellation date, reason", "RequestNo, premium and refund details"], ["Cancel Approve (Approver)", "RequestNo, Decision", "Policy status, RefundPremium, EndorsementNo"],
    ["Reject Proposal", "ProposalNo (open)", "Confirmation"], ["Commission Query / Feed File", "PolicyNo, product, or a period", "Commission records / policy file"]], [30, 40, 30])
H2("2.4 Data Flow Diagrams")
LBL("2.4.1 Sales Journey — Sequence")
P("The diagram shows the touch points of the sales journey between the channel, the APIs and the platform services. Every call carries the bearer token and the ChannelCode.")
FIG("fig1", "Figure 1: Sales journey — sequence across the channel, the APIs and the platform")
LBL("2.4.2 Orchestration Flows — Sales and Cancellation")
P("The diagram lays out both journeys side by side. Every step is an atomic API; the cancellation journey is a maker-checker pair that works on the pending request created by the Checker.")
FIG("fig2", "Figure 2: Insurance API orchestration flows — Sales (Journey A) and Cancellation (Journey B)")
# ------------------------------------------------------------------ 3 APIs
H1("3. API Specifications")
H2("3.0 API Use Case")
USE = [("Get Token:", ["To get secure access to the APIs."]),
       ("Get Plans:", ["Returns every plan of the product variant with the annual (or single) premium, the commission and the cover list for the insured details sent.", "Checks the insured age and the term against the product rules when the date of birth and term are supplied.", "Supports single, annual and monthly premium modes where the product offers them."]),
       ("Create Proposal:", ["Takes the insured, beneficiary and payment detail and the chosen PlanId, and creates the proposal; the premium is calculated by the platform from the plan and is never taken from the request.", "Returns the ProposalNo used by every following call."]),
       ("Update Proposal:", ["Updates an open proposal before issue; the whole proposal is sent again."]),
       ("Issue Policy:", ["Issues an open proposal and returns the policy number and the policy data."]),
       ("Load Proposal / Policy:", ["Atomic query API: returns the stored proposal (proposalNo) or the issued policy (policyNo) of the calling channel."]),
       ("Reject Proposal:", ["Closes an open proposal with a reason."]),
       ("Policy Documents / Application Form:", ["Returns the policy certificate or the application form as PDF; the print data can be returned as JSON."]),
       ("Cancel Check (Checker):", ["Calculates the refund for the cancellation date (free look or pro-rata), returns premium details, refund details and the current policy status, and creates the pending cancellation request."]),
       ("Cancel Approve (Approver):", ["Approves the request (the policy is cancelled through a platform endorsement and the refund is returned) or rejects it (the policy stays in force)."]),
       ("Master Data:", ["Lists the values of a code table for drop-downs and validation."]),
       ("Commission Query:", ["Commission by policy, by plan configuration or for a period."]),
       ("Policy Feed File:", ["Generates the policy feed file for a period as Excel or JSON for reporting and reconciliation."])]
for k, items in USE: LBL(k); BUL(items)
# 3.1 Get Token
H2("3.1 Get Token", True)
P("This API is used to obtain an authentication token using the user name and password issued to your channel during onboarding. The token received from this endpoint is passed in the “Authorization” header as a Bearer token when invoking the subsequent APIs. When a call returns HTTP 401 the token has expired: call this API again.")
KV("Request URL:", "{casUrl}/cas/ebao/v2/json/tickets"); KV("Request Method:", "POST"); KV("Request Header:", "Content-Type: application/json  |  x-mo-user-source-id: platform  |  x-mo-tenant-id: {tenant} (tenant code provided at onboarding)")
LBL("Request Body Parameters")
TBL(["Parent Object", "Field Name", "Data Type", "Required", "Description"], [["", "username", "String", "M", "API user name issued to the channel"], ["", "password", "String", "M", "Password of the API user (never logged or echoed back)"]], [18, 22, 14, 12, 34])
NOTE("Response Content Type:  application/json")
LBL("Response Parameters")
TBL(["Parent Object", "Field Name", "Data Type", "Description"], [["", "access_token", "String", "Bearer access token (the Postman collection stores it in the variable token)"]], [20, 24, 14, 42])
# 3.x APIs
ORDER = ["UPGetPlans", "UPProposal", "UPUpdateProposal", "UPIssue", "UPLoadPolicy", "UPProposalReject", "UPDocGeneration", "UPApplicationDocGeneration", "UPCancelCheck", "UPCancelApprove", "UPListMasterTable", "UPCommissionQuery", "UPFeedFile"]
INTRO = {
 "UPGetPlans": "Returns the plans of a product variant with premium, commission and covers for the insured details supplied. Plan eligibility, the insured age and the policy term are checked against the product rules; the premium of every plan is calculated by the platform. The same policy body structure is used by Create Proposal, so the response can be reused as the base of the proposal.",
 "UPProposal": "Creates a proposal (application) for the chosen plan. The request carries the insured, beneficiary and payment detail together with the PlanId selected from Get Plans. The premium and commission are calculated by the platform from the plan; premium, commission, status and policy number values sent by the caller are ignored. Send OrgCode 1 (the service adds it when it is missing).",
 "UPUpdateProposal": "Updates an open proposal (enrolment: beneficiaries, payment details, corrected insured data). The complete proposal body is sent again together with the ProposalNo; the premium is recalculated. An issued or rejected proposal cannot be updated (HTTP 409).",
 "UPIssue": "Issues the policy for an open proposal and returns the policy data with the PolicyNo. The proposal must belong to the calling channel and to the ProductCode sent. A proposal that is already issued or rejected cannot be issued (HTTP 409).",
 "UPLoadPolicy": "Atomic query API that returns the stored proposal (proposalNo) or the issued policy (policyNo) of the calling channel, with code descriptions for the coded fields. PolicyStatus 2 = in force, 3 = cancelled.",
 "UPProposalReject": "Rejects an open proposal. An issued or already rejected proposal cannot be rejected (HTTP 409).",
 "UPDocGeneration": "Generates the policy certificate (DocType = Policy, by PolicyNo) or the application form (DocType = Application, by ProposalNo) as a PDF file. With PreviewData = Y the print data is returned as JSON.",
 "UPApplicationDocGeneration": "Generates the application form of a proposal as a PDF file.",
 "UPCancelCheck": "Used by the Checker. Calculates the refund for the cancellation date and creates the pending cancellation request. Cancellation up to 15 days after the policy start date is a free look cancellation with a 100% refund; later cancellations refund the pro-rata premium of the unexpired days at 80%. Calling it again for a policy with a pending request returns the same request.",
 "UPCancelApprove": "Used by the Approver. APPROVE cancels the policy (the policy status becomes 3 – Cancelled) and returns the refund premium and the endorsement number; REJECT closes the request and keeps the policy in force. A request can be decided once; a second call returns HTTP 404.",
 "UPListMasterTable": "Lists the records of a master (code) table, or one record when Id is sent.",
 "UPCommissionQuery": "Returns commission by policy, by plan configuration (product, sub-product, plan) or for a period (with paging).",
 "UPFeedFile": "Generates the policy feed file for the effective-date period as an Excel file (or JSON). The result is limited in size: narrow the period and page through the result."}
ERR = {"UPGetPlans": ["400 OUT_OF_RANGE — insured age or term outside the product limits", "400 NOT_ALLOWED — premium mode not allowed for the product", "400 REQUIRED — PremiumModeCode where plans differ by mode"],
       "UPProposal": ["400 UP-VALIDATION — age, term, premium mode, code values, INVALID_TOTAL for beneficiary shares", "A duplicate ApplicationNo is not rejected: use a unique value"],
       "UPUpdateProposal": ["404 unknown proposal", "400 MISMATCH — product differs from the stored proposal", "409 — proposal already issued or rejected"],
       "UPIssue": ["404 unknown proposal", "400 MISMATCH — ProductCode differs", "409 — already issued or rejected"], "UPLoadPolicy": ["400 — neither or both of policyNo and proposalNo", "404 — not found for the channel"],
       "UPProposalReject": ["404 unknown proposal", "409 — already issued or rejected"], "UPDocGeneration": ["404 unknown policy or proposal", "400 REQUIRED — PolicyNo or ProposalNo for the DocType"], "UPApplicationDocGeneration": ["404 unknown proposal"],
       "UPCancelCheck": ["404 unknown policy", "400 — cancellation date before the start or after the expiry date", "409 — proposal not issued, policy already cancelled, or another endorsement pending"],
       "UPCancelApprove": ["404 — request not found or already decided", "400 NOT_ALLOWED — Decision", "409 — the platform refused the cancellation; the request stays pending"], "UPListMasterTable": ["400 NOT_ALLOWED — table not available"],
       "UPCommissionQuery": ["400 REQUIRED — none of PolicyNo, ProductCode or FromDate + ToDate", "400 OUT_OF_RANGE — PageSize above 50", "404 unknown policy"], "UPFeedFile": ["400 — date range missing or too large", "400 OUT_OF_RANGE — PageSize above 50"]}
EXKEY = {"UPGetPlans": "get-plans", "UPProposal": "proposal", "UPUpdateProposal": "update-proposal", "UPIssue": "issue", "UPLoadPolicy": "load-policy", "UPProposalReject": "proposal-reject",
         "UPDocGeneration": "doc-policy", "UPApplicationDocGeneration": "doc-application", "UPCancelCheck": "cancel-check", "UPCancelApprove": "cancel-approve"}
TOPKEY = {"UPListMasterTable": "master", "UPCommissionQuery": "commission_by_policy", "UPFeedFile": "feedfile"}
n = 1
for api in ORDER:
    n += 1; sp = spec[api]
    H2(f"3.{n} {sp['title']}", True)
    P(INTRO[api])
    KV("Request URL:", sp["path"]); KV("Request Method:", sp["method"])
    KV("Request Header:", "Authorization: Bearer {access_token}" + ("" if sp["method"] == "GET" else "  |  Content-Type: application/json"))
    LBL("Query Parameters" if sp["method"] == "GET" else "Request Body Parameters")
    rows = [[x["parent"], x["name"], x["dtype"], x["req"], cond_desc(x)] for x in sp["inputs"]]
    TBL(["Parent Object", "Field Name", "Data Type", "Required", "Description"], rows, [19, 21, 10, 11, 39])
    NOTE("Required: M = Mandatory, O = Optional, C = Conditional mandatory (the condition is stated in the description), X = must not be sent." + (" The optional insured and policy fields are used for the age and premium check when they are supplied." if api == "UPGetPlans" else ""))
    NOTE("Response Content Type:  " + ("application/pdf" if api in ("UPDocGeneration", "UPApplicationDocGeneration") else ("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet (Excel) or application/json" if api == "UPFeedFile" else "application/json")))
    LBL("Response Parameters")
    rows = [[x["parent"], x["name"], x["dtype"], x["desc"] + (" (" + x["cond"][0].lower() + x["cond"][1:] + ")" if x["req"] == "C" and x["cond"] else "")] for x in sp["outputs"]]
    TBL(["Parent Object", "Field Name", "Data Type", "Description"], rows, [18, 24, 11, 47])
    # samples
    s = ex.get(EXKEY.get(api)); req = None; resp = None; qs = ""
    if s:
        req, resp, qs = s["request"], s["response"], (("?" + s["query"]) if s["query"] else "")
    elif api in TOPKEY and top.get(TOPKEY[api]):
        j = top[TOPKEY[api]]; req = md.resolve(j["request"]["body"], vars_ | {"monthStart": "2026-10-01", "monthEnd": "2026-10-31"}); resp = j["response"]["body"]
    if req is not None or qs:
        LBL("Sample Request"); CODE(f"{sp['method']} {{baseUrl}}{sp['path']}{qs}" + (("\n" + js(req)) if req is not None else ""))
    if resp is not None and not (isinstance(resp, dict) and (resp.get("_pdf") or resp.get("_xlsx"))):
        LBL("Sample Response"); CODE(js(md.trim(resp[:2] if isinstance(resp, list) else resp), 40))
    LBL("Errors"); BUL(ERR[api] + ["Common errors (400 validation, 401, 404, 409, 422, 500) are described in section 7."])
# ------------------------------------------------------------------ 4 data model
H1("4. Standard Data Model — Product, Plan & Cover Reference")
P("The tables below define the products, plans and covers available through the APIs. Not every cover is available on every plan; the Get Plans response surfaces only the covers a plan actually includes.")
H2("4.1 Products and Variants")
TBL(["Product Code", "ProductSubcode", "Product Name", "Insurer", "Premium Modes", "Term (years)", "Insured Age", "Free Look / Refund"],
    [[p["code"], p["sub"], p["name"], "AFIC - " + INSURER, ", ".join(f"{c.strip()} = {dict(cts.get('PremiumMode', [])).get(c.strip(), '')}" for c in str(p["rule"].get("PremiumModes", "")).split(",")), f"{p['rule'].get('MinTerm','')}-{p['rule'].get('MaxTerm','')}", f"{p['rule'].get('MinAge','')}-{p['rule'].get('MaxAge','')}", f"{p['rule'].get('FreeLookDays','')} days / {p['rule'].get('ProRataRefundPercent','')}%"] for p in prods], [10, 8, 18, 18, 18, 7, 8, 13])
H2("4.2 Cover Catalogue")
bens = collections.OrderedDict()
for p in prods:
    for b in p["covers"]: bens.setdefault(b["BenefitCode"], [b["BenefitDesc"], []])[1].append(f"{p['code']}-{p['sub']}")
TBL(["IMO Cover Code", "Cover Name", "Available In (Product - Sub)"], [[c, v[0], ", ".join(sorted(set(v[1])))] for c, v in bens.items()], [18, 34, 48])
H2("4.3 Plans, Premiums and Sums Insured")
P("Premium is the annual premium of the plan (single premium products: the premium for the whole term). The amount for a given insured is always returned by Get Plans.")
rows = []
for p in prods:
    for pl in p["plans"]:
        cv = [b for b in p["covers"] if b["IMOPlanCode"] == pl["IMOPlanCode"]]
        rows.append([p["code"] + "-" + p["sub"], f"{pl['IMOPlanCode']} - {pl['IMOPlanName']}", pl["Premium"], pl["Commission"], "; ".join(f"{b['BenefitCode']} {b['BenefitLimit']}" for b in cv)])
TBL(["Product - Sub", "Plan", "Premium", "Commission", "Covers and limits"], rows, [14, 14, 11, 12, 49])
# ------------------------------------------------------------------ 5 data tables
H1("5. Data Tables")
P("Master reference tables used throughout this specification. The values can be listed with the Master Data API.")
DESCT = {"UP_Carrier": ("Insurer (carrier) master: CarrierCode and CarrierName of the insurer of the products", "CarrierCode"), "BranchCode": ("Branch master", "BranchCode"), "CustomerType": ("Customer type master", "Id"), "GenderCode": ("Gender master", "Id"), "IdType": ("ID type master", "Id"), "InsMaritalStatus": ("Marital status master", "Id"),
         "Plan": ("Plan master (plan id of the product variants)", "Id"), "PremiumMode": ("Premium mode master (single, annual, monthly)", "Id"), "Relationship": ("Beneficiary relationship master", "Id"), "ResidentStatus": ("Resident status master", "Id"), "Salutation": ("Salutation master", "Id")}
TBL(["S.No.", "Table Name", "Purpose", "Input Column Name"], [[str(i), t, DESCT[t][0], DESCT[t][1]] for i, t in enumerate(DESCT, 1)], [8, 24, 48, 20])
H2("5.1 Code Table Values")
for t in DESCT:
    LBL(t); TBL(["Code", "Description"], [[c, d] for c, d in cts.get(t, [])], [20, 80])
# ------------------------------------------------------------------ 6 business rules
H1("6. Business Rules")
H2("6.1 Eligibility, Premium Mode and Term")
P("The insured age is calculated from the date of birth at the effective date and checked against the minimum age, the maximum entry age and the maximum exit age (age + term) of the product (section 4.1). A single premium covers the whole term and the term must lie within the product limits; for annual and monthly premium the term is one year. The premium is calculated by the platform from the plan: premium, commission and discount values sent by the caller do not change it.")
H2("6.2 Cancellation and Refund")
TBL(["Case", "Refund"], [["Cancellation date up to 15 days after the policy start date (free look)", "100% of the premium"], ["Later", "premium × unexpired days ÷ policy days × 80%"]], [60, 40])
P("Policy days = days from the start date to the expiry date, both included; unexpired days = policy days minus the days since commencement. Amounts are rounded half up to 2 decimals. Example: premium 70.00, policy of 365 days, cancelled 29 days after the start date: 70.00 × 336 ÷ 365 = 64.44; 64.44 × 80% = 51.55. The free look days and the refund percentage are set per product (section 4.1). A proposal must be issued before it can be cancelled; a cancelled policy cannot be cancelled again; the cancellation date must lie between the start and the expiry date.")
# ------------------------------------------------------------------ 7 errors and security
H1("7. Error Handling and Security")
H2("7.1 Error Response")
P("Errors raised by the APIs have one structure:")
CODE(js(next(x["response"] for x in res if x["status"] == 400 and isinstance(x["response"], dict) and x["response"].get("code") == "UP-VALIDATION" and x["api"] == "UPGetPlans")))
TBL(["HTTP", "code", "Meaning", "Action"], [
    ["400", "UP-VALIDATION", "One or more fields are wrong; errors[] lists every problem (field, code, message)", "Fix the fields and resend"], ["400", "UP-400", "The request cannot be processed", "Correct the request"],
    ["401", "—", "Missing, invalid or expired token", "Get a new token"], ["404", "UP-404", "The proposal, policy or request does not exist for the channel", "Check the number and the channel"],
    ["409", "UP-409", "Not allowed in the current state (issued, rejected, cancelled, pending)", "Read the record and follow its state"], ["422", "—", "Wrong HTTP method for the path", "Use the documented method"],
    ["500", "UP-500 / UP-CONFIG", "Unexpected error; the message is generic", "Retry once, then contact support with the trace_id"]], [8, 20, 46, 26])
H2("7.2 Field Error Codes")
codes = collections.OrderedDict()
for x in res:
    b = x["response"]
    if isinstance(b, dict):
        for e in b.get("errors") or []: codes.setdefault(e.get("code"), e.get("message"))
mean = {"REQUIRED": "A required field is missing or empty", "INVALID_FORMAT": "The value does not match the required format", "INVALID_TYPE": "The value has the wrong type", "TOO_SHORT": "Shorter than the minimum length", "TOO_LONG": "Longer than the maximum length",
        "OUT_OF_RANGE": "Outside the allowed range (age, term, amount, page size, date)", "NOT_ALLOWED": "The value or the combination is not allowed", "UNKNOWN_VALUE": "The value is not in the list of allowed values",
        "MISMATCH": "The value does not match the stored proposal / policy", "INVALID_TOTAL": "Beneficiary shares do not total 100", "INVALID_CHARACTER": "The value contains a character that is not allowed", "INVALID_BODY": "The body is not a JSON object", "RANGE_TOO_LARGE": "The selection is too large"}
codes.setdefault("INVALID_CHARACTER", ""); codes.setdefault("INVALID_BODY", "")
TBL(["Code", "Meaning"], [[c, mean.get(c, "")] for c in codes if c], [25, 75])
H2("7.3 Request Conventions and Security")
BUL(["JSON, UTF-8, HTTPS only. Dates YYYY-MM-DD; expiry date YYYY-MM-DDT23:59:59.", "ChannelCode is required on every request and a record can only be used by the channel that created it.", "Text fields may contain letters (any script), digits, space and . , ' - / @ + ( ); the characters < > $ { } ` \\ | ^ ~ ; and control characters are rejected (INVALID_CHARACTER).",
     "Do not send server-owned fields (policy number, ids, statuses); they are ignored. Responses may contain additional technical fields: ignore what is not documented.", "Create and approve calls are not idempotent: after a lost answer read the record before repeating the call.",
     "Keep tokens and credentials secret; never log request or response bodies containing personal data in clear text; the mobile number is returned masked.", "Use separate API users for the Checker and the Approver role of the cancellation process.", "Quote the trace_id of the response when contacting support."])
# ------------------------------------------------------------------ 8 testing
H1("8. Testing and Go-Live")
NUM(["Import the Sohar Bank Postman collection and environment, set username and password and run Get Token.", "Run the folder of a product from top to bottom: plans, proposal, update, load, issue, load policy, reject, documents, cancel check, cancel approve, load cancelled policy.",
     "Test the error cases of section 7: missing field, unknown number, second issue, second approval.", "Agree the production base URL, credentials and the Checker / Approver users with the Afillar integration team.",
     "Go-live checklist: token renewal on 401, unique ApplicationNo, ChannelCode and OrgCode on every proposal, handling of 400 / 404 / 409, storing ProposalNo, PolicyNo, RequestNo and trace_id."])
