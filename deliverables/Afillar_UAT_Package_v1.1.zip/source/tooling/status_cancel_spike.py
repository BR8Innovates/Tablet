#!/usr/bin/env python3
"""Spike: can an issued Uponly policy be set to Cancelled through the platform's own proposal update calls?
Works on ONE throwaway Uponly policy only (the policy must be in force, product code one of the 7 Uponly products, never PA001).
  status_cancel_spike.py            dry run: loads the policy and prints what it would send (nothing is written)
  status_cancel_spike.py --apply    tries /updateEx then /save, reloading the policy after each, and stops at the first that persists
Log: status_cancel_spike.log (no tokens)."""
import json, os, sys, time, urllib.request, urllib.error
GW = os.environ["GW"]; TOK = os.environ["TOK"]; B = os.environ["B"]
CANCELLED = "3"                                    # policy status code for Cancelled (UP_ApiConfig PolicyStatusCancelled)
UPONLY = {"UPPA001", "TL001", "FP001", "HC001", "CI001", "LP001", "DH001"}
H = {"Authorization": "Bearer " + TOK, "Content-Type": "application/json", "x-mo-tenant-id": "uponly"}
apply = "--apply" in sys.argv
policy_no = json.load(open(os.path.dirname(B) + "/throwaway.json"))["policy"]
def log(m): print(m, flush=True); open(B + "/status_cancel_spike.log", "a").write(time.strftime("%H:%M:%S ") + m + "\n")
def call(m, path, body=None):
    req = urllib.request.Request(GW + path, data=json.dumps(body).encode() if body is not None else None, method=m, headers=H)
    try:
        with urllib.request.urlopen(req, timeout=240) as r: return r.status, r.read().decode()
    except urllib.error.HTTPError as e: return e.code, e.read().decode()
def load():
    s, t = call("GET", "/platform/proposal/v1/load?policyNo=" + policy_no); return json.loads(t)
p = load()
assert p["ProductCode"] in UPONLY, "not an Uponly product"
assert str(p["PolicyStatus"]) == "2", "policy is not in force: " + str(p["PolicyStatus"])
log(f"policy {policy_no} ({p['ProductCode']}) status {p['PolicyStatus']} version {p.get('VersionSeq')}")
body = dict(p); body["PolicyStatus"] = int(CANCELLED)
for path in ("/platform/proposal/v1/updateEx", "/platform/proposal/v1/save"):
    if not apply: log(f"DRY RUN: would POST {path} with PolicyStatus={CANCELLED}"); continue
    s, t = call("POST", path, body)
    try: msg = json.loads(t).get("message", "")[:200] if s != 200 else "ok"
    except Exception: msg = t[:200]
    q = load(); log(f"{path} -> HTTP {s} {msg}; policy status after: {q['PolicyStatus']}")
    if str(q["PolicyStatus"]) == CANCELLED: log("status persisted"); break
