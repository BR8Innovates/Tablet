#!/usr/bin/env python3
"""Adds ONE field binding, IsAdminChange (string), to the cancellation endorsement object (id 300224988) for the Uponly TECH products only.
It never touches PA001: the product list comes from products.json and the script refuses any other id.
  bind_cancel_field.py            dry run: prints the 7 requests, changes nothing
  bind_cancel_field.py --apply    creates the bindings and logs them to bind_cancel_field.log"""
import json, os, subprocess, sys, time
B = os.environ["B"]; GW = os.environ["GW"]; TOK = os.environ["TOK"]
OBJECT = 300224988; FIELD = "IsAdminChange"; TYPE_STRING = -4
techs = {code: v["tech"] for code, v in json.load(open(B + "/products.json")).items()}
assert set(techs) == {"UPPA001", "TL001", "FP001", "HC001", "CI001", "LP001", "DH001"}
PF = ["python3", "/tmp/insuremo/insuremo-gi-product-config/scripts/policy_field.py", "--gateway", GW, "--token", TOK, "--workspace", B + "/ws"]
apply = "--apply" in sys.argv
for code, tech in techs.items():
    b = {"BusinessObjectId": OBJECT, "FieldType": TYPE_STRING, "FieldName": FIELD, "FieldCommentsEn": FIELD, "FieldLabelEn": FIELD, "IsFixed": "N", "IsDeprecated": "N", "IsMandatory": "N", "IsTemp": "N", "IsUnique": "N", "IsIndexed": "N", "IsInput": "Y"}
    body = {"ContextTypeId": "5", "ContextId": str(tech), "BusinessFieldBinding": b}
    if not apply: print("DRY RUN", code, "context", tech, json.dumps(b)); continue
    path = f"{B}/payloads/cancel_{FIELD}_{code}.json"; json.dump(body, open(path, "w"))
    r = subprocess.run(PF + ["--body-file", path, "--confirm", "create-binding"], capture_output=True, text=True)
    line = f"{time.strftime('%H:%M:%S')} {code} tech {tech}: " + ("ok" if "BindingId" in r.stdout else (r.stdout + r.stderr)[-200:].replace("\n", " "))
    print(line); open(B + "/bind_cancel_field.log", "a").write(line + "\n")
