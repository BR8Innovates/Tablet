import json, os, glob, collections
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from common_tests import *
res = load(); B = os.environ["B"]
wb = Workbook()
HDR = PatternFill("solid", fgColor="1F4E78"); WH = Font(bold=True, color="FFFFFF"); GREEN = PatternFill("solid", fgColor="C6EFCE"); RED = PatternFill("solid", fgColor="FFC7CE"); GREY = PatternFill("solid", fgColor="EDEDED")
def header(ws, row, cols, widths=None):
    for i, c in enumerate(cols, 1):
        cell = ws.cell(row=row, column=i, value=c); cell.fill = HDR; cell.font = WH; cell.alignment = Alignment(wrap_text=True, vertical="center")
        if widths: ws.column_dimensions[get_column_letter(i)].width = widths[i - 1]
    ws.freeze_panes = ws.cell(row=row + 1, column=1)
def cut(v, n=30000):
    s = v if isinstance(v, str) else json.dumps(v, ensure_ascii=False, indent=1)
    return s if len(s) <= n else s[:n] + " ...(truncated)"
# ---------- All cases
ws = wb.active; ws.title = "All cases"
cols = ["ID", "Group", "API", "Product", "Variant", "Plan", "Success/Failure", "Case", "Method", "Path", "Expected", "Actual HTTP", "Result", "Reason", "Trace id", "Request", "Response"]
header(ws, 1, cols, [9, 20, 24, 10, 8, 6, 10, 55, 8, 30, 38, 8, 8, 30, 34, 60, 60])
for i, r in enumerate(res, 2):
    q = r["body"] if r.get("body") is not None else r.get("query")
    vals = [r["id"], r["group"], r["api"], product_of(r), sub_of(r), r.get("plan") or "", kind(r), r["title"], r["method"], r["path"], exp_text(r["expect"]), r["status"], r["result"], r["reason"], trace(r), cut(q if q is not None else "", 8000), cut(r["response"], 8000)]
    for j, v in enumerate(vals, 1):
        c = ws.cell(row=i, column=j, value=v)
        if j in (16, 17): c.alignment = Alignment(wrap_text=False, vertical="top")
    ws.cell(row=i, column=13).fill = GREEN if r["result"] == "PASS" else RED
ws.auto_filter.ref = f"A1:{get_column_letter(len(cols))}{len(res) + 1}"
n = len(res) + 1
# ---------- Summary
NPLAN = len([d for d in glob.glob(B + "/samples/ref/*_P*") if os.path.exists(d + "/12_cancel-approve.json")])
sm = wb.create_sheet("Summary", 0)
sm["A1"] = "Uponly API test report"; sm["A1"].font = Font(bold=True, size=16)
info = [("Environment", "Uponly tenant, test route /platform/api-orchestration-test/v1/flow/up/..."), ("Run date", "2026-10-01"), ("Scope", "13 APIs x 7 products (11 variants, 52 plans). Every request carries ChannelCode (SOHAR). Cancellation = Checker (cancel-check) + Approver (cancel-approve)."),
        ("PA001", "Snapshot of PA001 tables, rows and product entries before vs after: unchanged")]
for i, (k, v) in enumerate(info, 3): sm.cell(row=i, column=1, value=k).font = Font(bold=True); sm.cell(row=i, column=2, value=v)
r0 = 8
sm.cell(row=r0, column=1, value="Total cases").font = Font(bold=True); sm.cell(row=r0, column=2, value=f"=COUNTA('All cases'!A2:A{n})")
sm.cell(row=r0 + 1, column=1, value="Passed").font = Font(bold=True); sm.cell(row=r0 + 1, column=2, value=f"=COUNTIF('All cases'!M2:M{n},\"PASS\")")
sm.cell(row=r0 + 2, column=1, value="Failed").font = Font(bold=True); sm.cell(row=r0 + 2, column=2, value=f"=COUNTIF('All cases'!M2:M{n},\"FAIL\")")
sm.cell(row=r0 + 3, column=1, value="Pass rate").font = Font(bold=True); sm.cell(row=r0 + 3, column=2, value=f"=B{r0+1}/B{r0}"); sm.cell(row=r0 + 3, column=2).number_format = "0.0%"
sm.cell(row=r0 + 4, column=1, value="Plan flows passed").font = Font(bold=True); sm.cell(row=r0 + 4, column=2, value=f"=COUNTIF('Plan flows'!O2:O{NPLAN + 1},\"PASS\")&\" of {NPLAN}\"")
def block(title, col_letter, values, start):
    sm.cell(row=start, column=1, value=title).font = Font(bold=True, size=12)
    for j, h in enumerate(["", "Cases", "Passed", "Failed"], 1):
        c = sm.cell(row=start + 1, column=j, value=h if j > 1 else title.split(" ")[-1]); c.fill = HDR; c.font = WH
    for i, v in enumerate(values, start + 2):
        sm.cell(row=i, column=1, value=v)
        sm.cell(row=i, column=2, value=f"=COUNTIF('All cases'!{col_letter}$2:{col_letter}${n},A{i})")
        sm.cell(row=i, column=3, value=f"=COUNTIFS('All cases'!{col_letter}$2:{col_letter}${n},A{i},'All cases'!M$2:M${n},\"PASS\")")
        sm.cell(row=i, column=4, value=f"=B{i}-C{i}")
    return start + len(values) + 3
nxt = block("Results by API", "C", list(collections.OrderedDict.fromkeys(r["api"] for r in res)), 15)
nxt = block("Results by group", "B", list(collections.OrderedDict.fromkeys(r["group"] for r in res)), nxt)
nxt = block("Results by product", "D", KNOWN + ["Common"], nxt)
nxt = block("Results by Success/Failure type", "G", ["Success", "Failure"], nxt)
sm.column_dimensions["A"].width = 38; sm.column_dimensions["B"].width = 16
for c in "CD": sm.column_dimensions[c].width = 10
sm.cell(row=nxt, column=1, value="Not covered").font = Font(bold=True, size=12)
for i, t in enumerate(["Runtime (non-test) route, load/performance, role permissions (security testing: see the Security probe sheet and the VAPT report)"], nxt + 1): sm.cell(row=i, column=1, value=t)
# ---------- Plan flows
pf = wb.create_sheet("Plan flows")
STEPS = ["get-plans", "proposal", "update-proposal", "load-proposal", "issue", "load-policy", "proposal-for-reject", "proposal-reject", "doc-application", "doc-policy", "cancel-check", "cancel-approve", "load-cancelled"]
cols = ["Variant / plan"] + STEPS + ["Result", "Result"]
header(pf, 1, ["Variant / plan"] + STEPS + ["Result"], [22] + [14] * 13 + [10])
i = 2
for d in sorted(glob.glob(B + "/samples/ref/*_P*"), key=lambda x: (x.split("/")[-1].split("_P")[0], int(x.rsplit("_P", 1)[1]))):
    pf.cell(row=i, column=1, value=os.path.basename(d))
    sts = []
    for k, s in enumerate(STEPS, 1):
        fn = f"{d}/{k:02d}_{s}.json"; st = json.load(open(fn))["response"]["status"] if os.path.exists(fn) else "-"; sts.append(st)
        c = pf.cell(row=i, column=k + 1, value=st); c.fill = GREEN if st == 200 else RED
    pf.cell(row=i, column=15, value=f'=IF(COUNTIF(B{i}:N{i},200)=13,"PASS","FAIL")'); i += 1
# ---------- Failures and fixes
fx = wb.create_sheet("Failures and fixes")
header(fx, 1, ["#", "Found by the suite", "Fix", "Run found"], [4, 90, 90, 12])
fixes = [("Empty request body {} returned HTTP 500 (null pointer) on 9 APIs", "Null body treated as empty input; validator returns the field errors", "1"),
 ("Issue / reject / update of an unknown proposal returned 500; documents for an unknown policy or proposal returned 500", "Existence check first: HTTP 404 with a clear message", "1"),
 ("Issue / update / reject of an already issued proposal returned 500 from the platform", "HTTP 409 UP-409 (status codes come from UP_ApiConfig)", "2"),
 ("A rejected proposal could be issued and rejected again", "Rejected proposals return HTTP 409 for issue, update and reject", "2"),
 ("Update / issue / reject with another product than the stored proposal was accepted", "HTTP 400 MISMATCH on ProductCode / ProductSubcode", "2"),
 ("A wrong sub-product code reported two errors (format and unknown)", "Product-dependent checks skipped when the product fields already failed", "1"),
 ("Get plans without premium mode on LP001 returned both modes mixed", "PremiumModeCode REQUIRED where plans differ by mode", "1"),
 ("Test data issues: GET object test, feed file test with PA001, short sub-code pattern test", "Tests corrected, no product change", "1"),
 ("Repeat cancellation check on a policy with a pending request returned 500: the endorsement service needs the signed policy id", "Signed id taken from the platform load; id sent once-encoded", "3"),
 ("Platform business errors during cancellation approval escaped as HTTP 500 (the REST client raises its own exception)", "UPPlatformClient returns status + message; approver answers 409 and keeps the request pending", "3"),
 ("Unexpected errors gave no usable trace", "Generic text to the caller; full exception logged with the trace id", "3"),
 ("Proposal without OrgCode kept the platform default -1 and could not be cancelled", "Default branch 1 applied (UPSecurity.defaultOrgCode); caller value kept", "4"),
 ("Free-text fields accepted script, template and command text", "UPSecurity.scan: blocked characters, free-text allow-list (400 INVALID_CHARACTER)", "4"),
 ("Client could send PolicyNo / PolicyStatus (500 with database text, 500 / 502)", "Server-owned fields removed; internal platform text replaced by a generic message", "4"),
 ("JSON array / text / number body gave HTTP 500", "UPSecurity.readInput: 400 INVALID_BODY", "4")]
for i, (a, b, c) in enumerate(fixes, 2):
    for j, v in enumerate([i - 1, a, b, c], 1): fx.cell(row=i, column=j, value=v).alignment = Alignment(wrap_text=True, vertical="top")
# ---------- Rules / config
def rows_from(prefix):
    out = []
    for f in sorted(glob.glob(B + f"/tables/{prefix}*.json")):
        d = json.load(open(f)); out += d if isinstance(d, list) else [d]
    return out
def sheet(title, rows, cols, widths):
    w = wb.create_sheet(title); header(w, 1, cols, widths)
    for i, r in enumerate(rows, 2):
        for j, c in enumerate(cols, 1): w.cell(row=i, column=j, value=r.get(c, ""))
    w.auto_filter.ref = f"A1:{get_column_letter(len(cols))}{len(rows) + 1}"
rr = rows_from("r_UP_FieldRule_"); sheet("Validation rules", rr, ["Id", "Api", "Path", "Label", "Required", "DataType", "MinLength", "MaxLength", "Pattern", "MinValue", "MaxValue", "CodeTable", "CodeColumn", "EnumValues", "AppliesTo", "WhenPath", "WhenValue"], [5, 24, 55, 26, 8, 9, 8, 8, 30, 8, 8, 14, 12, 14, 24, 12, 12])
cf = rows_from("r_UP_ApiConfig_") + rows_from("r_cfg"); sheet("Config (UP_ApiConfig)", cf, ["Id", "Api", "Scope", "Key", "Value"], [5, 8, 8, 32, 90])
sheet("Wording (UP_DocWording)", rows_from("r_UP_DocWording_") + rows_from("r_wordA_"), ["Id", "ModeCode", "Key", "Value"], [5, 10, 18, 120])
sheet("Benefit text", rows_from("r_UP_BenefitText_") + rows_from("r_benA_"), ["Id", "ProductCode", "BenefitCode", "NameEn", "NameAr"], [5, 12, 12, 45, 45])
sheet("Channels (UP_Channel)", rows_from("r_channel_0"), ["Id", "ChannelCode", "Description", "IsActive"], [5, 14, 30, 10])
sheet("Feed columns", rows_from("r_feedcol"), ["Id", "Sequence", "Heading", "Source"], [5, 10, 34, 70])
dflt = [("Risk element R00001, policy status 2, sequence 1, IsAutoAttachedForm Y, customer flags, instalment structure, zero-premium field list, IsPremiumCalcSuccess, BusinessCateCode", "UP_ApiConfig"),
        ("Template version, print service URL, gateway URL, proposal status codes, page sizes, effective date offset, success text, commission switch", "UP_ApiConfig"),
        ("Premium mode wording (English / Arabic)", "UP_DocWording"), ("English / Arabic benefit names", "UP_BenefitText"), ("Field rules", "UP_FieldRule"),
        ("Free look 15 days / refund 80% fallback, policy term default 1, IsInstallment default N, plan name default", "Removed: a missing value is an error (HTTP 500 UP-CONFIG or 400 REQUIRED)"),
        ("Y / N flag values in about 20 places", "UP_ApiConfig TrueValue / FalseValue"), ("Premium mode meaning (single premium = mode 1, other modes fixed term 1)", "UP_ApiConfig SinglePremiumModeCode / NonSingleTermYears"),
        ("Print settings (pdf, not_store, sync), content type, file name pattern, document type names", "UP_ApiConfig PrintExportType / PrintStorage / PrintMode / DocContentType / DocFileNamePattern / DocTypeApplication / DocTypePolicy"),
        ("Search constants (sort field, sort type, module, day start / end), feed file name, sheet name, content type, caps", "UP_ApiConfig Search* / DayStartTime / DayEndTime / Feed*"), ("26 feed file column headings and sources", "Table UP_FeedColumn"),
        ("Date, money, number formats, plan label prefix, benefit limit phrases", "UP_ApiConfig DateFormatDoc / MoneyFormat / NumberFormat / PlanLabelPrefix, UP_DocWording BASIS:*"),
        ("Beneficiary share total 100, money scale 2, rounding HALF_UP, percent base 100", "UP_ApiConfig BeneficiaryShareTotal / MoneyScale / RoundingMode / PercentBase"),
        ("Cancellation status / type / reason / pay-mode codes, endorsement paths, refund type names, request statuses, decisions", "UP_ApiConfig Endo* / Cancel* / RefundType* / RequestStatus* / Decision* / ProposalLoadPath"),
        ("Allowed master-table list duplicated in the API", "Single list in UP_ApiConfig MasterTables"), ("Benefit name fallback to the plan table description", "Row required in UP_BenefitText (config error if missing)"),
        ("Cancel reason default sentence, first plan as default PlanId", "Removed: CancelReason and PlanId are required"), ("Error texts for server / config / number errors", "UP_ApiConfig MsgServerError / MsgConfigError / MsgInvalidNumber"),
        ("Hosts the caller's token may be sent to", "UP_ApiConfig AllowedHosts (https only)")]
w = wb.create_sheet("Defaults removed"); header(w, 1, ["Hard-coded in code before", "Now"], [110, 60])
for i, (a, b) in enumerate(dflt, 2): w.cell(row=i, column=1, value=a); w.cell(row=i, column=2, value=b)
# ---------- Security probe results
sp = B + "/security/results.json"
if os.path.exists(sp):
    sd = json.load(open(sp)); w = wb.create_sheet("Security probe"); header(w, 1, ["ID", "Category", "Check", "Sent", "Expected", "HTTP", "Verdict", "Evidence"], [8, 26, 60, 34, 50, 7, 9, 80])
    for i, r in enumerate(sd["results"], 2):
        for j, k in enumerate(["id", "category", "title", "sent", "expectation", "status", "verdict", "evidence"], 1):
            c = w.cell(row=i, column=j, value=r[k]); c.alignment = Alignment(wrap_text=True, vertical="top")
        w.cell(row=i, column=7).fill = GREEN if r["verdict"] == "PASS" else (RED if r["verdict"] == "FAIL" else GREY)
    w.auto_filter.ref = f"A1:H{len(sd['results']) + 1}"; w.freeze_panes = "A2"
os.makedirs(B + "/final", exist_ok=True)
wb.save(B + "/final/Uponly_Test_Report.xlsx"); print("saved", n - 1, "cases")
