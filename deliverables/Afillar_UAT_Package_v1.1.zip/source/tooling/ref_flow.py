#!/usr/bin/env python3
"""Runs the PA001-style 11 step flow for every plan of every variant, using the request bodies of the
UPONLY_UAT reference collection as the template, and saves request + response of every step.
usage: ref_flow.py TAG [TAG ...]  (e.g. FP001_1)   output: samples/ref/<TAG>_P<plan>/NN_name.json"""
import json, os, re, sys, time, copy, subprocess, glob, urllib.request, urllib.error
from datetime import datetime, timedelta, timezone
B = os.environ["B"]; GW = os.environ["GW"]; TOK = os.environ["TOK"]
BASE = GW + "/platform/api-orchestration-test/v1/flow"; OUT = B + "/samples/ref"; os.makedirs(OUT, exist_ok=True)
REF = json.load(open(glob.glob("/root/.claude/uploads/*/9a04f7cf*")[0]))
P1 = {it["name"].split(". ", 1)[1]: it for it in REF["item"][5]["item"]}
def tpl(name):
    b = json.loads(P1[name]["request"]["body"]["raw"])
    if isinstance(b, dict) and name in ("Get Plans", "Create Proposal (application)"): b["ChannelCode"] = "{{channelCode}}"
    if isinstance(b, dict) and name == "Create Proposal (application)": b["OrgCode"] = "{{orgCode}}"   # a branch known to the platform PubBranch code table; without it the cancellation cannot be validated
    return b
NOW = datetime.now(timezone.utc); EFF = NOW + timedelta(days=1); EXP = EFF.replace(year=EFF.year + 1) - timedelta(days=1)
ymd = lambda d: d.strftime("%Y-%m-%d")
VARS = {"applyDate": ymd(NOW), "effectiveDate": ymd(EFF), "expiry1y": ymd(EXP) + "T23:59:59", "cancelDate": ymd(EFF + timedelta(days=30)),
        "channelCode": "SOHAR", "orgCode": "1", "monthStart": NOW.strftime("%Y-%m-01"), "monthEnd": ymd((NOW.replace(day=28) + timedelta(days=4)).replace(day=1) - timedelta(days=1))}
def concrete(o, extra=None):
    s = json.dumps(o); v = dict(VARS); v.update(extra or {})
    for k, val in v.items(): s = s.replace("{{%s}}" % k, str(val))
    return json.loads(s)
def call(method, path, body=None, query=None):
    global TOK
    for attempt in (0, 1, 2, 3):
        url = BASE + path + (("?" + query) if query else "")
        req = urllib.request.Request(url, data=json.dumps(body).encode() if body is not None else None, method=method,
                                     headers={"Authorization": "Bearer " + TOK, "Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=240) as r: raw = r.read(); st = r.status; ct = r.headers.get("Content-Type", "")
        except urllib.error.HTTPError as e: raw = e.read(); st = e.code; ct = e.headers.get("Content-Type", "")
        except Exception as e:
            print("   (retry after", type(e).__name__, ")", flush=True); time.sleep(5)
            if attempt == 3: raw = b"connection failed"; st = 599; ct = ""; break
            continue
        if st == 401 and attempt == 0:
            j = json.loads(subprocess.run(["imo", "auth", "prepare", "--profile", "portal:uponly", "--json"], capture_output=True, text=True, cwd="/home/user/Tablet").stdout)
            TOK = j.get("access_token") or j.get("token"); continue
        if st == 502 and attempt < 2: time.sleep(5); continue
        break
    if raw[:4] == b"%PDF": parsed = {"_pdf": True, "_contentType": ct, "_bytes": len(raw)}
    elif raw[:2] == b"PK": parsed = {"_xlsx": True, "_contentType": ct, "_bytes": len(raw)}
    else:
        try: parsed = json.loads(raw)
        except Exception: parsed = {"_nonJson": raw[:200].decode("utf-8", "replace"), "_contentType": ct, "_bytes": len(raw)}
    return st, parsed
def save(d, n, name, tbody, method, path, query, st, resp):
    json.dump({"name": name, "request": {"method": method, "path": path, "query": query, "body": tbody}, "response": {"status": st, "body": resp}},
              open(f"{d}/{n:02d}_{name}.json", "w"), indent=2)
    print(f"   {n:02d} {name:18s} {st} {json.dumps(resp)[:110]}", flush=True)
def build(tag, plan, plans_by_id, sample):
    code, sub = tag.split("_"); pl = plans_by_id[plan]
    t = tpl("Create Proposal (application)")
    t["ProductCode"] = code; t["ProductSubcode"] = sub; t["PremiumModeCode"] = sample["PremiumModeCode"]; t["PolicyTerm"] = sample["PolicyTerm"]
    t["PlanId"] = int(plan); t["DuePremium"] = pl["DuePremium"]
    lob = t["PolicyLobList"][0]; lob["ProductCode"] = code; lob["DuePremium"] = pl["DuePremium"]
    risk = lob["PolicyRiskList"][0]
    risk["PlanList"] = [{"PolicyCoverageList": [{"ProductElementCode": c["ProductElementCode"], "SumInsured": c["SumInsured"]} for c in pl["PolicyCoverageList"]], "PlanId": int(plan)}]
    srisk = sample["PolicyLobList"][0]["PolicyRiskList"][0]
    if code == "FP001":
        for k in ("Gender", "Salutation", "InsuredName"): risk[k] = srisk[k]
    return t
def run(tag):
    code, sub = tag.split("_")
    sample = json.load(open(f"{B}/samples/req/{tag}_proposal.json"))
    # plans of the variant
    gp = tpl("Get Plans"); gp["ProductCode"] = code; gp["ProductSubcode"] = sub
    gp["PolicyLobList"][0]["ProductCode"] = code
    gp["PremiumModeCode"] = sample["PremiumModeCode"]
    st, r = call("POST", "/up/get-plans", concrete(gp, {"applicationNo": "x"}))
    plans = r["PolicyLobList"][0]["PolicyRiskList"][0]["PlanList"]; plans_by_id = {p["PlanId"]: p for p in plans}
    print("==", tag, "plans", list(plans_by_id), flush=True)
    for plan in plans_by_id:
        if os.environ.get('ONLY_PLAN') and plan != os.environ['ONLY_PLAN']: continue
        d = f"{OUT}/{tag}_P{plan}"; os.makedirs(d, exist_ok=True)
        if os.path.exists(d + "/13_load-cancelled.json"): print("   skip", d); continue
        appno = str(int(time.time() * 1000)); ex = {"applicationNo": appno}
        body = build(tag, plan, plans_by_id, sample); n = 0
        g = copy.deepcopy(gp)
        n += 1; st, r = call("POST", "/up/get-plans", concrete(g, ex)); save(d, n, "get-plans", g, "POST", "/up/get-plans", None, st, r)
        n += 1; st, r = call("POST", "/up/proposal", concrete(body, ex)); save(d, n, "proposal", body, "POST", "/up/proposal", None, st, r)
        pno = r.get("ProposalNo")
        if not pno: print("   !! no ProposalNo"); continue
        ex["proposalNo"] = pno
        upd = {"ProposalNo": "{{proposalNo}}"}; upd.update(copy.deepcopy(body))
        n += 1; st, r = call("POST", "/up/update-proposal", concrete(upd, ex)); save(d, n, "update-proposal", upd, "POST", "/up/update-proposal", None, st, r)
        n += 1; st, r = call("GET", "/up/load-policy", None, "proposalNo=" + pno + "&ChannelCode=SOHAR"); save(d, n, "load-proposal", None, "GET", "/up/load-policy", "proposalNo={{proposalNo}}&ChannelCode={{channelCode}}", st, r)
        iss = {"ProposalNo": "{{proposalNo}}", "ProductCode": code, "ChannelCode": "{{channelCode}}"}
        n += 1; st, r = call("POST", "/up/issue", concrete(iss, ex)); save(d, n, "issue", iss, "POST", "/up/issue", None, st, r)
        pol = r.get("PolicyNo")
        if not pol: print("   !! no PolicyNo"); continue
        ex["policyNo"] = pol
        n += 1; st, r = call("GET", "/up/load-policy", None, "policyNo=" + pol + "&ChannelCode=SOHAR"); save(d, n, "load-policy", None, "GET", "/up/load-policy", "policyNo={{policyNo}}&ChannelCode={{channelCode}}", st, r)
        rb = copy.deepcopy(body); rb["ApplicationNo"] = "{{applicationNo}}R"
        n += 1; st, r = call("POST", "/up/proposal", concrete(rb, ex)); save(d, n, "proposal-for-reject", rb, "POST", "/up/proposal", None, st, r)
        rej = {"ProposalNo": "{{rejectProposalNo}}", "ProposalRejectDesc": "checker rejected", "ProductCode": code, "ChannelCode": "{{channelCode}}"}
        ex["rejectProposalNo"] = r.get("ProposalNo", "")
        n += 1; st, r = call("POST", "/up/proposal-reject", concrete(rej, ex)); save(d, n, "proposal-reject", rej, "POST", "/up/proposal-reject", None, st, r)
        ab = {"DocType": "Application", "ProposalNo": "{{proposalNo}}", "ProductSubcode": sub, "ChannelCode": "{{channelCode}}"}
        n += 1; st, r = call("POST", "/up/doc_generation", concrete(ab, ex)); save(d, n, "doc-application", ab, "POST", "/up/doc_generation", None, st, r)
        pb = {"DocType": "Policy", "PolicyNo": "{{policyNo}}", "ProductSubcode": sub, "ChannelCode": "{{channelCode}}"}
        n += 1; st, r = call("POST", "/up/doc_generation", concrete(pb, ex)); save(d, n, "doc-policy", pb, "POST", "/up/doc_generation", None, st, r)
        # cancellation: Checker creates the request, Approver approves it (the policy becomes Cancelled), then the policy is loaded again
        cb = {"PolicyNo": "{{policyNo}}", "CancellationDate": "{{cancelDate}}", "CancelReason": "Customer request", "ChannelCode": "{{channelCode}}"}
        n += 1; st, r = call("POST", "/up/cancel-check", concrete(cb, ex)); save(d, n, "cancel-check", cb, "POST", "/up/cancel-check", None, st, r)
        req_no = r.get("RequestNo") if isinstance(r, dict) else None
        ex["requestNo"] = req_no or ""
        ap = {"PolicyNo": "{{policyNo}}", "RequestNo": "{{requestNo}}", "Decision": "APPROVE", "ChannelCode": "{{channelCode}}"}
        n += 1; st, r = call("POST", "/up/cancel-approve", concrete(ap, ex)); save(d, n, "cancel-approve", ap, "POST", "/up/cancel-approve", None, st, r)
        n += 1; st, r = call("GET", "/up/load-policy", None, "policyNo=" + pol + "&ChannelCode=SOHAR"); save(d, n, "load-cancelled", None, "GET", "/up/load-policy", "policyNo={{policyNo}}&ChannelCode={{channelCode}}", st, r)

if __name__ == "__main__":
    for t in sys.argv[1:]: run(t)
