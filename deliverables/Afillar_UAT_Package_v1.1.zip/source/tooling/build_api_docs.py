#!/usr/bin/env python3
"""External API documentation (Markdown) + OpenAPI 3.0 spec for the Uponly insurance APIs. Internal details (tenant tables, configuration keys, code names) are not part of the document."""
import json, os, re, collections
import model_data as md
B = os.environ["B"]; OUT = B + "/final2"; os.makedirs(OUT, exist_ok=True)
prods = md.products(); cts = md.code_tables(); rules = md.field_rules(); ex, vars_ = md.examples(); top = md.top_examples()
res = json.load(open(B + "/tests/results.json"))
BASE = "https://portal-gw.insuremo.com/platform/api-orchestration-test/v1/flow"
DESC = {"ChannelCode": "Your channel code (Sohar Bank = SOHAR). Required on every request; a record can only be used by the channel that created it.",
        "ProductCode": "Product code, for example UPPA001, TL001, FP001, HC001, CI001, LP001, DH001.", "ProductSubcode": "Product variant (see Reference data).",
        "PlanId": "Plan id (see Reference data).", "PremiumModeCode": "Premium mode (see code table PremiumMode).", "PolicyTerm": "Policy term in years.",
        "ApplicationNo": "Your own unique application reference.", "EffectiveDate": "Policy start date, YYYY-MM-DD.", "ExpiryDate": "Policy end date, YYYY-MM-DDT23:59:59.",
        "ApplyDate": "Application date, YYYY-MM-DD.", "BranchCode": "Branch (code table BranchCode).", "DateOfBirth": "Insured date of birth, YYYY-MM-DD.",
        "InsuredName": "Insured full name.", "IdNo": "ID / passport number.", "IdType": "ID type (code table IdType).", "Gender": "Gender (code table GenderCode).",
        "Mobile": "Mobile number; returned masked.", "CIFNumber": "Customer CIF number.", "CustomerType": "Customer type (code table CustomerType).", "RelationshipCode": "Relationship of the beneficiary (code table Relationship).",
        "Share": "Beneficiary share in percent; the shares of one insured add up to 100.", "OrgCode": "Issuing branch code. Optional: when omitted the service sends 1.",
        "CancellationDate": "Requested cancellation date, YYYY-MM-DD, between the policy start and expiry date.", "CancelReason": "Reason for the cancellation, 3 to 200 characters.",
        "RequestNo": "Cancellation request number returned by the Checker.", "Decision": "APPROVE cancels the policy; REJECT closes the request and keeps the policy in force.",
        "ProposalRejectDesc": "Reason for the rejection.", "DocType": "Application (application form) or Policy (certificate).", "PreviewData": "Y returns the print data as JSON instead of a PDF.",
        "DataTableName": "Name of the master table (for example Relationship, GenderCode, BranchCode).", "FromDate": "Start of the commission period.", "ToDate": "End of the commission period.",
        "PageNo": "Page number, starting at 1.", "PageSize": "Rows per page, 1 to 50.", "SearchType": "Policy or Proposal.", "OutputFormat": "EXCEL (default) or JSON."}
md_ = []; w = md_.append
def ok_codes(s):
    return {"R": "required", "O": "optional"}.get(s, s)
def rule_text(r):
    bits = []
    if r["DataType"] == "date": bits.append("date YYYY-MM-DD" + (" or YYYY-MM-DDTHH:MM:SS" if "T" in r.get("Pattern", "") else ""))
    elif r["DataType"] == "integer": bits.append("integer")
    elif r["DataType"] == "enum": bits.append("one of " + r["EnumValues"].replace(",", ", "))
    if r.get("MinLength") or r.get("MaxLength"): bits.append(f"{r.get('MinLength', 0)}-{r.get('MaxLength', '')} characters")
    if r.get("MinValue") is not None or r.get("MaxValue") is not None: bits.append(f"{r.get('MinValue', '')} to {r.get('MaxValue', '')}")
    if r.get("Pattern") and r["DataType"] == "string": bits.append("format `" + r["Pattern"].replace("|", "/") + "`")
    if r.get("CodeTable") and r["CodeTable"] != "UP_Channel": bits.append(f"code table {r['CodeTable']}")
    if r.get("WhenPath"): bits.append(f"required when {r['WhenPath']} = {r['WhenValue']}")
    return "; ".join(bits)
def req_table(api):
    rr = [r for r in rules if r["Api"] == api]
    out = ["| Field | Required | Format / rule | Description |", "|---|---|---|---|"]
    for r in rr:
        name = r["Path"]; leaf = re.sub(r"\[\d+\]", "", name).split(".")[-1]
        req = "Yes" if r["Required"] == "Y" and not r.get("WhenPath") else ("Conditional" if r.get("WhenPath") else "No")
        out.append(f"| `{name}` | {req} | {rule_text(r)} | {DESC.get(leaf, r['Label'])} |")
    if api in ("UPProposal", "UPUpdateProposal"):
        out.append("| `OrgCode` | No | 1-10 characters | " + DESC["OrgCode"] + " |")
    return "\n".join(out)
def js(o, n=70):
    t = json.dumps(o, indent=2, ensure_ascii=False).split("\n"); return "\n".join(t[:n] + (["  ... (trimmed)"] if len(t) > n else []))
def err_example(code, status, api=None):
    for x in res:
        if x["status"] == status and (api is None or x["api"] == api) and isinstance(x["response"], dict) and x["response"].get("code") == code: return x["response"]
# ------------------------------------------------------------------ front matter
w("# Afillar Insurance APIs - Integration Guide\n")
w("**Version 1.0 - 2 October 2026 - for channel partners (Sohar Bank and other channels)**\n")
w("This guide explains how to sell and service Uponly insurance products through the Uponly APIs: how to connect, the order of the calls, every request and response, the business rules (age, term, premium, refund) and the errors you can receive. A Postman collection (Sohar Bank) with a working example for every API and an OpenAPI 3 file (`uponly_openapi.yaml`) accompany this guide.\n")
w("## 1. Overview\n")
w("The APIs cover the full life of a policy: show the plans and premiums, create and update an application (proposal), issue the policy, print the documents, cancel the policy with a maker-checker approval, and report policies and commission.\n")
w("| Product | Code | Variants (ProductSubcode) |\n|---|---|---|")
byp = collections.OrderedDict()
for p in prods: byp.setdefault(p["code"], []).append(p)
for code, ps in byp.items(): w(f"| {ps[0]['lob']} | `{code}` | " + "; ".join(f"{p['sub']} = {p['name']}" for p in ps) + " |")
w("")
w("### Typical flow\n")
w("1. **Get plans** - send the insured details, receive every plan with its premium and covers.\n2. **Create proposal** - send the same details plus the chosen `PlanId`; receive the `ProposalNo` and the premium.\n3. **Update proposal** (optional) - add beneficiaries and payment details, or correct data, while the proposal is open.\n4. **Issue policy** - receive the `PolicyNo`.\n5. **Documents** - application form and policy certificate as PDF.\n6. **Cancellation** - the Checker calls *cancel-check* (refund calculated, request created); the Approver calls *cancel-approve* with APPROVE or REJECT.\n7. **Reporting** - load a proposal or policy, query commission, download the policy feed file.\n")
w("A proposal that is not wanted can be rejected with *proposal-reject* while it is open. An issued proposal cannot be updated, issued again or rejected.\n")
# ------------------------------------------------------------------ getting started
w("## 2. Getting started\n")
w("### 2.1 Environments\n")
w("| Environment | Base URL |\n|---|---|\n| Test (sandbox) | `" + BASE + "` |\n| Production | provided by the Uponly onboarding team at go-live |\n")
w("All paths in this guide are relative to the base URL, for example `POST {baseUrl}/up/get-plans`. Use HTTPS only.\n")
w("### 2.2 Authentication\n")
w("Every call needs a bearer token: `Authorization: Bearer <token>`. Tokens are issued for the API user created for your channel (user name and password are provided during onboarding). In the Postman collection the request *0. Get Token* fetches a token and stores it for the other requests. A token expires after a while; on **HTTP 401** fetch a new token and repeat the call. Never put credentials or tokens in URLs, logs or source code.\n")
w("### 2.3 Request conventions\n")
w("- JSON body, `Content-Type: application/json`, UTF-8. GET requests carry their parameters in the query string.\n- Dates are `YYYY-MM-DD`; the policy expiry date is `YYYY-MM-DDT23:59:59`. Amounts are decimal numbers with 2 decimals.\n- **ChannelCode is required on every request** (GET requests: query parameter `ChannelCode`). Use the code assigned to your channel (`SOHAR` for Sohar Bank). A proposal or policy can only be read, changed, printed, cancelled or reported by the channel that created it; any other channel receives an error as if it did not exist.\n- **OrgCode**: send `1` on every proposal. When it is missing the service sends `1`.\n- Text values may contain letters (any script), digits, space and `. , ' - / @ + ( )`. Names, addresses and free text must not contain `< > $ { } \\` | ^ ~ ;` or control characters (error `INVALID_CHARACTER`).\n- Send only fields documented here. Do not send server-owned fields (policy number, ids, statuses); they are ignored.\n- Responses contain the documented fields and may contain additional technical fields. Ignore fields you do not know; do not depend on their presence or order.\n")
w("### 2.4 Timing and retries\n")
w("Typical response times: 1-4 seconds; PDF documents about 5 seconds. Use a client timeout of at least 60 seconds. Calls that create something (proposal, issue, cancel-approve) are **not idempotent**: if the answer is lost, first read the record (`load-policy`) before repeating the call. Repeating an issue or an approval is refused with HTTP 409 / 404 and does not create a second policy or refund.\n")
# ------------------------------------------------------------------ errors
w("## 3. Responses and errors\n")
w("Successful calls return HTTP 200 with JSON (or a file for PDF / Excel). Errors from the service always have this shape:\n")
w("```\n" + js(err_example("UP-VALIDATION", 400, "UPGetPlans")) + "\n```\n")
w("| HTTP | `code` | Meaning | What to do |\n|---|---|---|---|")
w("| 400 | `UP-VALIDATION` | One or more request fields are wrong; `errors[]` lists every problem (`field`, `code`, `message`) | Fix the fields and resend |\n| 400 | `UP-400` | The request cannot be processed (for example an invalid number) | Correct the request |\n| 401 | - | Missing, invalid or expired token | Get a new token |\n| 404 | `UP-404` | The proposal, policy or request does not exist for your channel | Check the number and the channel |\n| 409 | `UP-409` | The action is not allowed in the current state (already issued, rejected, cancelled, pending request) | Read the record and follow its state |\n| 422 | - | Wrong HTTP method for the path | Use the method shown in this guide |\n| 500 | `UP-500` | Unexpected error; the message is generic | Retry once, then contact support with the `trace_id` |\n| 500 | `UP-CONFIG` | The service is not configured for the request | Contact support with the `trace_id` |\n")
w("Always quote the `trace_id` when you contact support. Field error codes in `errors[]`:\n")
codes = collections.OrderedDict()
for x in res:
    b = x["response"]
    if isinstance(b, dict):
        for e in b.get("errors") or []: codes.setdefault(e.get("code"), e.get("message"))
meaning = {"REQUIRED": "A required field is missing or empty", "INVALID_FORMAT": "The value does not match the required format", "INVALID_TYPE": "The value has the wrong type (for example text instead of a number)",
           "TOO_SHORT": "Shorter than the minimum length", "TOO_LONG": "Longer than the maximum length", "OUT_OF_RANGE": "Outside the allowed range (age, term, amount, page size, date)",
           "NOT_ALLOWED": "The value or the combination of fields is not allowed", "UNKNOWN_VALUE": "The value is not in the list of allowed values (code table, product, channel)",
           "MISMATCH": "The value does not match the stored proposal / policy", "INVALID_TOTAL": "The beneficiary shares do not add up to 100", "INVALID_CHARACTER": "The value contains a character that is not allowed",
           "INVALID_BODY": "The request body is not a JSON object"}
codes.setdefault("INVALID_CHARACTER", "The value contains a character that is not allowed"); codes.setdefault("INVALID_BODY", "The request body must be a JSON object")
w("| Code | Meaning | Example message |\n|---|---|---|")
for c, m in codes.items():
    if c: w(f"| `{c}` | {meaning.get(c, '')} | {m} |")
w("")
# ------------------------------------------------------------------ API reference
w("## 4. API reference\n")
tops = top
def example_pair(key, k2=None):
    s = ex[key]; q = ("?" + s["query"]) if s["query"] else ""
    out = [f"Request: `{s['method']} {{baseUrl}}{s['path']}{q}`\n"]
    if s["request"] is not None: out.append("```\n" + js(s["request"], 60) + "\n```\n")
    return "\n".join(out), s
resp_notes = {
 "get-plans": "`PolicyLobList[0].PolicyRiskList[0].PlanList[]`: one entry per plan with `PlanId`, `PlanName`, `DuePremium` (annual premium for the plan, or the single premium), `Commission` and `PolicyCoverageList[]` (`CoverageCode`, `CoverageDescription`, `SumInsured`).",
 "proposal": "`ProposalNo` (use it for update, issue, reject and documents), `ApplicationNo`, `PlanId`, `DuePremium`, `Commission`, `CommissionRate`, `EffectiveDate`, `ExpiryDate`, `PolicyTerm`, `PremiumModeCode`, `OrgCode`, `ChannelCode`, and the insured / plan / cover data.",
 "update-proposal": "The updated proposal in the same shape as *Create proposal*.",
 "issue": "The issued policy: `PolicyNo`, `ProposalNo`, `IssueDate`, premium, plan and cover data.",
 "load-policy": "The stored proposal (`proposalNo` given) or policy (`policyNo` given) with code descriptions (fields ending in `_CodeDesc`). `PolicyStatus` 2 = in force / effective, 3 = cancelled; `ProposalStatus` shows the proposal state.",
 "proposal-reject": "`status` = SUCCESS and a confirmation `message`.",
 "doc-policy": "A PDF file (`application/pdf`); with `PreviewData` = Y the print data as JSON.",
 "doc-application": "A PDF file (`application/pdf`).",
 "cancel-check": "`RequestNo` (pass it to *cancel-approve*), `RequestStatus` = PENDING, `RequestExists` (Y when the request already existed), `PolicyInfo`, `PolicyStatus`, `PremiumDetails` (`Premium`, `PolicyPeriodDays`, `DaysSinceCommencement`, `UnexpiredDays`, `ProRataPremium`, `FreeLookDays`) and `RefundDetails` (`CancellationType` FREE_LOOK or PRO_RATA, `RefundPercent`, `RefundPremium`).",
 "cancel-approve": "`RequestStatus` = APPROVED or REJECTED, `PolicyInfo`, `PolicyStatus` (3 = Cancelled after approval), and for an approval `RefundPremium` and `EndorsementNo` (the endorsement that cancelled the policy).",
 "master": "An array of records (`Id`, `Description`, ...) of the requested master table.",
 "commission": "By policy: one record with `Premium`, `Commission`, `CommissionRate`. By plan configuration: `Records[]` per plan. By period: `Records[]`, `Total`, `PageTotalPremium`, `PageTotalCommission`.",
 "feed": "An Excel file (`application/vnd.openxmlformats-officedocument.spreadsheetml.sheet`) with one row per policy, or JSON when `OutputFormat` = JSON."}
specific_errors = {
 "get-plans": "400 `OUT_OF_RANGE` age below / above the product limit; 400 `NOT_ALLOWED` premium mode or term not available for the variant.",
 "proposal": "400 `UP-VALIDATION` (age, term, premium mode, code values, beneficiary shares). A duplicate `ApplicationNo` is not rejected: use a unique value for every proposal.",
 "update-proposal": "404 unknown proposal; 400 `MISMATCH` product differs from the stored proposal; 409 the proposal is already issued or rejected.",
 "issue": "404 unknown proposal; 400 `MISMATCH` product code differs; 409 already issued or rejected.",
 "load-policy": "400 when neither `policyNo` nor `proposalNo` is sent; 404 not found for your channel.",
 "proposal-reject": "404 unknown proposal; 409 already issued or already rejected.",
 "doc-policy": "404 unknown policy / proposal; 400 `REQUIRED` `PolicyNo` or `ProposalNo` for the chosen `DocType`.",
 "doc-application": "404 unknown proposal.",
 "cancel-check": "404 unknown policy; 400 cancellation date before the start or after the expiry date; 409 the proposal is not issued, the policy is already cancelled, or another kind of endorsement is pending.",
 "cancel-approve": "404 request not found or no longer pending (also on a second approval); 400 `NOT_ALLOWED` Decision; 409 the platform refused the cancellation - the request stays pending and can be approved again or rejected.",
 "master": "400 `REQUIRED` `DataTableName`; only master tables for insurance data are listed.",
 "commission": "400 `REQUIRED` when you send none of `PolicyNo`, `ProductCode` (+ `ProductSubcode` / `PlanId`) or `FromDate` and `ToDate`; 400 `OUT_OF_RANGE` for `PageSize` above 50; 404 unknown policy.",
 "feed": "400 for a missing date range or `PageSize` above 50. Very large result sets are limited: narrow the period and page through the result."}
n = 0
for key, name, method, path, title, purpose in md.APIS:
    n += 1
    w(f"### 4.{n} {title}\n")
    w(f"**`{method} {{baseUrl}}{path}`** - {purpose}\n")
    if key in ex:
        s = ex[key]
    api_rules = [r for r in rules if r["Api"] == name]
    if key == "load-policy":
        w("Query parameters (send `policyNo` **or** `proposalNo`):\n")
    else:
        w("**Request fields**\n")
    w(req_table(name) + "\n")
    if key in ex:
        s = ex[key]; q = ("?" + s["query"]) if s["query"] else ""
        w("**Example request**\n")
        w(f"`{s['method']} {{baseUrl}}{s['path']}{q}`\n")
        if s["request"] is not None: w("```\n" + js(s["request"], 60) + "\n```\n")
        w("**Example response** (HTTP " + str(s["status"]) + ")\n")
        body = md.trim(s["response"])
        if isinstance(body, dict) and body.get("_pdf"): w("A PDF file, `Content-Type: application/pdf`.\n")
        else: w("```\n" + js(body, 60) + "\n```\n")
    else:
        tk = {"master": "master", "commission": "commission_by_policy", "feed": "feedfile"}.get(key)
        j = tops.get(tk) if tk else None
        if j:
            rb = md.resolve(j["request"]["body"], vars_ | {"monthStart": "2026-10-01", "monthEnd": "2026-10-31"})
            w("**Example request**\n"); w(f"`{j['request']['method']} {{baseUrl}}{j['request']['path']}`\n"); w("```\n" + js(rb, 40) + "\n```\n")
            resp = j["response"]["body"]; w("**Example response** (HTTP " + str(j["response"]["status"]) + ")\n")
            if isinstance(resp, dict) and resp.get("_xlsx"): w("An Excel file.\n")
            else: w("```\n" + js(md.trim(resp[:3] if isinstance(resp, list) else resp), 40) + "\n```\n")
    w("**Response fields**: " + resp_notes[key] + "\n")
    w("**Errors**: " + specific_errors[key] + " Common errors (401, 400 validation, 422) are described in section 3.\n")
# ------------------------------------------------------------------ business rules
w("## 5. Business rules\n")
w("### 5.1 Eligibility and term\n")
w("| Product | Sub | Premium modes | Term (years) | Insured age | Max entry age | Max exit age |\n|---|---|---|---|---|---|---|")
pm = dict(cts.get("PremiumMode", []))
for p in prods:
    r = p["rule"]; modes = ", ".join(f"{c} = {pm.get(c.strip(), '')}" for c in str(r.get("PremiumModes", "")).split(","))
    w(f"| {p['code']} | {p['sub']} | {modes} | {r.get('MinTerm','')}-{r.get('MaxTerm','')} | {r.get('MinAge','')}-{r.get('MaxAge','')} | {r.get('MaxEntryAge','')} | {r.get('MaxExitAge','')} |")
w("")
w("The insured age is calculated from the date of birth at the effective date. A single premium covers the whole term; for the other premium modes the term is one year. The premium is calculated by the service from the plan; the premium and commission you send are ignored.\n")
w("### 5.2 Cancellation and refund\n")
w("Cancellation needs two steps by two roles. The **Checker** calls `cancel-check` with the cancellation date; the service calculates the refund and creates a pending request. The **Approver** calls `cancel-approve` with the `RequestNo`: APPROVE cancels the policy (status 3) and returns the refund, REJECT closes the request and keeps the policy in force. While a request is pending, calling `cancel-check` again returns the same request.\n")
w("| Case | Refund |\n|---|---|\n| Cancellation date up to **15 days** after the policy start date (free look) | **100%** of the premium |\n| Later | premium x unexpired days / policy days x **80%** |\n")
w("Policy days = days from the start date to the expiry date, both included; unexpired days = policy days minus days since commencement. Amounts are rounded half up to 2 decimals. Example: premium 70.00, policy 365 days, cancelled 29 days after the start: 70.00 x 336 / 365 = 64.44; 64.44 x 80% = **51.55**. The free-look days and the refund percentage are set per product (the values above apply to all products today).\n")
w("A proposal must be issued before it can be cancelled; a cancelled policy cannot be cancelled again. The cancellation date must lie between the start and the expiry date of the policy.\n")
# ------------------------------------------------------------------ reference data
w("## 6. Reference data\n")
w("### 6.1 Plans and premiums\n")
w("Premium is the annual premium of the plan (single premium products: the premium for the whole term). The exact amount for your insured is always returned by *Get plans*.\n")
w("| Product | Sub | Variant | Plan | Premium | Commission |\n|---|---|---|---|---|---|")
for p in prods:
    for pl in p["plans"]: w(f"| {p['code']} | {p['sub']} | {p['name']} | {pl['IMOPlanCode']} - {pl['IMOPlanName']} | {pl['Premium']} | {pl['Commission']} |")
w("")
w("### 6.2 Covers per plan\n")
w("| Product | Sub | Plan | Cover | Code | Sum insured / limit |\n|---|---|---|---|---|---|")
for p in prods:
    for b in p["covers"]: w(f"| {p['code']} | {p['sub']} | {b['IMOPlanCode']} | {b['BenefitDesc']} | {b['BenefitCode']} | {b['BenefitLimit']}" + (f" ({b['BenefitLimitDesc']})" if b.get("BenefitLimitDesc") and b["BenefitLimitDesc"] != "Covered" else "") + " |")
w("")
w("### 6.3 Code tables\n")
w("The same values are available from the *Master data* API.\n")
for t, vals in cts.items():
    w(f"**{t}**\n"); w("| Code | Description |\n|---|---|")
    for c, d in vals: w(f"| `{c}` | {d} |")
    w("")
# ------------------------------------------------------------------ security, testing
w("## 7. Security and data protection\n")
w("- TLS 1.2+ only; never disable certificate checks. Keep tokens secret and renew them when they expire.\n- Use the least privilege: separate API users for Checker and Approver duties of the cancellation process (role based permissions are managed by Uponly).\n- Personal data (name, ID number, mobile, e-mail, address) is processed only for the policy. The mobile number is returned masked. Do not log request or response bodies in clear text.\n- Every request is limited to your channel. Ids that belong to another channel look like unknown ids (404 / 409).\n- Input is checked for unsafe characters; do not send markup or script text in any field.\n- Report suspected security issues to Uponly support immediately, with the `trace_id`.\n")
w("## 8. Testing and go-live\n")
w("1. Import `Sohar_Bank.postman_collection.json` and the *Sohar Bank* environment; set `username` and `password`; run *0. Get Token*.\n2. Run the folder of a product from top to bottom (13 steps: plans, proposal, update, load, issue, load policy, reject, documents, cancel check, cancel approve, load cancelled policy).\n3. Test the error cases of section 3 (missing field, unknown number, second issue, second approval).\n4. Agree with Uponly the production base URL, credentials and the Checker / Approver users.\n5. Go-live checklist: token renewal on 401, unique `ApplicationNo` per proposal, `ChannelCode` and `OrgCode` on every proposal, handling of 400 / 404 / 409, storing `ProposalNo`, `PolicyNo`, `RequestNo` and `trace_id`, no retry of issue / approve without reading the record first.\n")
w("## 9. Change log\n")
w("| Version | Date | Change |\n|---|---|---|\n| 1.0 | 2026-10-02 | First release for external channels: 7 products, 13 APIs, cancellation with Checker and Approver, ChannelCode on every request. |\n")
w("## 10. Support\n")
w("Contact the Uponly integration team (details provided at onboarding). Include the API name, the time of the call, your `ChannelCode` and the `trace_id` from the response.\n")
open(OUT + "/_old_guide.md", "w").write("\n".join(md_))
# ------------------------------------------------------------------ OpenAPI
def schema_of(r):
    t = {"string": "string", "date": "string", "integer": "integer", "enum": "string", "decimal": "number"}.get(r["DataType"], "string"); s = {"type": t}
    if r["DataType"] == "date": s["format"] = "date"
    if r.get("MinLength"): s["minLength"] = r["MinLength"]
    if r.get("MaxLength"): s["maxLength"] = r["MaxLength"]
    if r.get("MinValue") is not None: s["minimum"] = r["MinValue"]
    if r.get("MaxValue") is not None: s["maximum"] = r["MaxValue"]
    if r.get("EnumValues"): s["enum"] = r["EnumValues"].split(",")
    if r.get("Pattern") and r["DataType"] != "date": s["pattern"] = r["Pattern"]
    ct = r.get("CodeTable")
    if ct and ct in cts: s["enum"] = [c for c, d in cts[ct]]; s["description"] = "; ".join(f"{c} = {d}" for c, d in cts[ct])
    desc = DESC.get(re.sub(r"\[\d+\]", "", r["Path"]).split(".")[-1])
    if desc and "description" not in s: s["description"] = desc
    return s
def nest(props, path, schema, required):
    parts = path.split("."); cur = props
    for i, part in enumerate(parts):
        m = re.match(r"^(.*)\[(\d+)\]$", part); name = m.group(1) if m else part; last = i == len(parts) - 1
        if last: cur[name] = schema; return
        if m: cur = cur.setdefault(name, {"type": "array", "items": {"type": "object", "properties": {}}})["items"]["properties"]
        else: cur = cur.setdefault(name, {"type": "object", "properties": {}})["properties"]
paths = {}
errref = {"400": {"description": "Validation error", "content": {"application/json": {"schema": {"$ref": "#/components/schemas/Error"}}}}, "401": {"description": "Missing, invalid or expired token"},
          "404": {"description": "Not found for the channel", "content": {"application/json": {"schema": {"$ref": "#/components/schemas/Error"}}}}, "409": {"description": "Not allowed in the current state", "content": {"application/json": {"schema": {"$ref": "#/components/schemas/Error"}}}}}
for key, name, method, path, title, purpose in md.APIS:
    rr = [r for r in rules if r["Api"] == name]
    op = {"summary": title, "description": purpose, "operationId": name[0].lower() + name[1:], "tags": [{"get-plans": "Sales", "proposal": "Sales", "update-proposal": "Sales", "issue": "Sales", "proposal-reject": "Sales", "load-policy": "Servicing", "doc-policy": "Documents", "doc-application": "Documents", "cancel-check": "Cancellation", "cancel-approve": "Cancellation", "master": "Reference data", "commission": "Reporting", "feed": "Reporting"}[key]]}
    if method == "GET":
        op["parameters"] = [{"name": r["Path"] if r["Path"] != "ChannelCode" else "ChannelCode", "in": "query", "required": r["Required"] == "Y", "schema": schema_of(r), "description": DESC.get(r["Path"], r["Label"])} for r in rr]
        sch = ex[key]["response"] if key in ex else {}
    else:
        props = {}; req = []
        for r in rr:
            nest(props, r["Path"], schema_of(r), req)
            if r["Required"] == "Y" and "." not in r["Path"] and "[" not in r["Path"] and not r.get("WhenPath"): req.append(r["Path"])
        if key in ("proposal", "update-proposal"): props["OrgCode"] = {"type": "string", "default": "1", "description": DESC["OrgCode"]}
        body = {"type": "object", "properties": props}
        if req: body["required"] = sorted(set(req))
        s = ex.get(key); exmp = s["request"] if s and s["request"] is not None else None
        if exmp is None:
            tk = {"master": "master", "commission": "commission_by_policy", "feed": "feedfile"}.get(key); j = tops.get(tk) if tk else None
            exmp = md.resolve(j["request"]["body"], vars_ | {"monthStart": "2026-10-01", "monthEnd": "2026-10-31"}) if j else None
        content = {"application/json": {"schema": body}}
        if exmp is not None: content["application/json"]["example"] = exmp
        op["requestBody"] = {"required": True, "content": content}
    okresp = {"description": "Success"}
    sres = ex[key]["response"] if key in ex else None
    if key in ("doc-policy", "doc-application"): okresp["content"] = {"application/pdf": {"schema": {"type": "string", "format": "binary"}}}
    elif key == "feed": okresp["content"] = {"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": {"schema": {"type": "string", "format": "binary"}}, "application/json": {"schema": {"type": "object"}}}
    else:
        okresp["content"] = {"application/json": {"schema": {"type": "object"}}}
        if isinstance(sres, dict) and not sres.get("_pdf"): okresp["content"]["application/json"]["example"] = md.trim(sres)
    op["responses"] = {"200": okresp, **errref}
    paths.setdefault(path, {})[method.lower()] = op
spec = {"openapi": "3.0.3", "info": {"title": "Afillar Insurance APIs", "version": "1.0.0", "description": "Sales, servicing, cancellation, documents and reporting APIs for the Afillar insurance products (UPPA001, TL001, FP001, HC001, CI001, LP001, DH001). See the Integration Guide for business rules."},
        "servers": [{"url": BASE, "description": "Test (sandbox)"}], "security": [{"bearerAuth": []}], "paths": paths,
        "components": {"securitySchemes": {"bearerAuth": {"type": "http", "scheme": "bearer"}},
                       "schemas": {"Error": {"type": "object", "properties": {"status": {"type": "integer"}, "code": {"type": "string"}, "message": {"type": "string"}, "api": {"type": "string"}, "trace_id": {"type": "string"},
                                                                          "errors": {"type": "array", "items": {"type": "object", "properties": {"field": {"type": "string"}, "code": {"type": "string"}, "message": {"type": "string"}}}}}}}}}
json.dump(spec, open(OUT + "/uponly_openapi.json", "w"), indent=2, ensure_ascii=False)
try:
    import yaml
    yaml.safe_dump(spec, open(OUT + "/uponly_openapi.yaml", "w"), sort_keys=False, allow_unicode=True, width=120)
    print("yaml ok")
except ImportError: print("no yaml module")
print("docs", len(md_), "lines", len(paths), "paths")
