#!/usr/bin/env python3
import json, os, re, shutil, sys, collections, copy
B = os.environ["B"]; sys.path.insert(0, B)
from pm_common import *
import common_tests as ct
OUT = B + "/final/test_cases_by_product"
shutil.rmtree(OUT, ignore_errors=True); os.makedirs(OUT)
res = json.load(open(B + "/tests/results.json"))
PRODS = ct.KNOWN + ["Common"]
APIN = {"UPGetPlans": "Get Plans", "UPProposal": "Create Proposal", "UPUpdateProposal": "Update Proposal", "UPIssue": "Issue Policy", "UPLoadPolicy": "Load Policy",
        "UPProposalReject": "Reject Proposal", "UPApplicationDocGeneration": "Application Form PDF", "UPDocGeneration": "Policy Certificate PDF",
        "UPListMasterTable": "Master Data", "UPFeedFile": "Feed File", "UPCommissionQuery": "Commission Query", "UPCancelCheck": "Cancel Check", "UPCancelApprove": "Cancel Approve"}
tree = {p: {"Success": collections.defaultdict(list), "Failure": collections.defaultdict(list)} for p in PRODS}
cnt = collections.Counter()
for r in res:
    p = ct.product_of(r); k = ct.kind(r); a = APIN.get(r["api"], r["api"])
    tree[p][k][a].append(r); cnt[(p, k)] += 1
    d = f"{OUT}/{p}/{k}/{a.replace(' ', '_')}"; os.makedirs(d, exist_ok=True)
    slug = re.sub(r"[^A-Za-z0-9]+", "_", r["title"]).strip("_")[:60]
    json.dump({"id": r["id"], "group": r["group"], "api": r["api"], "title": r["title"], "product": p, "variant": r.get("product", ""), "plan": r.get("plan", ""),
               "expected": ct.exp_text(r["expect"]), "actualStatus": r["status"], "result": r["result"], "traceId": ct.trace(r),
               "request": {"method": r["method"], "path": r["path"], "query": r.get("query"), "body": r.get("body")}, "response": r["response"]},
              open(f"{d}/{r['id']}_{slug}.json", "w"), indent=2, ensure_ascii=False)
col = base_collection("Uponly - Test cases by product (Success / Failure)", "All 857 recorded Uponly test cases. Folders: Product > Success / Failure > API > case. Every request carries a test asserting the expected HTTP status; the saved example is the real response from the test run. Set `token`; baseUrl is the Uponly test route.")
items = []; total = 0
for p in PRODS:
    pf = []
    for k in ("Success", "Failure"):
        af = []
        for a in APIN.values():
            cs = tree[p][k].get(a)
            if not cs: continue
            af.append({"name": f"{a} ({len(cs)})", "item": [case_item(f"{c['id']} - {c['title']}", c, ct.exp_text(c["expect"])) for c in cs]}); total += len(cs)
        pf.append({"name": f"{k} ({cnt[(p, k)]})", "item": af})
    items.append({"name": f"{p} ({cnt[(p, 'Success')] + cnt[(p, 'Failure')]})", "item": pf})
col["item"] = [copy.deepcopy(ref["item"][0])] + items
fn = B + "/final/Uponly_Test_Cases_ByProduct.postman_collection.json"
json.dump(col, open(fn, "w"), indent=2, ensure_ascii=False)
rd = ["# Uponly test cases by product", "", "Folder layout: `Product / Success|Failure / API / <caseId>_<title>.json`. Each JSON has the request, expected result, actual status, result and the real response.", "",
      "| Product | Success | Failure | Total |", "|---|---:|---:|---:|"]
for p in PRODS: rd.append(f"| {p} | {cnt[(p,'Success')]} | {cnt[(p,'Failure')]} | {cnt[(p,'Success')]+cnt[(p,'Failure')]} |")
rd += ["", f"Total {sum(cnt.values())} cases, all PASS.", "", "`Common` holds cases not tied to one product (master data, feed file, commission query, state and robustness checks).",
       "Success = expected HTTP 200 (including boundary passes). Failure = expected 400/404/409/422 (validation, state, not found, robustness).", "",
       "The same cases are in `Uponly_Test_Cases_ByProduct.postman_collection.json` (same folder structure)."]
open(OUT + "/README.md", "w").write("\n".join(rd))
nfiles = sum(len(f) for _, _, f in os.walk(OUT)) - 1
print("files", nfiles, "collection cases", total, dict(cnt))
