import json, os, glob, copy
B = os.environ["B"]
ref = json.load(open(glob.glob("/root/.claude/uploads/*/9a04f7cf*")[0]))
T = {it["name"].split(". ", 1)[1]: it for it in ref["item"][5]["item"]}
STAT = {200: "OK", 400: "Bad Request", 401: "Unauthorized", 404: "Not Found", 409: "Conflict", 422: "Unprocessable Entity", 500: "Internal Server Error"}
def raw_body(b): return json.dumps(b, indent=4, ensure_ascii=False)
def resp_text(r):
    if isinstance(r, dict) and r.get("_pdf"): return f"(binary PDF, {r.get('_bytes', 0):,} bytes) Content-Type: {ctype(r)}"
    if isinstance(r, dict) and r.get("_xlsx"): return f"(binary, {r.get('_bytes', 0):,} bytes) Content-Type: {ctype(r)}"
    return json.dumps(r, indent=2, ensure_ascii=False)
def ctype(r):
    if isinstance(r, dict) and (r.get("_pdf") or r.get("_xlsx")): return r.get("_contentType", "application/pdf" if r.get("_pdf") else "application/octet-stream")
    return "application/json;charset=UTF-8"
def url_of(path, query):
    if isinstance(query, dict): query = "&".join(f"{k}={v}" for k, v in query.items())
    u = {"raw": "{{baseUrl}}" + path + (("?" + query) if query else ""), "host": ["{{baseUrl}}"], "path": [p for p in path.split("/") if p]}
    if query: u["query"] = [{"key": k, "value": v} for k, v in (x.split("=", 1) for x in query.split("&"))]
    return u
def example(req, status, body):
    orig = {k: copy.deepcopy(req[k]) for k in ("method", "header", "url", "body") if k in req}
    return {"name": f"{status} - saved example", "originalRequest": orig, "status": STAT.get(status, ""), "code": status,
            "_postman_previewlanguage": "json" if ctype(body).startswith("application/json") else "text",
            "header": [{"key": "Content-Type", "value": ctype(body)}], "body": resp_text(body)}
CANCEL_CHECK_TEST = ["pm.test('Status is 200', function () { pm.response.to.have.status(200); });", "var j = pm.response.json();",
                     "pm.test('RequestNo and refund returned', function () { pm.expect(j.RequestNo).to.be.a('string'); pm.expect(j.RefundDetails.RefundPremium).to.be.a('number'); pm.expect(j.PolicyStatus.Code).to.be.a('string'); });",
                     "pm.collectionVariables.set('requestNo', j.RequestNo);"]
CANCEL_APPROVE_TEST = ["pm.test('Status is 200 (APPROVE cancels the policy, REJECT closes the request)', function () { pm.response.to.have.status(200); });", "var j = pm.response.json();",
                       "pm.test('Request status and policy info returned', function () { pm.expect(j.RequestStatus).to.be.a('string'); pm.expect(j.PolicyInfo.PolicyNo).to.be.a('string'); if (j.RequestStatus === 'APPROVED') { pm.expect(j.PolicyStatus.Code).to.eql('3'); pm.expect(j.RefundPremium).to.be.a('number'); } });"]
def case_item(name, c, expected_text):
    """Postman item for a recorded test case c (dict with method/path/query/body/status/response/expect)."""
    it = copy.deepcopy(T["Reject Proposal"]); it["name"] = name
    rq = it["request"]; rq["method"] = c["method"]; rq["url"] = url_of(c["path"], c.get("query"))
    if c.get("body") is not None: rq["body"] = {"mode": "raw", "raw": raw_body(c["body"]), "options": {"raw": {"language": "json"}}}
    elif c.get("raw_body") is not None: rq["body"] = {"mode": "raw", "raw": str(c["raw_body"])}
    else: rq.pop("body", None)
    rq["description"] = f"{c['id']} - {c['title']}\nExpected: {expected_text}\nActual: HTTP {c['status']} - {c['result']}"
    st = c["expect"].get("status")
    chk = f"pm.response.to.have.status({int(st)});" if st else "pm.expect(pm.response.code).to.be.oneOf(%s);" % json.dumps(c["expect"].get("status_in", []))
    tn = json.dumps(f"{c['id']} expected: {expected_text}")
    it["event"] = [{"listen": "test", "script": {"type": "text/javascript", "exec": [f"pm.test({tn}, function () {{ {chk} }});"]}}]
    resp = c["response"] if c.get("response") is not None else {}
    it["response"] = [example(rq, int(c["status"]) if str(c["status"]).isdigit() else 0, resp)]
    return it
def base_collection(name, description):
    col = copy.deepcopy(ref)
    col["info"] = {"name": name, "schema": ref["info"]["schema"], "description": description}
    pre = col["event"][0]["script"]["exec"]
    pre.insert(pre.index("cv.set('monthStart',now.getUTCFullYear()+'-'+pad(now.getUTCMonth()+1)+'-01');"), "var canc=new Date(eff.getTime()+30*86400000); cv.set('cancelDate',ymd(canc));")
    for v in col["variable"]:
        if v["key"] == "baseUrl": v["value"] = "https://portal-gw.insuremo.com/platform/api-orchestration-test/v1/flow"
        if v["key"] in ("casUrl", "gatewayUrl"): v["value"] = "https://portal-gw.insuremo.com"
        if v["key"] == "tenant": v["value"] = "uponly"
    col["variable"] += [{"key": "cancelDate", "value": ""}, {"key": "channelCode", "value": "SOHAR"}, {"key": "orgCode", "value": "1"}, {"key": "requestNo", "value": ""}]
    return col
