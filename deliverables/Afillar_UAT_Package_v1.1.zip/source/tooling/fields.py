import json,subprocess,os,sys
B=os.environ['B']; PC=os.environ['PC'].split()
FIELDS=[ # code, fieldName, type, label, codetable
("APPLICATIONNO","ApplicationNo","string","Application No",None),
("APPLYDATE","ApplyDate","date","Apply Date",None),
("BRANCHCODE","BranchCode","string","Branch Code","BranchCode"),
("CIFNUMBER","CIFNumber","integer","CIF Number",None),
("DISCOUNTAMOUNT","DiscountAmount","decimal","Discount Amount",None),
("STAFFID","StaffId","string","Staff Id",None),
("USERNAME","UserName","string","User Name",None),
("PLANID","PlanId","string","Plan Id","Plan"),
("POLICYTERM","PolicyTerm","string","Policy Term",None),
("PREMIUMMODECODE","PremiumModeCode","string","Premium Mode Code","PremiumMode"),
("PRODUCTSUBCODE","ProductSubcode","string","Product Subcode",None),
("INSUREDNAME","InsuredName","string","Insured Name",None),
("GENDER","Gender","string","Gender","GenderCode"),
("SALUTATION","Salutation","string","Salutation","Salutation"),
("RESIDENTSTATUS","ResidentStatus","string","Resident Status","ResidentStatus"),
("DUEPREMIUM","DuePremium","decimal","Due Premium",None),
("COMMISSION","Commission","decimal","Commission",None),
("BENEFICARYNAME","BeneficaryName","string","Beneficiary Name",None),
("BENEFICARYSEQUENCE","BeneficarySequence","long","Beneficiary Sequence",None),
("RELATIONSHIPCODE","RelationshipCode","string","Relationship Code","Relationship"),
("SHARE","Share","string","Share",None),
("PLANNAME","PlanName","string","Plan Name",None),
("COVERAGECODE","CoverageCode","string","Coverage Code",None),
("STANDARDGROSSPREMIUM","StandardGrossPremium","decimal","Standard Gross Premium",None),
]
ids={}
for code,fn,t,label,ct in FIELDS:
    chk=json.loads(subprocess.run(PC+["check-field","--code",code],capture_output=True,text=True).stdout)
    if chk.get("exists"): ids[code]=chk["productElementId"]; print(code,"exists",ids[code]); continue
    r=subprocess.run(PC+["create-field","--code",code,"--type",t,"--field-name",fn,"--name",label,"--description",label,"--confirm"],capture_output=True,text=True)
    try:
        j=json.loads(r.stdout[r.stdout.index('{'):]); 
        ids[code]=j.get("ProductElementId") or j.get("productElementId") or j.get("@pk")
    except Exception as e:
        print(code,"ERR",r.stdout[-300:],r.stderr[-200:]); continue
    print(code,"created",ids[code])
json.dump({"ids":ids,"fields":FIELDS},open(B+"/fields_created.json","w"),indent=1)
