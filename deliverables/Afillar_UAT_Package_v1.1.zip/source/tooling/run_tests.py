#!/usr/bin/env python3
"""Generates and runs the Uponly API test suite. usage: run_tests.py [generate|run|all] [filter-substring]"""
import json, os, sys, copy, glob, time, re, urllib.request, urllib.error
from concurrent.futures import ThreadPoolExecutor
from datetime import date, timedelta
B = os.environ["B"]; GW = os.environ["GW"]; TOK = os.environ["TOK"]
src = open(B + "/ref_flow.py").read().split("def run(tag):")[0]; ns = {}; exec(src, ns)
call_flow = ns["call"]; VARS = ns["VARS"]; concrete = ns["concrete"]; tpl = ns["tpl"]; build = ns["build"]
BASE = GW + "/platform/api-orchestration-test/v1/flow"
TD = B + "/tests"
def http(method, path, body=None, query=None, token=TOK, raw_body=None):
    url = BASE + path + (("?" + query) if query else "")
    data = raw_body if raw_body is not None else (json.dumps(body).encode() if body is not None else None)
    h = {"Content-Type": "application/json"}
    if token: h["Authorization"] = "Bearer " + token
    for attempt in range(3):
        try:
            req = urllib.request.Request(url, data=data, method=method, headers=h)
            with urllib.request.urlopen(req, timeout=120) as r: raw = r.read(); st = r.status; ct = r.headers.get("Content-Type", "")
        except urllib.error.HTTPError as e: raw = e.read(); st = e.code; ct = e.headers.get("Content-Type", "")
        except Exception as e:
            if attempt == 2: return 599, {"_error": str(e)}
            time.sleep(4); continue
        if st == 502 and attempt < 2: time.sleep(4); continue
        break
    if raw[:4] == b"%PDF": return st, {"_pdf": True, "_bytes": len(raw)}
    if raw[:2] == b"PK": return st, {"_xlsx": True, "_bytes": len(raw)}
    try: return st, json.loads(raw)
    except Exception: return st, {"_nonJson": raw[:200].decode("utf-8", "replace")}
# ---------------------------------------------------------------- bodies
PLANS = {}
def plans_of(tag):
    if tag not in PLANS:
        code, sub = tag.split("_"); gp = tpl("Get Plans"); gp["ProductCode"] = code; gp["ProductSubcode"] = sub; gp["PolicyLobList"][0]["ProductCode"] = code
        mode = json.load(open(f"{B}/samples/req/{tag}_proposal.json"))["PremiumModeCode"]; gp["PremiumModeCode"] = mode
        st, r = http("POST", "/up/get-plans", concrete(gp, {"applicationNo": "x"}))
        PLANS[tag] = {p["PlanId"]: p for p in r["PolicyLobList"][0]["PolicyRiskList"][0]["PlanList"]}
    return PLANS[tag]
def proposal_body(tag, plan, mode=None, term=None):
    sample = json.load(open(f"{B}/samples/req/{tag}_proposal.json"))
    if mode: sample["PremiumModeCode"] = mode
    if term: sample["PolicyTerm"] = term
    b = build(tag, plan, plans_of(tag), sample)
    if mode: b["PremiumModeCode"] = mode
    if term: b["PolicyTerm"] = term
    return concrete(b, {"applicationNo": str(int(time.time() * 1000)) + str(len(CASES))})
def getplans_body(tag, mode=None):
    code, sub = tag.split("_"); gp = tpl("Get Plans"); gp["ProductCode"] = code; gp["ProductSubcode"] = sub; gp["PolicyLobList"][0]["ProductCode"] = code
    m = mode or json.load(open(f"{B}/samples/req/{tag}_proposal.json"))["PremiumModeCode"]; gp["PremiumModeCode"] = m
    return concrete(gp, {"applicationNo": "x"})
def setp(o, path, val, delete=False):
    parts = path.split("."); cur = o
    for i, part in enumerate(parts):
        m = re.match(r"^(.*)\[(\d+)\]$", part); name, idx = (m.group(1), int(m.group(2))) if m else (part, None)
        last = i == len(parts) - 1
        if last and idx is None:
            if delete: cur.pop(name, None)
            else: cur[name] = val
            return
        cur = cur[name]
        if idx is not None:
            if last:
                if delete: cur.pop(idx)
                else: cur[idx] = val
                return
            cur = cur[idx]
CASES = []
CHANNEL = "SOHAR"
def with_channel(title, path, method, body, query):
    """Every request carries ChannelCode (the Channel code field cases build their own value)."""
    if "Channel code" in title: return body, query
    if isinstance(body, dict) and "ChannelCode" not in body: body = dict(body, ChannelCode=CHANNEL)
    if method == "GET" and path.endswith("/load-policy") and (query is None or "ChannelCode" not in query): query = (query + "&" if query else "") + "ChannelCode=" + CHANNEL
    return body, query
def case(cid, group, api, title, method, path, body=None, query=None, expect=None, product="", plan="", note="", token=True, raw_body=None):
    body, query = with_channel(title, path, method, body, query)
    CASES.append(dict(id=cid, group=group, api=api, title=title, method=method, path=path, body=body, query=query, expect=expect or {"status": 200}, product=product, plan=plan, note=note, token=token, raw_body=raw_body))
API_PATH = {"UPGetPlans": "/up/get-plans", "UPProposal": "/up/proposal", "UPUpdateProposal": "/up/update-proposal", "UPIssue": "/up/issue", "UPProposalReject": "/up/proposal-reject",
            "UPLoadPolicy": "/up/load-policy", "UPListMasterTable": "/up/list-master-table", "UPFeedFile": "/up/generate-feedfile", "UPDocGeneration": "/up/doc_generation",
            "UPApplicationDocGeneration": "/up/application_doc_generation", "UPCommissionQuery": "/up/commission-query",
            "UPCancelCheck": "/up/cancel-check", "UPCancelApprove": "/up/cancel-approve"}
def rules():
    rows = []
    for f in sorted(glob.glob(B + "/tables/r_UP_FieldRule_*.json")): rows += json.load(open(f))
    return rows
def base_for(api, rule):
    b = base_for0(api, rule)
    b.setdefault("ChannelCode", CHANNEL)
    return b
def base_for0(api, rule):
    ap = rule.get("AppliesTo", "*")
    tag = "LP001_1" if ap != "*" else "HC001_1"; plan = "2" if tag == "LP001_1" else "3"
    if api == "UPProposal": return proposal_body(tag, plan)
    if api == "UPUpdateProposal":
        b = proposal_body(tag, plan); b["ProposalNo"] = "PHC0010000000001"; return b
    if api == "UPGetPlans": return getplans_body(tag)
    if api == "UPIssue": return {"ProposalNo": "PHC0010000000001", "ProductCode": "HC001"}
    if api == "UPProposalReject": return {"ProposalNo": "PHC0010000000001", "ProposalRejectDesc": "checker rejected", "ProductCode": "HC001"}
    if api == "UPLoadPolicy": return {"policyNo": "POHC00100000001"}
    if api == "UPListMasterTable": return {"DataTableName": "Relationship", "Id": "2"}
    if api == "UPFeedFile":
        b = json.loads(ns["REF"]["item"][3]["request"]["body"]["raw"].replace("{{monthStart}}", VARS["monthStart"]).replace("{{monthEnd}}", VARS["monthEnd"]))
        b["Conditions"]["ProductCode"] = "HC001"; return b
    if api == "UPDocGeneration":
        dt = "Policy" if rule.get("Path") == "PolicyNo" else "Application"
        return {"DocType": dt, "ProposalNo": "PHC0010000000001", "PolicyNo": "POHC00100000001", "ProductSubcode": "1"}
    if api == "UPApplicationDocGeneration": return {"proposalNo": "PHC0010000000001", "ProductSubcode": "1"}
    if api == "UPCommissionQuery": return {"ProductCode": "HC001", "ProductSubcode": "1"} if rule["Path"] not in ("FromDate", "ToDate", "PolicyNo") else ({"PolicyNo": "POHC00100000001"} if rule["Path"] == "PolicyNo" else {"FromDate": "2026-10-01", "ToDate": "2026-10-31"})
    if api == "UPCancelCheck": return {"PolicyNo": "POHC00100000001", "CancellationDate": VARS["effectiveDate"], "CancelReason": "Customer request"}
    if api == "UPCancelApprove": return {"PolicyNo": "POHC00100000001", "RequestNo": "POHC00100000001-001", "Decision": "APPROVE"}
    raise Exception(api)
def charfor(rule):
    p = rule.get("Pattern", "")
    return "1" if p.startswith("^[0-9]") else "A"
def gen_field_cases():
    n = 0
    for rule in rules():
        api = rule["Api"]; path = rule["Path"]; typ = rule["DataType"]; req = rule.get("Required") == "Y"
        method = "GET" if api == "UPLoadPolicy" else "POST"; ap = API_PATH[api]
        def mk(suffix, title, mutate, expect):
            nonlocal n; n += 1
            b = base_for(api, rule); b = mutate(b) if mutate else b
            if rule.get("WhenPath"):
                wp = rule["WhenPath"]; setp(b, wp, rule["WhenValue"])
            if method == "GET": case(f"F{n:04d}", "Field validation", api, title, method, ap, query="&".join(f"{k}={v}" for k, v in b.items()), expect=expect, note=f"{path}: {suffix}")
            else: case(f"F{n:04d}", "Field validation", api, title, method, ap, body=b, expect=expect, note=f"{path}: {suffix}")
        label = rule.get("Label") or path
        def err(code): return {"status": 400, "errors": [[path, code]]}
        def mut(v, delete=False): return lambda b: (setp(b, path, v, delete), b)[1]
        if req:
            title = f"{label}: missing"; mk("missing", title, mut(None, True), err("REQUIRED"))
            title = f"{label}: empty string"; mk("empty", title, mut(""), err("REQUIRED"))
        if method == "POST":
            title = f"{label}: object instead of value"; mk("object", title, mut({"a": 1}), err("INVALID_TYPE"))
        if typ in ("string", "enum"):
            ch = charfor(rule)
            if rule.get("MaxLength"):
                ml = int(rule["MaxLength"]); v = ("a" * ml + "@x.com") if path.endswith("Email") else ch * (ml + 1)
                title = f"{label}: longer than {ml}"; mk("too long", title, mut(v), err("TOO_LONG"))
            if rule.get("MinLength") and int(rule["MinLength"]) > 1:
                v = ch * (int(rule["MinLength"]) - 1); title = f"{label}: shorter than {rule['MinLength']}"; mk("too short", title, mut(v), err("TOO_SHORT"))
        if typ == "enum":
            title = f"{label}: not allowed value"; mk("bad enum", title, mut("Z"), err("NOT_ALLOWED"))
        elif rule.get("Pattern") and typ in ("string", "date"):
            ml = rule.get("MaxLength"); bad = "@@" if (ml and int(ml) < 7) else "@@bad@@"
            title = f"{label}: wrong format"; mk("bad format", title, mut(bad), err("INVALID_FORMAT"))
        if typ == "date":
            title = f"{label}: impossible date"; mk("bad date", title, mut("2026-13-45"), err("INVALID_FORMAT"))
            title = f"{label}: dd/MM/yyyy format"; mk("slash date", title, mut("01/10/2026"), err("INVALID_FORMAT"))
        if typ in ("integer", "decimal"):
            title = f"{label}: not a number"; mk("text", title, mut("abc"), err("INVALID_TYPE"))
            if typ == "integer":
                title = f"{label}: decimal value"; mk("decimal", title, mut("1.5"), err("INVALID_TYPE"))
            if rule.get("MinValue") != "" and rule.get("MinValue") is not None and str(rule.get("MinValue")) != "":
                v = float(rule["MinValue"]) - 1; v = int(v) if typ == "integer" else v; title = f"{label}: below minimum {rule['MinValue']}"; mk("below min", title, mut(v), err("OUT_OF_RANGE"))
            if rule.get("MaxValue") is not None and str(rule.get("MaxValue")) != "":
                v = float(rule["MaxValue"]) + 1; v = int(v) if typ == "integer" else v; title = f"{label}: above maximum {rule['MaxValue']}"; mk("above max", title, mut(v), err("OUT_OF_RANGE"))
        if rule.get("CodeTable"):
            title = f"{label}: unknown code"; mk("unknown code", title, mut("99999"), err("UNKNOWN_VALUE"))

TAGS = ["UPPA001_1", "UPPA001_2", "TL001_1", "TL001_2", "FP001_1", "HC001_1", "CI001_1", "CI001_2", "CI001_3", "LP001_1", "DH001_1"]
RULE = {}
def load_rules():
    for f in sorted(glob.glob(B + "/tables/rows_UP_ProductRule.json")):
        for r in json.load(open(f)): RULE[(r["ProductCode"], r["ProductSubcode"])] = r
def dob_for(age, eff=None):
    e = date.fromisoformat(eff or VARS["effectiveDate"]); return date(e.year - age, e.month, e.day).isoformat() if not (e.month == 2 and e.day == 29) else date(e.year - age, 2, 28).isoformat()
def dob_days(age, extra_days, eff=None):
    e = date.fromisoformat(eff or VARS["effectiveDate"]); return (date(e.year - age, e.month, e.day) + timedelta(days=extra_days)).isoformat()
def gen_business_cases():
    n = 0
    def nid(prefix):
        nonlocal n; n += 1; return f"{prefix}{n:04d}"
    for tag in TAGS:
        code, sub = tag.split("_"); rule = RULE[(code, sub)]; modes = rule["PremiumModes"].split(","); minT, maxT = int(rule["MinTerm"]), int(rule["MaxTerm"])
        plan = sorted(plans_of(tag))[0]
        # age boundaries
        entry = int(rule["MaxEntryAge"]); minage = int(rule["MinAge"])
        mode0 = json.load(open(f"{B}/samples/req/{tag}_proposal.json"))["PremiumModeCode"]
        def prop(mutator, **kw):
            b = proposal_body(tag, plan, **kw); mutator(b); return b
        dobp = "PolicyLobList[0].PolicyRiskList[0].DateOfBirth"
        for age, ok, what in ((minage, True, "exactly minimum age"), (minage - 1, False, "one day below minimum age"), (entry, True, "exactly maximum entry age"), (entry + 1, False, "just above maximum entry age")):
            dob = dob_for(age) if ok else dob_days(age, 1 if what.startswith("one day") else 0) if what.startswith("one day") else dob_for(age)
            if what.startswith("one day"): dob = dob_days(minage, 1)
            if what.startswith("just above"): dob = dob_for(entry + 1)
            b = prop(lambda b, d=dob: setp(b, dobp, d))
            exp = {"status": 200} if ok else {"status": 400, "errors": [[dobp, "OUT_OF_RANGE"]]}
            case(nid("B"), "Age rules", "UPProposal", f"{code} sub {sub}: age {what}", "POST", "/up/proposal", body=b, expect=exp, product=tag, plan=plan)
        # modes
        for m in ("1", "2", "3"):
            if m in modes:
                terms = [1] if m != "1" else sorted(set([minT, (minT + maxT) // 2, maxT]))
                for t in terms:
                    pid = sorted(plans_of(tag))[0]
                    if m != mode0 or t != json.load(open(f"{B}/samples/req/{tag}_proposal.json"))["PolicyTerm"] or True:
                        gp_ok = True
                        b = proposal_body(tag, pid, mode=m, term=str(t))
                        case(nid("B"), "Premium mode and term", "UPProposal", f"{code} sub {sub}: allowed mode {m}, term {t}", "POST", "/up/proposal", body=b, expect={"status": 200}, product=tag, plan=pid)
            else:
                b = proposal_body(tag, plan, mode=m, term="1")
                case(nid("B"), "Premium mode and term", "UPProposal", f"{code} sub {sub}: premium mode {m} not allowed", "POST", "/up/proposal", body=b, expect={"status": 400, "errors": [["PremiumModeCode", "NOT_ALLOWED"]]}, product=tag, plan=plan)
        if "1" in modes:
            for t, what in ((minT - 1, "below minimum"), (maxT + 1, "above maximum")):
                b = proposal_body(tag, plan, mode="1", term=str(t)); b2 = b
                case(nid("B"), "Premium mode and term", "UPProposal", f"{code} sub {sub}: single premium term {t} ({what})", "POST", "/up/proposal", body=b2, expect={"status": 400, "errors": [["PolicyTerm", "OUT_OF_RANGE"]]}, product=tag, plan=plan)
        if mode0 != "1":
            b = proposal_body(tag, plan, mode=mode0, term="2")
            case(nid("B"), "Premium mode and term", "UPProposal", f"{code} sub {sub}: term 2 with recurring mode {mode0}", "POST", "/up/proposal", body=b, expect={"status": 400, "errors": [["PolicyTerm", "OUT_OF_RANGE"]]}, product=tag, plan=plan)
        # plan not in variant
        b = prop(lambda b: (b.__setitem__("PlanId", 4 if False else "9")))
        case(nid("B"), "Plan rules", "UPProposal", f"{code} sub {sub}: PlanId 9 does not exist", "POST", "/up/proposal", body=prop(lambda b: b.__setitem__("PlanId", "9")), expect={"status": 400, "errors": [["PlanId", "UNKNOWN_VALUE"]]}, product=tag, plan="9")
        maxplan = max(int(p) for p in plans_of(tag))
        if maxplan < 5:
            case(nid("B"), "Plan rules", "UPProposal", f"{code} sub {sub}: plan {maxplan + 1} not offered for this variant", "POST", "/up/proposal", body=prop(lambda b, mp=maxplan: b.__setitem__("PlanId", str(mp + 1))), expect={"status": 400, "errors": [["PlanId", "NOT_ALLOWED"]]}, product=tag, plan=str(maxplan + 1))
        # beneficiary share
        if code in ("UPPA001", "TL001", "CI001", "LP001"):
            case(nid("B"), "Beneficiary rules", "UPProposal", f"{code} sub {sub}: beneficiary share total 90", "POST", "/up/proposal", body=prop(lambda b: setp(b, "PolicyLobList[0].PolicyRiskList[0].BeneficiaryList[0].Share", "90")), expect={"status": 400, "errors": [["PolicyLobList[0].PolicyRiskList[0].BeneficiaryList", "INVALID_TOTAL"]]}, product=tag, plan=plan)
        # unknown sub-code
        b = prop(lambda b: b.__setitem__("ProductSubcode", "9"))
        case(nid("B"), "Product rules", "UPProposal", f"{code}: unknown sub code 9", "POST", "/up/proposal", body=b, expect={"status": 400, "errors": [["ProductSubcode", "UNKNOWN_VALUE"]]}, product=tag, plan=plan)
        # dates
        b = prop(lambda b: b.__setitem__("ExpiryDate", b["EffectiveDate"] + "T23:59:59")); b["ExpiryDate"] = VARS["effectiveDate"] + "T00:00:00"
        case(nid("B"), "Date rules", "UPProposal", f"{code} sub {sub}: ExpiryDate not after EffectiveDate", "POST", "/up/proposal", body=b, expect={"status": 400, "errors": [["ExpiryDate", "OUT_OF_RANGE"]]}, product=tag, plan=plan)
        past = (date.today() - timedelta(days=5)).isoformat()
        case(nid("B"), "Date rules", "UPProposal", f"{code} sub {sub}: EffectiveDate in the past", "POST", "/up/proposal", body=prop(lambda b: b.__setitem__("EffectiveDate", past)), expect={"status": 400, "errors": [["EffectiveDate", "OUT_OF_RANGE"]]}, product=tag, plan=plan)
        case(nid("B"), "Date rules", "UPProposal", f"{code} sub {sub}: date of birth in the future", "POST", "/up/proposal", body=prop(lambda b: setp(b, dobp, (date.today() + timedelta(days=30)).isoformat())), expect={"status": 400, "errors": [[dobp, "OUT_OF_RANGE"]]}, product=tag, plan=plan)
        # get plans
        gp = getplans_body(tag); case(nid("G"), "Get plans", "UPGetPlans", f"{code} sub {sub}: plans returned", "POST", "/up/get-plans", body=gp, expect={"status": 200, "plans": len(plans_of(tag))}, product=tag)
        gp2 = getplans_body(tag); gp2["PolicyLobList"][0]["PolicyRiskList"][0]["DateOfBirth"] = dob_for(minage - 1)
        case(nid("G"), "Get plans", "UPGetPlans", f"{code} sub {sub}: age below minimum", "POST", "/up/get-plans", body=gp2, expect={"status": 400, "errors": [[dobp, "OUT_OF_RANGE"]]}, product=tag)
        gp3 = getplans_body(tag); gp3["PremiumModeCode"] = "7"
        case(nid("G"), "Get plans", "UPGetPlans", f"{code} sub {sub}: unknown premium mode 7", "POST", "/up/get-plans", body=gp3, expect={"status": 400, "errors": [["PremiumModeCode", "UNKNOWN_VALUE"]]}, product=tag)
    # product-level
    gp = getplans_body("HC001_1"); gp["ProductCode"] = "ZZ999"; case(nid("G"), "Get plans", "UPGetPlans", "unknown product code ZZ999", "POST", "/up/get-plans", body=gp, expect={"status": 400, "errors": [["ProductCode", "UNKNOWN_VALUE"]]})
    gp = getplans_body("HC001_1"); gp["ProductCode"] = "PA001"; case(nid("G"), "Get plans", "UPGetPlans", "PA001 is not served by the new APIs", "POST", "/up/get-plans", body=gp, expect={"status": 400, "errors": [["ProductCode", "UNKNOWN_VALUE"]]})
    gp = getplans_body("LP001_1"); gp.pop("PremiumModeCode"); case(nid("G"), "Get plans", "UPGetPlans", "LP001 without premium mode (plans differ by mode)", "POST", "/up/get-plans", body=gp, expect={"status": 400, "errors": [["PremiumModeCode", "REQUIRED"]]})
    # not-found / state
    case(nid("S"), "Not found and state", "UPLoadPolicy", "load unknown policy", "GET", "/up/load-policy", query="policyNo=PO00000000000", expect={"status": 404})
    case(nid("S"), "Not found and state", "UPLoadPolicy", "load unknown proposal", "GET", "/up/load-policy", query="proposalNo=P00000000000", expect={"status": 404})
    case(nid("S"), "Not found and state", "UPLoadPolicy", "no parameter", "GET", "/up/load-policy", expect={"status": 400, "errors": [["policyNo", "REQUIRED"]]})
    case(nid("S"), "Not found and state", "UPLoadPolicy", "both policyNo and proposalNo", "GET", "/up/load-policy", query="policyNo=POHC00100000001&proposalNo=PHC0010000000001", expect={"status": 400, "errors": [["proposalNo", "NOT_ALLOWED"]]})
    case(nid("S"), "Not found and state", "UPIssue", "issue unknown proposal", "POST", "/up/issue", body={"ProposalNo": "P00000000000", "ProductCode": "HC001"}, expect={"status_in": [400, 404, 409, 422]})
    case(nid("S"), "Not found and state", "UPProposalReject", "reject unknown proposal", "POST", "/up/proposal-reject", body={"ProposalNo": "P00000000000", "ProposalRejectDesc": "x reject", "ProductCode": "HC001"}, expect={"status_in": [400, 404, 409, 422]})
    ub = proposal_body("HC001_1", "3"); ub["ProposalNo"] = "P00000000000"
    case(nid("S"), "Not found and state", "UPUpdateProposal", "update unknown proposal", "POST", "/up/update-proposal", body=ub, expect={"status_in": [400, 404, 409, 422]})
    case(nid("S"), "Not found and state", "UPProposal", "ProposalNo supplied on create", "POST", "/up/proposal", body=dict(proposal_body("HC001_1", "3"), ProposalNo="PHC0010000000001"), expect={"status": 400})
    case(nid("S"), "Not found and state", "UPDocGeneration", "certificate for unknown policy", "POST", "/up/doc_generation", body={"DocType": "Policy", "PolicyNo": "PO00000000000", "ProductSubcode": "1"}, expect={"status_in": [400, 404]})
    case(nid("S"), "Not found and state", "UPApplicationDocGeneration", "application form for unknown proposal", "POST", "/up/application_doc_generation", body={"proposalNo": "P00000000000", "ProductSubcode": "1"}, expect={"status_in": [400, 404]})
    case(nid("S"), "Not found and state", "UPCommissionQuery", "commission for unknown policy", "POST", "/up/commission-query", body={"PolicyNo": "PO00000000000"}, expect={"status": 404})
    case(nid("S"), "Not found and state", "UPCommissionQuery", "no criteria", "POST", "/up/commission-query", body={"Foo": "x"}, expect={"status": 400, "errors": [["PolicyNo", "REQUIRED"]]})
    case(nid("S"), "Not found and state", "UPCommissionQuery", "ToDate before FromDate", "POST", "/up/commission-query", body={"FromDate": "2026-10-31", "ToDate": "2026-10-01"}, expect={"status": 400, "errors": [["ToDate", "OUT_OF_RANGE"]]})
    case(nid("S"), "Not found and state", "UPCommissionQuery", "FromDate without ToDate", "POST", "/up/commission-query", body={"FromDate": "2026-10-01", "ProductCode": "HC001"}, expect={"status": 400, "errors": [["ToDate", "REQUIRED"]]})
    case(nid("S"), "Not found and state", "UPCommissionQuery", "unknown product", "POST", "/up/commission-query", body={"ProductCode": "ZZ999"}, expect={"status": 400, "errors": [["ProductCode", "UNKNOWN_VALUE"]]})
    case(nid("S"), "Not found and state", "UPListMasterTable", "table not in allow-list (ProductPlanRelation)", "POST", "/up/list-master-table", body={"DataTableName": "ProductPlanRelation"}, expect={"status": 400, "errors": [["DataTableName", "NOT_ALLOWED"]]})
    case(nid("S"), "Not found and state", "UPListMasterTable", "unknown record id", "POST", "/up/list-master-table", body={"DataTableName": "Relationship", "Id": "99"}, expect={"status": 200, "empty": True})
    for t in ("BranchCode", "CustomerType", "GenderCode", "IdType", "InsMaritalStatus", "Plan", "PremiumMode", "Relationship", "ResidentStatus", "Salutation", "Document", "ProductMaster", "ProductRule"):
        case(nid("M"), "Master data", "UPListMasterTable", f"list {t}", "POST", "/up/list-master-table", body={"DataTableName": t}, expect={"status": 200, "nonempty": True})
    fb = lambda **kw: dict(json.loads(ns["REF"]["item"][3]["request"]["body"]["raw"].replace("{{monthStart}}", VARS["monthStart"]).replace("{{monthEnd}}", VARS["monthEnd"])), **kw)
    for c, _ in sorted({(t.split("_")[0], 0) for t in TAGS}):
        b = fb(); b["Conditions"] = {"ProductCode": c}; case(nid("D"), "Feed file", "UPFeedFile", f"feed file Excel for {c}", "POST", "/up/generate-feedfile", body=b, expect={"status": 200})
        b = fb(OutputFormat="JSON"); b["Conditions"] = {"ProductCode": c}; case(nid("D"), "Feed file", "UPFeedFile", f"feed file JSON for {c}", "POST", "/up/generate-feedfile", body=b, expect={"status": 200})
    for ps in (1, 50):
        b = fb(PageSize=ps, OutputFormat="JSON"); b["Conditions"] = {"ProductCode": "HC001"}
        case(nid("D"), "Feed file", "UPFeedFile", f"page size {ps}", "POST", "/up/generate-feedfile", body=b, expect={"status": 200})
    case(nid("D"), "Feed file", "UPFeedFile", "page size 0", "POST", "/up/generate-feedfile", body=fb(PageSize=0), expect={"status": 400, "errors": [["PageSize", "OUT_OF_RANGE"]]})
    case(nid("D"), "Feed file", "UPFeedFile", "page size 51", "POST", "/up/generate-feedfile", body=fb(PageSize=51), expect={"status": 400, "errors": [["PageSize", "OUT_OF_RANGE"]]})
    b = fb(); b["FromRangeConditions"] = {"EffectiveDate": "2026-12-31T00:00:00"}; b["ToRangeConditions"] = {"EffectiveDate": "2026-01-01T23:59:59"}
    case(nid("D"), "Feed file", "UPFeedFile", "to date before from date", "POST", "/up/generate-feedfile", body=b, expect={"status": 400, "errors": [["ToRangeConditions.EffectiveDate", "OUT_OF_RANGE"]]})
    b = fb(); b["Conditions"] = {"ProductCode": "ZZ999"}; case(nid("D"), "Feed file", "UPFeedFile", "unknown product", "POST", "/up/generate-feedfile", body=b, expect={"status": 400, "errors": [["Conditions.ProductCode", "UNKNOWN_VALUE"]]})
    # robustness
    for api, p in API_PATH.items():
        if api == "UPLoadPolicy": continue
        case(nid("R"), "Robustness", api, "empty body", "POST", p, body={}, expect={"status": 400})
        case(nid("R"), "Robustness", api, "malformed JSON", "POST", p, raw_body=b"{bad json", expect={"status_in": [400, 422]})
        case(nid("R"), "Robustness", api, "no token", "POST", p, body={}, token=False, expect={"status_in": [401, 403]})
        case(nid("R"), "Robustness", api, "invalid token", "POST", p, body={}, token="invalid.token.value", expect={"status_in": [401, 403]})
        case(nid("R"), "Robustness", api, "wrong HTTP method (GET)", "GET", p, expect={"status_in": [400, 404, 405, 422]})
    case(nid("R"), "Robustness", "UPLoadPolicy", "no token", "GET", "/up/load-policy", query="policyNo=POHC00100000001", token=False, expect={"status_in": [401, 403]})
    case(nid("R"), "Robustness", "UPLoadPolicy", "wrong HTTP method (POST)", "POST", "/up/load-policy", body={}, expect={"status_in": [400, 404, 405, 422]})

def state_cases():
    """Sequential scenarios that need ids from earlier steps (issue twice, update after issue, reject twice ...)."""
    out = []; n = [0]
    def step(group, api, title, method, path, body, expect, query=None, product="HC001_1", plan="3", check=None):
        body, query = with_channel(title, path, method, body, query)
        n[0] += 1; c = dict(id=f"ST{n[0]:04d}", group=group, api=api, title=title, method=method, path=path, body=body, query=query, expect=expect, product=product, plan=plan, note="", token=True, raw_body=None)
        out.append(c); r = run_case(c)
        if check and r["result"] == "PASS":
            why = check(r["response"])
            if why:
                r["result"] = "FAIL"; r["reason"] = why; json.dump(trunc(r), open(f"{TD}/results/{c['id']}.json", "w"), indent=1)
        return r
    G = "State transitions"
    ok = {"status": 409}
    b1 = proposal_body("HC001_1", "3"); r = step(G, "UPProposal", "create proposal A", "POST", "/up/proposal", b1, {"status": 200}); pa = r["response"].get("ProposalNo")
    ub = dict(b1, ProposalNo=pa); step(G, "UPUpdateProposal", "update proposal A with payment", "POST", "/up/update-proposal", ub, {"status": 200})
    wrong = proposal_body("TL001_1", "1"); wrong["ProposalNo"] = pa; step(G, "UPUpdateProposal", "update proposal A with a TL001 body (product mismatch)", "POST", "/up/update-proposal", wrong, {"status": 400, "errors": [["ProductCode", "MISMATCH"]]})
    step(G, "UPIssue", "issue proposal A with wrong product code", "POST", "/up/issue", {"ProposalNo": pa, "ProductCode": "TL001"}, {"status": 400, "errors": [["ProductCode", "MISMATCH"]]})
    r = step(G, "UPIssue", "issue proposal A", "POST", "/up/issue", {"ProposalNo": pa, "ProductCode": "HC001"}, {"status": 200}); pol = r["response"].get("PolicyNo")
    step(G, "UPIssue", "issue proposal A a second time", "POST", "/up/issue", {"ProposalNo": pa, "ProductCode": "HC001"}, ok)
    step(G, "UPUpdateProposal", "update proposal A after issue", "POST", "/up/update-proposal", ub, ok)
    step(G, "UPProposalReject", "reject proposal A after issue", "POST", "/up/proposal-reject", {"ProposalNo": pa, "ProposalRejectDesc": "late reject", "ProductCode": "HC001"}, ok)
    step(G, "UPLoadPolicy", "load issued policy", "GET", "/up/load-policy", None, {"status": 200}, query=f"policyNo={pol}")
    step(G, "UPLoadPolicy", "load policy number as proposalNo", "GET", "/up/load-policy", None, {"status": 404}, query=f"proposalNo={pol}")
    step(G, "UPDocGeneration", "certificate for issued policy", "POST", "/up/doc_generation", {"DocType": "Policy", "PolicyNo": pol, "ProductSubcode": "1"}, {"status": 200})
    step(G, "UPDocGeneration", "application form for issued policy's proposal", "POST", "/up/doc_generation", {"DocType": "Application", "ProposalNo": pa, "ProductSubcode": "1"}, {"status": 200})
    step(G, "UPDocGeneration", "preview data for policy", "POST", "/up/doc_generation", {"DocType": "Policy", "PolicyNo": pol, "PreviewData": "Y"}, {"status": 200})
    step(G, "UPCommissionQuery", "commission by issued policy", "POST", "/up/commission-query", {"PolicyNo": pol}, {"status": 200})
    step(G, "UPCommissionQuery", "commission by plan configuration (HC001 plan 3)", "POST", "/up/commission-query", {"ProductCode": "HC001", "ProductSubcode": "1", "PlanId": "3"}, {"status": 200})
    step(G, "UPCommissionQuery", "commission for a period", "POST", "/up/commission-query", {"ProductCode": "HC001", "FromDate": VARS["effectiveDate"], "ToDate": VARS["effectiveDate"], "PageNo": 1, "PageSize": 5}, {"status": 200})
    step(G, "UPCommissionQuery", "commission page size 51", "POST", "/up/commission-query", {"ProductCode": "HC001", "FromDate": VARS["effectiveDate"], "ToDate": VARS["effectiveDate"], "PageSize": 51}, {"status": 400, "errors": [["PageSize", "OUT_OF_RANGE"]]})
    # cancellation: Checker, then Approver (APPROVE cancels the policy through the platform endorsement)
    cd = VARS["cancelDate"]; GC = "Cancellation"
    step(GC, "UPCancelCheck", "checker for an unknown policy", "POST", "/up/cancel-check", {"PolicyNo": "PO00000000000", "CancellationDate": cd, "CancelReason": "Customer request"}, {"status": 404})
    step(GC, "UPCancelCheck", "checker with both PolicyNo and ProposalNo", "POST", "/up/cancel-check", {"PolicyNo": pol, "ProposalNo": pa, "CancellationDate": cd, "CancelReason": "Customer request"}, {"status": 400, "errors": [["ProposalNo", "NOT_ALLOWED"]]})
    step(GC, "UPCancelCheck", "checker with neither PolicyNo nor ProposalNo", "POST", "/up/cancel-check", {"CancellationDate": cd, "CancelReason": "Customer request"}, {"status": 400, "errors": [["PolicyNo", "REQUIRED"]]})
    step(GC, "UPCancelCheck", "checker with the cancellation date before the policy starts", "POST", "/up/cancel-check", {"PolicyNo": pol, "CancellationDate": "2020-01-01", "CancelReason": "Customer request"}, {"status": 400})
    pe = proposal_body("HC001_1", "1"); r = step(GC, "UPProposal", "create proposal C (not issued)", "POST", "/up/proposal", pe, {"status": 200}); pc = r["response"].get("ProposalNo")
    step(GC, "UPCancelCheck", "checker for a proposal that is not issued", "POST", "/up/cancel-check", {"ProposalNo": pc, "CancellationDate": cd, "CancelReason": "Customer request"}, ok)
    r = step(GC, "UPCancelCheck", "checker by ProposalNo of the issued policy", "POST", "/up/cancel-check", {"ProposalNo": pa, "CancellationDate": cd, "CancelReason": "Customer request"}, {"status": 200}); rq = (r["response"] or {}).get("RequestNo", "")
    step(GC, "UPCancelCheck", "checker again by PolicyNo returns the pending request", "POST", "/up/cancel-check", {"PolicyNo": pol, "CancellationDate": cd, "CancelReason": "Customer request"}, {"status": 200})
    step(GC, "UPCancelApprove", "approver with an unknown request number", "POST", "/up/cancel-approve", {"PolicyNo": pol, "RequestNo": "UNKNOWN-001", "Decision": "APPROVE"}, {"status": 404})
    step(GC, "UPCancelApprove", "approver without Decision", "POST", "/up/cancel-approve", {"PolicyNo": pol, "RequestNo": rq}, {"status": 400, "errors": [["Decision", "REQUIRED"]]})
    step(GC, "UPCancelApprove", "approver with a Decision that is not allowed", "POST", "/up/cancel-approve", {"PolicyNo": pol, "RequestNo": rq, "Decision": "MAYBE"}, {"status": 400, "errors": [["Decision", "NOT_ALLOWED"]]})
    r = step(GC, "UPCancelApprove", "approve the request", "POST", "/up/cancel-approve", {"PolicyNo": pol, "RequestNo": rq, "Decision": "APPROVE"}, {"status": 200, "equals": [["RequestStatus", "APPROVED"], ["PolicyStatus.Code", "3"]]})
    step(GC, "UPCancelApprove", "approve the same request a second time", "POST", "/up/cancel-approve", {"PolicyNo": pol, "RequestNo": rq, "Decision": "APPROVE"}, {"status": 404})
    step(GC, "UPCancelApprove", "reject the already approved request", "POST", "/up/cancel-approve", {"PolicyNo": pol, "RequestNo": rq, "Decision": "REJECT"}, {"status": 404})
    step(GC, "UPCancelCheck", "checker for an already cancelled policy", "POST", "/up/cancel-check", {"PolicyNo": pol, "CancellationDate": cd, "CancelReason": "Customer request"}, ok)
    step(GC, "UPLoadPolicy", "load the cancelled policy", "GET", "/up/load-policy", None, {"status": 200, "equals": [["PolicyStatus", "3"]]}, query=f"policyNo={pol}")
    step(GC, "UPDocGeneration", "certificate of the cancelled policy", "POST", "/up/doc_generation", {"DocType": "Policy", "PolicyNo": pol, "ProductSubcode": "1"}, {"status": 200})
    cancellation_by_product(step)
    b2 = proposal_body("HC001_1", "2"); r = step(G, "UPProposal", "create proposal B", "POST", "/up/proposal", b2, {"status": 200}); pb = r["response"].get("ProposalNo")
    step(G, "UPProposalReject", "reject proposal B", "POST", "/up/proposal-reject", {"ProposalNo": pb, "ProposalRejectDesc": "checker rejected", "ProductCode": "HC001"}, {"status": 200})
    step(G, "UPProposalReject", "reject proposal B a second time", "POST", "/up/proposal-reject", {"ProposalNo": pb, "ProposalRejectDesc": "again", "ProductCode": "HC001"}, ok)
    step(G, "UPIssue", "issue rejected proposal B", "POST", "/up/issue", {"ProposalNo": pb, "ProductCode": "HC001"}, ok)
    step(G, "UPUpdateProposal", "update rejected proposal B", "POST", "/up/update-proposal", dict(b2, ProposalNo=pb), ok)
    b3 = proposal_body("HC001_1", "1"); b3["ApplicationNo"] = b1["ApplicationNo"]
    step(G, "UPProposal", "create proposal with an ApplicationNo already used", "POST", "/up/proposal", b3, {"status_in": [200, 400, 409, 422]})
    return out
def refund_expect(premium, elapsed, total, free_days=15, pct=80):
    """Independent calculation of the refund: free look = full premium, otherwise pro-rata of the unexpired days x pct%."""
    from decimal import Decimal as D, ROUND_HALF_UP
    q = D("0.01")
    if elapsed <= free_days: return "FREE_LOOK", D(str(premium)).quantize(q, ROUND_HALF_UP)
    pro = (D(str(premium)) * D(total - elapsed) / D(total)).quantize(q, ROUND_HALF_UP)
    return "PRO_RATA", (pro * D(pct) / D(100)).quantize(q, ROUND_HALF_UP)
def refund_check(days):
    def check(b):
        pd, rd = b["PremiumDetails"], b["RefundDetails"]
        typ, amt = refund_expect(pd["Premium"], days, pd["PolicyPeriodDays"])
        if rd["CancellationType"] != typ: return f"type {rd['CancellationType']} != {typ}"
        if abs(float(rd["RefundPremium"]) - float(amt)) > 0.005: return f"refund {rd['RefundPremium']} != {amt}"
        return ""
    return check
def cancellation_by_product(step):
    """Per product: policy -> Checker at day 10 (free look) and day 60 (pro-rata), REJECT, then APPROVE with the refund verified by an independent calculation."""
    from datetime import date as _d
    G = "Cancellation by product"; eff = date.fromisoformat(VARS["effectiveDate"])
    for tag in ["UPPA001_1", "TL001_1", "FP001_1", "HC001_1", "CI001_1", "LP001_1", "DH001_1"]:
        code = tag.split("_")[0]; plan = sorted(plans_of(tag))[0]
        r = step(G, "UPProposal", f"{code}: create proposal", "POST", "/up/proposal", proposal_body(tag, plan), {"status": 200}, product=tag, plan=plan); pno = r["response"].get("ProposalNo")
        r = step(G, "UPIssue", f"{code}: issue", "POST", "/up/issue", {"ProposalNo": pno, "ProductCode": code}, {"status": 200}, product=tag, plan=plan); po = r["response"].get("PolicyNo")
        d10 = (eff + timedelta(days=10)).isoformat(); d15 = (eff + timedelta(days=15)).isoformat(); d16 = (eff + timedelta(days=16)).isoformat(); d60 = (eff + timedelta(days=60)).isoformat()
        for label, dt, days, typ in (("day 10 (free look)", d10, 10, "FREE_LOOK"), ("day 15 (last free look day)", d15, 15, "FREE_LOOK"), ("day 16 (first pro-rata day)", d16, 16, "PRO_RATA")):
            r = step(G, "UPCancelCheck", f"{code}: checker {label}", "POST", "/up/cancel-check", {"PolicyNo": po, "CancellationDate": dt, "CancelReason": "Customer request"},
                     {"status": 200, "equals": [["RefundDetails.CancellationType", typ]]}, product=tag, plan=plan, check=refund_check(days))
            step(G, "UPCancelApprove", f"{code}: reject the {label} request", "POST", "/up/cancel-approve", {"PolicyNo": po, "RequestNo": (r["response"] or {}).get("RequestNo"), "Decision": "REJECT"}, {"status": 200}, product=tag, plan=plan)
        r = step(G, "UPCancelCheck", f"{code}: checker day 60 (pro-rata, 80%)", "POST", "/up/cancel-check", {"PolicyNo": po, "CancellationDate": d60, "CancelReason": "Customer request"},
                 {"status": 200, "equals": [["RefundDetails.CancellationType", "PRO_RATA"], ["RefundDetails.RefundPercent", "80"]]}, product=tag, plan=plan, check=refund_check(60))
        rq = (r["response"] or {}).get("RequestNo"); refund = ((r["response"] or {}).get("RefundDetails") or {}).get("RefundPremium")
        step(G, "UPCancelApprove", f"{code}: approve (policy Cancelled, same refund as the Checker)", "POST", "/up/cancel-approve", {"PolicyNo": po, "RequestNo": rq, "Decision": "APPROVE"},
             {"status": 200, "equals": [["RequestStatus", "APPROVED"], ["PolicyStatus.Code", "3"], ["RefundPremium", refund]]}, product=tag, plan=plan)
    # a proposal without OrgCode gets the default branch from UPSecurity (OrgCode 1), so the platform can validate the cancellation later
    b = proposal_body("HC001_1", "3"); b.pop("OrgCode", None)
    r = step(G, "UPProposal", "HC001: create proposal without OrgCode (default branch is applied)", "POST", "/up/proposal", b, {"status": 200, "equals": [["OrgCode", "1"]]}, product="HC001_1", plan="3"); pno = r["response"].get("ProposalNo")
    r = step(G, "UPIssue", "HC001: issue the proposal without OrgCode", "POST", "/up/issue", {"ProposalNo": pno, "ProductCode": "HC001"}, {"status": 200}, product="HC001_1", plan="3"); po = r["response"].get("PolicyNo")
    r = step(G, "UPCancelCheck", "HC001: checker for the policy created without OrgCode", "POST", "/up/cancel-check", {"PolicyNo": po, "CancellationDate": VARS["cancelDate"], "CancelReason": "Customer request"}, {"status": 200}, product="HC001_1", plan="3")
    step(G, "UPCancelApprove", "HC001: approve for the policy created without OrgCode (policy Cancelled)", "POST", "/up/cancel-approve", {"PolicyNo": po, "RequestNo": (r["response"] or {}).get("RequestNo"), "Decision": "APPROVE"}, {"status": 200, "equals": [["PolicyStatus.Code", "3"]]}, product="HC001_1", plan="3")
def judge(c, st, body):
    e = c["expect"]; reasons = []
    if "status" in e and st != e["status"]: reasons.append(f"status {st} != {e['status']}")
    if "status_in" in e and st not in e["status_in"]: reasons.append(f"status {st} not in {e['status_in']}")
    if st >= 500: reasons.append("server error")
    if e.get("errors"):
        got = {(x.get("field"), x.get("code")) for x in (body.get("errors") or [])} if isinstance(body, dict) else set()
        for f, code in e["errors"]:
            if (f, code) not in got: reasons.append(f"missing error {f}/{code}; got {sorted(got)}")
    if e.get("plans") and isinstance(body, dict):
        n = len(body["PolicyLobList"][0]["PolicyRiskList"][0].get("PlanList", []))
        if n != e["plans"]: reasons.append(f"{n} plans != {e['plans']}")
    for path, want in (e.get("equals") or []):
        cur = body
        for part in path.split("."):
            cur = cur.get(part) if isinstance(cur, dict) else None
        if str(cur) != str(want): reasons.append(f"{path} = {cur} != {want}")
    if e.get("nonempty") and not (isinstance(body, list) and body): reasons.append("empty list")
    if e.get("empty") and body != []: reasons.append("expected empty list")
    return ("PASS" if not reasons else "FAIL", "; ".join(reasons))
def trunc(r):
    """Stored copy: large responses are cut to keep the result files small (the live copy keeps the full body for the follow-up steps)."""
    r = dict(r)
    if len(json.dumps(r["response"])) >= 6000: r["response"] = {"_truncated": json.dumps(r["response"])[:1500]}
    return r
def run_case(c):
    st, body = http(c["method"], c["path"], c["body"], c["query"], token=(TOK if c["token"] is True else (c["token"] or None)), raw_body=c.get("raw_body"))
    res, why = judge(c, st, body)
    out = dict(c, status=st, response=body, result=res, reason=why)
    out["raw_body"] = None
    json.dump(trunc(out), open(f"{TD}/results/{c['id']}.json", "w"), indent=1)
    return out
if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else "all"; flt = sys.argv[2] if len(sys.argv) > 2 else ""
    load_rules(); gen_field_cases(); gen_business_cases()
    CASES[:] = [c for c in CASES if flt in json.dumps([c["id"], c["api"], c["title"]])]
    if mode in ("run", "all") and (not flt or flt == "ST"):
        st_cases = state_cases(); st_results = [json.load(open(f"{TD}/results/{c['id']}.json")) for c in st_cases]
    json.dump([dict(c, raw_body=None) for c in CASES] + [dict(c, raw_body=None) for c in (st_cases if (mode in ("run", "all") and (not flt or flt == "ST")) else [])], open(f"{TD}/cases.json", "w"), indent=1)
    print(len(CASES), "cases", flush=True)
    if mode in ("run", "all"):
        with ThreadPoolExecutor(6) as ex: results = list(ex.map(run_case, CASES))
        if not flt or flt == "ST": results += st_results
        json.dump([trunc(r) for r in results], open(f"{TD}/results.json", "w"), indent=1)
        p = sum(r["result"] == "PASS" for r in results); print("PASS", p, "FAIL", len(results) - p)
        for r in results:
            if r["result"] == "FAIL": print(r["id"], r["api"], r["title"], "|", r["reason"][:200])
