import json, os, re, sys, urllib.request, urllib.error
from datetime import date, timedelta
GW=os.environ["GW"]; TOK=os.environ["TOK"]
H={"Authorization":"Bearer "+TOK,"Content-Type":"application/json","x-mo-tenant-id":"uponly"}
E="/platform/endo/core/endo/v1"
def call(m,p,b=None):
    r=urllib.request.Request(GW+p,data=json.dumps(b).encode() if b is not None else (b"" if m=="POST" else None),method=m,headers=H)
    try:
        with urllib.request.urlopen(r,timeout=240) as x: return x.status,x.read().decode()
    except urllib.error.HTTPError as e: return e.code,e.read().decode()
po=sys.argv[1]
s,t=call("GET","/platform/proposal/v1/load?policyNo="+po); p=json.loads(t); print("status",p["PolicyStatus"])
s,t=call("GET",E+"/queryPendingEndo?policyId="+p["PolicyId"])
if s==200 and t.strip().startswith("{"): print("suspend pending",call("POST",E+"/suspendEndorsement?endoId="+str(json.loads(t)["EndoId"]))[0])
env={"EndoEffectiveDate":(date.today()+timedelta(days=60)).isoformat(),"EndoType":"3","CancelType":"32","CancelReasonCode":"1","OtherCancelReason":"probe","PolicyNo":po,"ProductId":p["ProductId"],"ProductCode":p["ProductCode"],"EndorsementPaymentInfoList":[{"PayModeCode":"30","IsInstallment":"Y","InstallmentType":"1"}]}
s,t=call("POST",E+"/createEx",env); print("createEx",s); doc=json.loads(t)
s,t=call("POST",E+"/calculateEx",doc); print("calculateEx",s,t[:300]); 
if s!=200: sys.exit()
doc=json.loads(t)
def fix(o,path=""):
    if isinstance(o,dict):
        for k,v in o.items():
            if k=="OrgCode" and str(v)=="-1": print("  OrgCode -1 at",path); o[k]="1"
            else: fix(v,path+"/"+k)
    elif isinstance(o,list):
        for i,v in enumerate(o): fix(v,path+"[%d]"%i)
fix(doc)
s,t=call("POST",E+"/validate",doc); print("validate",s,t[:2500])
if s==200:
    d2=json.loads(t) if t.strip().startswith("{") else doc
    s,t=call("POST",E+"/issueEndorsement",d2); print("issue",s,t[:2500])
