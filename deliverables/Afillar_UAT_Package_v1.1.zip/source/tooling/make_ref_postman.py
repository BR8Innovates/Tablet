#!/usr/bin/env python3
"""Builds the TrialX collection in exactly the structure of the UPONLY_UAT reference collection."""
import json, os, glob, copy, re, sys
B = os.environ["B"]; REFD = B + "/samples/ref"; OUT = os.path.dirname(B) + "/deliverables"
sys.path.insert(0, B)
ref = json.load(open(glob.glob("/root/.claude/uploads/*/9a04f7cf*")[0]))
tf = ref["item"][5]; T = {it["name"].split(". ", 1)[1]: it for it in tf["item"]}
VARIANTS = {"UPPA001_1": "with TTD", "UPPA001_2": "without TTD", "TL001_1": "with Travel", "TL001_2": "without Travel", "CI001_1": "7 CI", "CI001_2": "11 CI", "CI001_3": "32 CI"}
ORDER = ["UPPA001_1", "UPPA001_2", "TL001_1", "TL001_2", "FP001_1", "HC001_1", "CI001_1", "CI001_2", "CI001_3", "LP001_1", "DH001_1"]
STEPS = [("get-plans", "Get Plans"), ("proposal", "Create Proposal (application)"), ("update-proposal", "Update Proposal (enrolment)"),
         ("load-proposal", "Load Proposal"), ("issue", "Issue Policy"), ("load-policy", "Load Policy"),
         ("proposal-for-reject", "Create Proposal (to be rejected)"), ("proposal-reject", "Reject Proposal"),
         ("doc-application", "Application Form PDF"), ("doc-policy", "Policy Certificate PDF"), ("cancel-policy", "Cancel Policy")]
def raw_body(b): return json.dumps(b, indent=4, ensure_ascii=False)
def resp_text(r):
    if isinstance(r, dict) and r.get("_pdf"): return f"(binary PDF, {r['_bytes']:,} bytes) Content-Type: {r['_contentType']}"
    if isinstance(r, dict) and r.get("_xlsx"): return f"(binary, {r['_bytes']:,} bytes) Content-Type: {r['_contentType']}"
    return json.dumps(r, indent=2, ensure_ascii=False)
def ctype(r):
    if isinstance(r, dict) and (r.get("_pdf") or r.get("_xlsx")): return r["_contentType"]
    return "application/json;charset=UTF-8"
STAT = {200: "OK", 400: "Bad Request", 404: "Not Found"}
CANCEL_TEST = ["pm.test('Status is 200', function () { pm.response.to.have.status(200); });",
               "var j = pm.response.json();",
               "pm.test('Status and refund returned', function () { pm.expect(j.PolicyStatus).to.eql('Cancelled'); pm.expect(j.RefundPremium).to.be.a('number'); pm.expect(j.CancellationDate).to.be.a('string'); });"]
def url_of(path, query):
    u = {"raw": "{{baseUrl}}" + path + (("?" + query) if query else ""), "host": ["{{baseUrl}}"], "path": [p for p in path.split("/") if p]}
    if query: u["query"] = [{"key": k, "value": v} for k, v in (x.split("=", 1) for x in query.split("&"))]
    return u
def make_item(step, label, saved, tmpl_name, number):
    if tmpl_name in T: it = copy.deepcopy(T[tmpl_name])
    else: it = copy.deepcopy(T["Reject Proposal"])          # cancel: same item style as Reject Proposal
    it["name"] = f"{number}. {label}"
    rq, rs = saved["request"], saved["response"]
    req = it["request"]; req["method"] = rq["method"]; req["url"] = url_of(rq["path"], rq.get("query"))
    if rq.get("body") is not None: req["body"] = {"mode": "raw", "raw": raw_body(rq["body"]), "options": {"raw": {"language": "json"}}}
    else: req.pop("body", None)
    if step == "cancel-policy":
        it["event"] = [{"listen": "test", "script": {"type": "text/javascript", "exec": CANCEL_TEST}}]
        req["description"] = "Cancels the issued policy. Free look: a cancellation within 15 days of commencement refunds the full premium; later, 80% of the pro-rata premium. The response shows PolicyStatus, CancellationDate and RefundPremium (RefundDetails has the working). The cancellation is saved: repeating the call returns the saved result (AlreadyCancelled = Y)."
    orig = {k: copy.deepcopy(req[k]) for k in ("method", "header", "url", "body") if k in req}
    ex = {"name": f"{rs['status']} - saved example", "originalRequest": orig, "status": STAT.get(rs["status"], ""), "code": rs["status"],
          "_postman_previewlanguage": "json" if ctype(rs["body"]).startswith("application/json") else "text",
          "header": [{"key": "Content-Type", "value": ctype(rs["body"])}], "body": resp_text(rs["body"])}
    it["response"] = [ex]
    return it
folders = []; n = 0
for tag in ORDER:
    code, sub = tag.split("_")
    for d in sorted(glob.glob(f"{REFD}/{tag}_P*"), key=lambda p: int(p.rsplit("_P", 1)[1])):
        if not os.path.exists(d + "/10_doc-policy.json"): continue
        n += 1; plan = d.rsplit("_P", 1)[1]
        v = VARIANTS.get(tag); label = f"Plan {n} - {code} sub {sub}" + (f" ({v})" if v else "") + f" - PlanId {plan}"
        items = []
        for i, (step, nm) in enumerate(STEPS, 1):
            saved = json.load(open(f"{d}/{i:02d}_{step}.json"))
            if saved["response"]["status"] != 200: continue
            items.append(make_item(step, nm, saved, nm, i))
        folders.append({"name": label, "item": items})
# top-level items (same as the reference)
top = copy.deepcopy(ref["item"][:5])
live = {}
for f in glob.glob(f"{B}/samples/top/*.json"): live[os.path.basename(f)[:-5]] = json.load(open(f))
def set_example(item, saved):
    rq, rs = saved["request"], saved["response"]
    req = item["request"]
    if rq.get("body") is not None: req["body"] = {"mode": "raw", "raw": raw_body(rq["body"]), "options": {"raw": {"language": "json"}}}
    orig = {k: copy.deepcopy(req[k]) for k in ("method", "header", "url", "body") if k in req}
    item["response"] = [{"name": f"{rs['status']} - saved example", "originalRequest": orig, "status": STAT.get(rs["status"], ""), "code": rs["status"],
                         "_postman_previewlanguage": "json" if ctype(rs["body"]).startswith("application/json") else "text",
                         "header": [{"key": "Content-Type", "value": ctype(rs["body"])}], "body": resp_text(rs["body"])}]
for it in top:
    key = {"Application Doc (application_doc_generation)": "application_doc", "Data Table - Relationship": "master", "Generate Feed File": "feedfile"}.get(it["name"])
    if key and key in live: set_example(it, live[key])
comm = []
for k in ("by_policy", "by_config", "by_period"):
    f = f"{B}/samples/top/commission_{k}.json"
    if os.path.exists(f):
        sv = json.load(open(f)); it = copy.deepcopy(T["Reject Proposal"]); it["name"] = "Commission Query - " + k.replace("_", " ")
        it["event"] = [{"listen": "test", "script": {"type": "text/javascript", "exec": ["pm.test('Status is 200', function () { pm.response.to.have.status(200); });"]}}]
        rq = it["request"]; rq["url"] = url_of(sv["request"]["path"], None); rq["body"] = {"mode": "raw", "raw": raw_body(sv["request"]["body"]), "options": {"raw": {"language": "json"}}}
        orig = {x: copy.deepcopy(rq[x]) for x in ("method", "header", "url", "body") if x in rq}
        it["response"] = [{"name": "200 - saved example", "originalRequest": orig, "status": "OK", "code": sv["response"]["status"], "_postman_previewlanguage": "json", "header": [{"key": "Content-Type", "value": "application/json;charset=UTF-8"}], "body": resp_text(sv["response"]["body"])}]
        comm.append(it)
col = copy.deepcopy(ref)
col["info"] = {"name": "Uponly Products - Uponly tenant (PA001-style flow)", "schema": ref["info"]["schema"],
               "description": "Same request / response structure as the UPONLY UAT PA001 collection, for all additional products built in the Uponly tenant (UPPA001 = PA001 reference product, TL001, FP001, HC001, CI001, LP001, DH001).\n\nSetup: set `token` (Bearer token of the machine/API user), `baseUrl` points to the test route (paths start with /up). Run a Plan folder top to bottom: steps 1-10. Cancel Policy (step 11) is not included yet for Uponly. Dates and ApplicationNo are generated per run; ProposalNo / PolicyNo / rejectProposalNo are filled by test scripts.\n\nFolders: one per product variant and PlanId. Saved examples are the real Uponly responses. No VAT is applied.\n\nCommission is returned like the PA001 flow (set environment parameter up.return.commission = N to hide it). POST /commission-query returns the configured commission."}
col["item"] = top + folders + ([{"name": "Commission Query", "item": comm}] if comm else [])
pre = col["event"][0]["script"]["exec"]
pre.insert(pre.index("cv.set('monthStart',now.getUTCFullYear()+'-'+pad(now.getUTCMonth()+1)+'-01');"), "var canc=new Date(eff.getTime()+30*86400000); cv.set('cancelDate',ymd(canc));")
for v in col["variable"]:
    if v["key"] == "baseUrl": v["value"] = "https://portal-gw.insuremo.com/platform/api-orchestration-test/v1/flow"
    if v["key"] == "casUrl": v["value"] = "https://portal-gw.insuremo.com"
    if v["key"] == "gatewayUrl": v["value"] = "https://portal-gw.insuremo.com"
    if v["key"] == "tenant": v["value"] = "uponly"
col["variable"].append({"key": "cancelDate", "value": ""})
path = OUT + "/Uponly_Products_TrialX.postman_collection.json"
json.dump(col, open(path, "w"), indent=2, ensure_ascii=False)
print("written", path, os.path.getsize(path), "folders", len(folders), "requests", sum(len(f["item"]) for f in folders) + len(top))
