#!/usr/bin/env python3
"""Minimal Markdown -> docx (headings, paragraphs, bullets, tables, bold, code spans). usage: md_to_docx.py in.md out.docx"""
import re, sys
from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.section import WD_ORIENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
src, dst = sys.argv[1], sys.argv[2]
doc = Document(); sec = doc.sections[0]; sec.orientation = WD_ORIENT.LANDSCAPE; sec.page_width, sec.page_height = sec.page_height, sec.page_width
for m in ("left_margin", "right_margin", "top_margin", "bottom_margin"): setattr(sec, m, Cm(1.6))
doc.styles["Normal"].font.name = "Calibri"; doc.styles["Normal"].font.size = Pt(10)
def runs(p, text, size=None):
    for part in re.split(r"(\*\*[^*]+\*\*|`[^`]+`)", text):
        if not part: continue
        if part.startswith("**"): r = p.add_run(part[2:-2]); r.bold = True
        elif part.startswith("`"): r = p.add_run(part[1:-1]); r.font.name = "Consolas"; r.font.size = Pt(9)
        else: r = p.add_run(part)
        if size: r.font.size = Pt(size)
def shade(cell, color):
    tcPr = cell._tc.get_or_add_tcPr(); sh = OxmlElement("w:shd"); sh.set(qn("w:val"), "clear"); sh.set(qn("w:color"), "auto"); sh.set(qn("w:fill"), color); tcPr.append(sh)
lines = open(src, encoding="utf-8").read().split("\n"); i = 0
while i < len(lines):
    ln = lines[i]
    if ln.startswith("```"):
        i += 1; block = []
        while i < len(lines) and not lines[i].startswith("```"): block.append(lines[i]); i += 1
        i += 1
        t = doc.add_table(rows=1, cols=1); t.style = "Table Grid"; cell = t.cell(0, 0); shade(cell, "F2F2F2"); cell.text = ""
        para = cell.paragraphs[0]; r = para.add_run("\n".join(block)); r.font.name = "Consolas"; r.font.size = Pt(8)
        doc.add_paragraph(); continue
    if ln.startswith("|"):
        rows = []
        while i < len(lines) and lines[i].startswith("|"):
            cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
            if not all(re.fullmatch(r":?-{2,}:?", c) for c in cells): rows.append(cells)
            i += 1
        n = max(len(r) for r in rows); t = doc.add_table(rows=len(rows), cols=n); t.style = "Table Grid"
        for ri, r in enumerate(rows):
            for ci in range(n):
                cell = t.cell(ri, ci); cell.text = ""; p = cell.paragraphs[0]; runs(p, r[ci] if ci < len(r) else "", 8)
                if ri == 0:
                    shade(cell, "1F3864")
                    for run in p.runs: run.bold = True; run.font.color.rgb = RGBColor(255, 255, 255)
        doc.add_paragraph(); continue
    m = re.match(r"^(#{1,4}) (.*)", ln)
    if m: doc.add_heading(m.group(2), level=min(len(m.group(1)), 4))
    elif ln.startswith("- "): runs(doc.add_paragraph(style="List Bullet"), ln[2:])
    elif re.match(r"^\d+\. ", ln): runs(doc.add_paragraph(style="List Number"), re.sub(r"^\d+\. ", "", ln))
    elif ln.strip(): runs(doc.add_paragraph(), ln)
    i += 1
doc.save(dst); print("saved", dst)
