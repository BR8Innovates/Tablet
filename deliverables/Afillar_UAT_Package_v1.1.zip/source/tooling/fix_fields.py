import json,os,re,subprocess,sys,time
B=os.environ['B']; GW=os.environ['GW']; TOK=os.environ['TOK']
req=sys.argv[1]; policy_obj=int(sys.argv[2]); product_id=sys.argv[3]
allf=json.load(open(B+'/dd/_tenant_fields.json'))
up={}
for grp in ('policy','lob','risk','plan','coverage','beneficiary'):
    for f in allf[grp]: up.setdefault(f['name'],f)
up.setdefault('ChannelCode',{'name':'ChannelCode','type':-4,'ct':None})
PF=["python3","/tmp/insuremo/insuremo-gi-product-config/scripts/policy_field.py","--gateway",GW,"--token",TOK,"--workspace",B+"/ws"]
def call():
    r=subprocess.run(["curl","-sS","-X","POST",GW+"/platform/api-orchestration-test/v1/flow/up/proposal","-H","Authorization: Bearer "+TOK,"-H","Content-Type: application/json","-d","@"+req],capture_output=True,text=True)
    return r.stdout
for i in range(60):
    out=call()
    if out.strip().startswith("Bad Gateway") or not out.strip():
        time.sleep(6); continue
    txt=out
    m=re.search(r'Field was not bound in object,param : businessObject\.(?:businessObjectId|ObjectId)=(\d+).{0,200}?(?:businessFiledName|businessField\.field)=(\w+)',txt,re.S)
    p=re.search(r'Property:(\w+) not defined in data dictionary, model:(\w+),code:(\w+),objectId:(\d+)',txt)
    if m: name,obj=m.group(2),int(m.group(1))
    elif p:
        name,obj=p.group(1),int(p.group(4))
    else:
        print("RESPONSE:",out[:700]); break
    f=up.get(name); ftype=f['type'] if f else -3; ct=f['ct'] if f and f['ct'] else None
    print(i,"missing",name,"type",ftype,"ct",ct,"(from uponly)" if f else "(guessed)")
    b={"BusinessObjectId":obj,"FieldType":ftype,"FieldName":name,"FieldCommentsEn":name,"FieldLabelEn":name,"IsFixed":"N","IsDeprecated":"N","IsMandatory":"N","IsTemp":"N","IsUnique":"N","IsIndexed":"N","IsInput":"Y"}
    if ct: b["CodeTableName"]=ct
    body={"ContextTypeId":"5","ContextId":product_id,"BusinessFieldBinding":b}
    path=f"{B}/payloads/fix_{name}.json"; json.dump(body,open(path,"w"))
    r=subprocess.run(PF+["--body-file",path,"--confirm","create-binding"],capture_output=True,text=True)
    print("   ->",("ok" if "BindingId" in r.stdout else r.stdout[-200:]))
