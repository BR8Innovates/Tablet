import json, os, collections
B = os.environ["B"]; cases = json.load(open(B + "/tests/cases.json"))
def exp(e):
    if e.get("errors"): return "400 + " + ", ".join(f"{f} {c}" for f, c in e["errors"])
    if e.get("status_in"): return "/".join(str(x) for x in e["status_in"])
    x = str(e.get("status", ""))
    if e.get("plans"): x += f", {e['plans']} plans"
    if e.get("nonempty"): x += ", list not empty"
    if e.get("empty"): x += ", empty list"
    return x
groups = collections.OrderedDict()
for c in cases: groups.setdefault((c["group"]), []).append(c)
md = ["# Uponly API test cases (shared before execution)", "",
      "Scope: the 13 `/up/...` APIs (get-plans, proposal, update-proposal, load-policy, issue, proposal-reject, list-master-table, generate-feedfile, doc_generation, application_doc_generation, commission-query, cancel-check, cancel-approve) for UPPA001 (sub 1, 2), TL001 (1, 2), FP001, HC001, CI001 (1, 2, 3), LP001, DH001. Cancellation is out of scope.", "",
      f"Total generated cases: **{len(cases)}**. Full request body of every case: `test_cases_requests.json`. Plan-wise end-to-end samples (all 52 plans, request + response of every step): `plan_samples/`.", "",
      "## How cases are produced",
      "- **Field validation**: generated from the `UP_FieldRule` table, so every rule (required, type, length, format, range, enum, code table) has missing / empty / wrong type / too long / too short / bad format / out of range / unknown code cases.",
      "- **Business rules** per product and variant: age boundaries, premium modes, terms, plan availability, beneficiary share, dates.",
      "- **State and not-found**, **master data**, **feed file**, **robustness** (empty body, malformed JSON, no/invalid token, wrong method).",
      "- **Positive plan-wise flows**: for every plan of every variant the full journey get-plans, proposal, update-proposal, load proposal, issue, load policy, proposal for reject, reject, application PDF, certificate PDF, cancel-check, cancel-approve (production of these is in `plan_samples/`).", "",
      "Expected for validation errors: HTTP 400, `code` UP-VALIDATION and `errors[]` containing the listed `field` + `code`.", ""]
cnt = collections.Counter(c["group"] for c in cases)
md += ["## Summary", "", "| Group | Cases |", "|---|---|"] + [f"| {g} | {n} |" for g, n in cnt.items()] + [""]
for g, cs in groups.items():
    md += [f"## {g} ({len(cs)})", "", "| ID | API | Product / plan | Case | Expected |", "|---|---|---|---|---|"]
    for c in cs:
        pp = (c["product"] + (f" P{c['plan']}" if c["plan"] else "")) if c["product"] else "-"
        md.append(f"| {c['id']} | {c['api']} | {pp} | {c['title'].replace('|','/')} | {exp(c['expect'])} |")
    md.append("")
os.makedirs(B + "/tests_out", exist_ok=True)
open(B + "/tests_out/Uponly_Test_Cases.md", "w").write("\n".join(md))
json.dump([{k: c[k] for k in ("id", "group", "api", "title", "method", "path", "query", "body", "expect")} for c in cases], open(B + "/tests_out/test_cases_requests.json", "w"), indent=1)
print(len(md), "lines")
