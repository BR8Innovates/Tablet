import json, os, sys, glob
sys.argv = ["x"]; src = open(os.environ["B"] + "/ref_flow.py").read().split("def build(")[0]; ns = {}; exec(src, ns)
call = ns["call"]; concrete = ns["concrete"]; P1 = ns["P1"]; REF = ns["REF"]; B = ns["B"]
top = {it["name"]: it for it in REF["item"][:5]}
def save(key, item, st, resp, body):
    json.dump({"request": {"method": "POST", "path": item["request"]["url"]["raw"].replace("{{baseUrl}}", "").split("?")[0], "body": body}, "response": {"status": st, "body": resp}}, open(f"{B}/samples/top/{key}.json", "w"), indent=2)
    print(key, st, json.dumps(resp)[:150])
it = top["Data Table - Relationship"]; body = json.loads(it["request"]["body"]["raw"]); st, r = call("POST", "/up/list-master-table", body); save("master", it, st, r, body)
it = top["Generate Feed File"]; body = json.loads(it["request"]["body"]["raw"]); body["Conditions"]["ProductCode"] = "FP001"; st, r = call("POST", "/up/generate-feedfile", concrete(body)); save("feedfile", it, st, r, body)
pno = json.load(open(glob.glob(f"{B}/samples/ref/*_P*/02_proposal.json")[0]))["response"]["body"]["ProposalNo"]
it = top["Application Doc (application_doc_generation)"]; body = json.loads(it["request"]["body"]["raw"]); b2 = json.loads(json.dumps(body).replace("{{proposalNo}}", pno))
st, r = call("POST", "/up/application_doc_generation", b2); save("application_doc", it, st, r, body)
