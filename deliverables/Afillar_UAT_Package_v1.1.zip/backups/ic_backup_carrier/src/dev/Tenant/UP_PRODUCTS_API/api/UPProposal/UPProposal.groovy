/**
 * Create a proposal (application). The request uses the native policy JSON
 * (PolicyLobList / PolicyRiskList / PlanList / PolicyCoverageList / BeneficiaryList ...).
 * The plan premium is taken from product data; coverages are filled from the plan when not supplied.
 */
import com.insuremo.icomposer.utils.IComposerJsonUtils
import com.insuremo.sdk.services.proposal.ProposalSdkClient

UPErrorHandler errorHandler = (UPErrorHandler) getCommonService("UPErrorHandler")
try {
    UPSecurity security = (UPSecurity) getCommonService("UPSecurity")
    Map<String, Object> input = security.readInput(RequestBody())
    if (input == null) {
        input = new HashMap<String, Object>()
    }
    UPDataUtil util = (UPDataUtil) getCommonService("UPDataUtil")
    UPProductData products = (UPProductData) getCommonService("UPProductData")
    UPShaper shaper = (UPShaper) getCommonService("UPShaper")
    UPValidator validator = (UPValidator) getCommonService("UPValidator")
    validator.validate("UPProposal", input)
    if (input.get("ProposalNo")) {
        util.fail("ProposalNo must not be supplied when creating a proposal. Use update-proposal.")
    }
    Map<String, Object> payload = products.prepareProposal(input)

    ProposalSdkClient proposalSdkClient = (ProposalSdkClient) getSDK("com.insuremo.sdk.services.proposal.ProposalSdkClient")
    Map<String, Object> response = (Map<String, Object>) proposalSdkClient.proposalApi()
            .newApplicationRequestBuilder()
            .requestBody(payload)
            .doRequest()
            .getBody()
    return shaper.shapeResponse(response)

} catch (Exception ex) {
    return errorHandler.handle("UPProposal", ex)
}
