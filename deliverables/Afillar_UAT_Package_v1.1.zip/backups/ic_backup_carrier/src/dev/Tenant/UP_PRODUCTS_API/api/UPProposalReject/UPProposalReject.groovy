/**
 * Reject a proposal (checker action). Request: { "ProposalNo", "ProposalRejectDesc" }.
 */
import com.insuremo.icomposer.utils.IComposerJsonUtils
import com.insuremo.sdk.services.proposal.ProposalSdkClient
import com.insuremo.sdk.services.proposal.model.RejectVo

UPErrorHandler errorHandler = (UPErrorHandler) getCommonService("UPErrorHandler")
try {
    UPSecurity security = (UPSecurity) getCommonService("UPSecurity")
    Map<String, Object> input = security.readInput(RequestBody())
    if (input == null) {
        input = new HashMap<String, Object>()
    }
    UPDataUtil util = (UPDataUtil) getCommonService("UPDataUtil")
    UPValidator validator = (UPValidator) getCommonService("UPValidator")
    validator.validate("UPProposalReject", input)
    String proposalNo = util.str(input.get("ProposalNo"))
    if (!proposalNo) {
        util.fail("ProposalNo is required")
    }
    ProposalSdkClient proposalSdkClient = (ProposalSdkClient) getSDK("com.insuremo.sdk.services.proposal.ProposalSdkClient")
    Map<String, Object> existing = (Map<String, Object>) proposalSdkClient.proposalApi().newLoadRequestBuilder().proposalNo(proposalNo).doRequest().getBody()
    if (existing == null) {
        return errorHandler.notFound("UPProposalReject", "No proposal found for ${proposalNo}".toString())
    }
    validator.requireChannel(existing, util.str(input.get("ChannelCode")))
    validator.requireProductMatch(existing, util.str(input.get("ProductCode")), "")
    validator.requireOpenProposal(existing, "rejected")
    RejectVo rejectVo = new RejectVo()
    rejectVo.setProposalNo(proposalNo)
    rejectVo.setProposalRejectDesc(util.str(input.get("ProposalRejectDesc")))
    proposalSdkClient.proposalApi().newRejectRequestBuilder().rejectVo(rejectVo).doRequest()

    Map<String, Object> response = new HashMap<String, Object>()
    response.put("status", util.cfg("SuccessStatusText", "*"))
    response.put("message", rejectVo.getProposalRejectDesc())
    return response

} catch (Exception ex) {
    return errorHandler.handle("UPProposalReject", ex)
}
