Afillar Insurance APIs - samples with values, recorded live on the MC tenant (uponly)

What is in the package
  Afillar_Samples.postman_collection.json  243 requests with literal values (no {{variables}}), each with a saved response example and a description that lists
                                           every request field, its sample value and its meaning ([M] mandatory, [O] optional, [C] conditional).
  jsonc/<folder>/NN_<case>.request.jsonc    the same request with a // comment above every field.
  jsonc/<folder>/NN_<case>.response.jsonc   the recorded response with a // comment above every field.
  Afillar_Samples.xlsx                      Cases (list of all 243), Request fields (3,234 rows: case, field, value, meaning), Response fields (one example per API).

The 243 cases
  11 product variants x 19 steps (209)  UPPA001-1/-2, TL001-1/-2, FP001, HC001, CI001-1/-2/-3, LP001, DH001. Each folder runs the whole journey:
      1 Get Plans, 2 Create Proposal, 3 Update Proposal, 4 Load Proposal, 5 Share proposal, 6 Issue, 7 Load Policy, 8 Policy certificate PDF,
      9 and 10 Application form PDF (both routes), 11 Share policy, 12 Create proposal to reject, 13 Reject, 14 Cancel Check (pro-rata),
      15 Cancel Detail, 16 Cancel Approve APPROVE, 17 Load cancelled policy, 18 Cancel Check inside the free-look period, 19 Cancel Approve REJECT.
  Staff portal and common APIs (18)      me, worklist (3), dashboard (2), share quotation, master data (3), commission (4), feed file (2), document data preview,
      and a proposal sent with a wrong premium and sum insured (the platform recalculates them: it returned premium 70 and sum insured 50).
  Error cases (16)                       E1 required field, E2 minimum age, E3 unknown plan, E4 premium mode, E5 ProposalNo sent, E6 platform rule (gender 9),
      E7 invalid character, E8 beneficiary shares, E9 not found (404), E10 already issued (409), E11 other product, E12 already cancelled (409),
      E13 cancellation date before start, E14 no token (401), E15 wrong method (422), E16 invalid JSON.

How the values were chosen
  Dates: application 2026-10-14, policy start 2026-10-15, end = start + term - 1 day; cancellation 2026-11-14 (pro-rata) and 2026-10-20 (free look, 15 days).
  People: one insured per variant (name, date of birth, id, mobile, e-mail); branch 001, channel SOHAR, user maker01, debit account and reference per variant.
  Product data: premium mode and term as accepted by each variant (single premium 3 years for UPPA001-2 and 5 years for CI001-2, annual for most, monthly for Life Protect).
  Numbers returned in one request (ProposalNo, PolicyNo, RequestNo) are used in the later requests of the same folder, exactly as recorded.

Notes
  - Authorization: every request carries a sample token (Bearer eyJ...sample-access-token). Replace it with a valid access token before sending.
  - Proposal and policy numbers are those created during the recording; to send a folder again, start from its first request so new numbers are created.
  - PDF and Excel responses are binary; the example shows their type and a note instead of the content.
  - Role checks are off in MC (RoleEnforcement N), so no 403 example is included.
  - Notifications show Status DRYRUN: the tenant has no e-mail / SMS account yet.
  - Field comments come from the policy model (Afillar_PolicyModel_v0.4) where the field is specified; platform technical fields have a general description.
