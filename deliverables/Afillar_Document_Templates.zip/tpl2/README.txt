Afillar Insurance - Application form and Policy certificate templates (Output Service, HTML)

Files
  UP_<PRODUCT>_APPLICATION_EN.html   application form  (7 products: UPPA001, TL001, FP001, HC001, CI001, LP001, DH001)
  UP_<PRODUCT>_POLICY_EN.html        policy certificate (same 7 products)
  sample/HC001_application_PrintData.json, sample/HC001_policy_PrintData.json
                                     the data merged into a template (what /up/doc_generation returns with PreviewData = Y)

How they are used
  - Template name per product / variant: table UP_DocTemplate (22 rows, column TemplateName). Variants of a product share one template.
  - /up/doc_generation (DocType Policy) and /up/application-doc-generation (DocType Application) send the PrintData to the print service
    (template_name from UP_DocTemplate, template_version from UP_ApiConfig TemplateVersion, PrintUrl from UP_ApiConfig).
  - To change a template: edit the HTML, load it in Output Service under the same name, then raise TemplateVersion if the version changes.
  - Bilingual (English / Arabic), logo, stamp and footer banner are embedded as images.

Note: regenerated from the build script (make_templates2.py) on 2026-10-07. I have not compared them against the copies currently stored in Output Service.
